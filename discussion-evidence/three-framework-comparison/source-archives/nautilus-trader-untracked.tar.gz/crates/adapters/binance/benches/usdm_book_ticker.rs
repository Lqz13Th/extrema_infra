// -------------------------------------------------------------------------------------------------
//  Copyright (C) 2015-2026 Nautech Systems Pty Ltd. All rights reserved.
//  https://nautechsystems.io
//
//  Licensed under the GNU Lesser General Public License Version 3.0 (the "License");
//  You may not use this file except in compliance with the License.
//  You may obtain a copy of the License at https://www.gnu.org/licenses/lgpl-3.0.en.html
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// -------------------------------------------------------------------------------------------------

//! Binance USD-M book-ticker decode and normalization benchmark.

use std::{hint::black_box, time::Duration};

use criterion::{Criterion, Throughput, criterion_group, criterion_main};
use nautilus_binance::futures::websocket::streams::{
    messages::BinanceFuturesBookTickerMsg, parse_data::parse_book_ticker,
};
use nautilus_core::UnixNanos;
use nautilus_model::{
    data::QuoteTick,
    identifiers::{InstrumentId, Symbol},
    instruments::{CryptoPerpetual, InstrumentAny},
    types::{Currency, Price, Quantity},
};

const BOOK_TICKER_JSON: &[u8] = br#"{"e":"bookTicker","u":10708444522016,"s":"BTCUSDT","b":"63405.40","B":"4.629","a":"63405.50","A":"2.357","T":1780563843114,"E":1780563843114}"#;
const TS_INIT: UnixNanos = UnixNanos::from_millis(1_780_563_843_115);

fn btcusdt_usdm_perpetual() -> InstrumentAny {
    InstrumentAny::CryptoPerpetual(CryptoPerpetual::new(
        InstrumentId::from("BTCUSDT-PERP.BINANCE"),
        Symbol::from("BTCUSDT"),
        Currency::from("BTC"),
        Currency::from("USDT"),
        Currency::from("USDT"),
        false,
        2,
        3,
        Price::from("0.01"),
        Quantity::from("0.001"),
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        UnixNanos::default(),
        UnixNanos::default(),
    ))
}

fn decode_message(raw: &[u8]) -> BinanceFuturesBookTickerMsg {
    serde_json::from_slice(raw).expect("valid Binance USD-M bookTicker fixture")
}

fn normalize(msg: &BinanceFuturesBookTickerMsg, instrument: &InstrumentAny) -> QuoteTick {
    parse_book_ticker(msg, instrument, TS_INIT).expect("bookTicker fixture should normalize")
}

fn assert_expected_message(msg: &BinanceFuturesBookTickerMsg) {
    assert_eq!(msg.event_type, "bookTicker");
    assert_eq!(msg.update_id, 10_708_444_522_016);
    assert_eq!(msg.symbol.as_str(), "BTCUSDT");
    assert_eq!(msg.best_bid_price, "63405.40");
    assert_eq!(msg.best_bid_qty, "4.629");
    assert_eq!(msg.best_ask_price, "63405.50");
    assert_eq!(msg.best_ask_qty, "2.357");
    assert_eq!(msg.transaction_time, 1_780_563_843_114);
    assert_eq!(msg.event_time, 1_780_563_843_114);
}

fn assert_expected_tick(tick: &QuoteTick) {
    assert_eq!(
        tick.instrument_id,
        InstrumentId::from("BTCUSDT-PERP.BINANCE")
    );
    assert_eq!(tick.bid_price, Price::from("63405.40"));
    assert_eq!(tick.ask_price, Price::from("63405.50"));
    assert_eq!(tick.bid_size, Quantity::from("4.629"));
    assert_eq!(tick.ask_size, Quantity::from("2.357"));
    assert_eq!(tick.ts_event, UnixNanos::from_millis(1_780_563_843_114));
    assert_eq!(tick.ts_init, TS_INIT);
}

fn bench_usdm_book_ticker(c: &mut Criterion) {
    let instrument = btcusdt_usdm_perpetual();
    let decoded = decode_message(BOOK_TICKER_JSON);
    assert_expected_message(&decoded);
    assert_expected_tick(&normalize(&decoded, &instrument));

    let mut group = c.benchmark_group("binance_usdm_book_ticker");
    group.throughput(Throughput::Elements(1));
    group.bench_function("parse_only", |b| {
        b.iter(|| {
            let msg = decode_message(black_box(BOOK_TICKER_JSON));
            black_box(msg);
        });
    });
    group.bench_function("parse_normalize", |b| {
        b.iter(|| {
            let msg = decode_message(black_box(BOOK_TICKER_JSON));
            let tick = normalize(&msg, black_box(&instrument));
            black_box(tick)
        });
    });
    group.finish();
}

criterion_group! {
    name = benches;
    config = Criterion::default()
        .warm_up_time(Duration::from_secs(1))
        .measurement_time(Duration::from_secs(3))
        .sample_size(100);
    targets = bench_usdm_book_ticker
}
criterion_main!(benches);
