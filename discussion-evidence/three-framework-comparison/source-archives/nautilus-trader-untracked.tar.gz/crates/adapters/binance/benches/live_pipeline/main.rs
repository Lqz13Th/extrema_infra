// -------------------------------------------------------------------------------------------------
//  Copyright (C) 2015-2026 Nautech Systems Pty Ltd. All rights reserved.
//  https://nautechsystems.io
//
//  Licensed under the GNU Lesser General Public License Version 3.0 (the "License");
//  You may not use this file except in compliance with the License.
//  You may obtain a copy of the License at https://www.gnu.org/licenses/lgpl-3.0.en.html
// -------------------------------------------------------------------------------------------------

#![recursion_limit = "512"]

mod support;

use std::{str::FromStr, time::Duration};

use serde_json::json;
use support::{
    LiveMode, LiveScenario, LiveTopology, PipelineConfig, PipelineReport, percentile, run_pipeline,
};

const DEFAULT_TASKS: usize = 5;
const DEFAULT_INSTRUMENTS_PER_TASK: usize = 20;
const DEFAULT_MESSAGES_PER_INSTRUMENT: usize = 256;
const DEFAULT_ORDER_EVERY: usize = 20;
const DEFAULT_REJECT_EVERY: usize = 10;
const DEFAULT_SIGNAL_COMPUTE_NS: u64 = 0;
const DEFAULT_WORKER_THREADS: usize = 16;
const DEFAULT_WARMUP_RUNS: usize = 1;
const DEFAULT_MEASURED_RUNS: usize = 5;
const DEFAULT_TIMEOUT_SECS: usize = 120;

fn main() -> anyhow::Result<()> {
    let worker_threads = positive_env("LIVE_WORKER_THREADS", DEFAULT_WORKER_THREADS)?;
    let runtime = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(worker_threads)
        .enable_all()
        .build()?;
    runtime.block_on(run(worker_threads))
}

async fn run(runtime_worker_threads: usize) -> anyhow::Result<()> {
    let topology = enum_env("LIVE_TOPOLOGY", LiveTopology::SharedHandler)?;
    let (default_tasks, default_instruments_per_task) = match topology {
        LiveTopology::Ws5Strategy20 => (20, 5),
        LiveTopology::SharedHandler | LiveTopology::BatchSharded => {
            (DEFAULT_TASKS, DEFAULT_INSTRUMENTS_PER_TASK)
        }
    };
    let config = PipelineConfig {
        tasks: positive_env("LIVE_TASKS", default_tasks)?,
        instruments_per_task: positive_env(
            "LIVE_INSTRUMENTS_PER_TASK",
            default_instruments_per_task,
        )?,
        messages_per_instrument: positive_env(
            "LIVE_MESSAGES_PER_INSTRUMENT",
            DEFAULT_MESSAGES_PER_INSTRUMENT,
        )?,
        topology,
        mode: enum_env("LIVE_MODE", LiveMode::Stress)?,
        order_every: positive_env("LIVE_ORDER_EVERY", DEFAULT_ORDER_EVERY)?,
        scenario: enum_env("LIVE_SCENARIO", LiveScenario::Success)?,
        reject_every: positive_env("LIVE_REJECT_EVERY", DEFAULT_REJECT_EVERY)?,
        signal_compute_ns: nonnegative_u64_env(
            "LIVE_SIGNAL_COMPUTE_NS",
            DEFAULT_SIGNAL_COMPUTE_NS,
        )?,
        timeout: Duration::from_secs(
            positive_env("LIVE_TIMEOUT_SECS", DEFAULT_TIMEOUT_SECS)? as u64
        ),
    };
    let warmup_runs = nonnegative_env("LIVE_WARMUP_RUNS", DEFAULT_WARMUP_RUNS)?;
    let measured_runs = positive_env("LIVE_MEASURED_RUNS", DEFAULT_MEASURED_RUNS)?;

    for _ in 0..warmup_runs {
        run_pipeline(config).await?.validate(config)?;
    }

    for run in 1..=measured_runs {
        let mut report = run_pipeline(config).await?;
        report.validate(config)?;
        report.sort_latencies();
        print_report(
            run,
            warmup_runs,
            measured_runs,
            runtime_worker_threads,
            config,
            &report,
        );
    }

    Ok(())
}

fn print_report(
    run: usize,
    warmup_runs: usize,
    measured_runs: usize,
    runtime_worker_threads: usize,
    config: PipelineConfig,
    report: &PipelineReport,
) {
    let (private_path, error_path, included) = match config.scenario {
        LiveScenario::Success => (
            "raw ORDER_TRADE_UPDATE -> BinanceFuturesOrderUpdateMsg decode -> production parse_exec -> benchmark correlation/dispatch bridge -> ExecutionEventEmitter -> native ACK/FILL callbacks",
            "not exercised",
            vec![
                "raw public JSON decode",
                "public normalization",
                "LiveNode data routing",
                "strategy callback",
                "native order submission",
                "raw ORDER_TRADE_UPDATE JSON decode",
                "production private report parsing",
                "native ACK/FILL callbacks",
            ],
        ),
        LiveScenario::BusinessError => (
            "successful orders use the success private path; rejected orders do not receive ORDER_TRADE_UPDATE",
            "raw code/msg/id -> BinanceFuturesWsErrorResponse decode -> benchmark current-submit correlation -> ExecutionEventEmitter rejection -> native rejection callback",
            vec![
                "raw public JSON decode",
                "public normalization",
                "LiveNode data routing",
                "strategy callback",
                "native order submission",
                "raw Binance business-error envelope decode",
                "production private report parsing for non-rejected orders",
                "native ACK/FILL/rejection callbacks",
            ],
        ),
    };
    let (
        trade_handler_kind,
        account_handler_kind,
        signal_handler_model,
        batch_isolation_model,
        account_owner_selection_model,
        private_fanout_model,
        public_ingress_model,
        private_ingress_model,
        overflow_model,
    ) = match config.topology {
        LiveTopology::SharedHandler => (
            "single_strategy_shared_subscription",
            "inline_owner_native_order_event",
            "one real Strategy subscribes to all configured instruments",
            "one OS thread + one current-thread Tokio runtime + one LiveNode",
            "the single originating Strategy owns every order",
            "each raw private frame produces one native owner order-event callback",
            "LIVE_TASKS producer tasks share one LiveNode DataEvent sender and yield cooperatively after every successful publish",
            "ExecutionClient decodes private frames inline during submit_order",
            "Nautilus internal DataEvent and ExecutionEvent channels are unbounded; source/callback conservation and timeout expose closure or loss",
        ),
        LiveTopology::BatchSharded => (
            "five_real_strategies_per_batch",
            "native_owner_plus_custom_non_owner",
            "five real Strategy handlers per batch; each subscribes to four instruments",
            "one OS thread + current-thread Tokio runtime + LiveNode per batch with unique trader/account/client/strategy identities",
            "each order is owned by its originating instrument Strategy, so owner selection varies across all five handlers rather than being fixed to handler zero",
            "each raw private frame is decoded once, then produces one native owner order-event callback plus four non-owner CustomData callbacks on its owner-specific topic",
            "twenty independent per-instrument Trade producer tasks per batch route to that batch LiveNode DataEvent sender and yield cooperatively after every successful publish",
            "one bounded cooperative AccountOrder mpsc consumer per batch; submit_order uses try_send and queue Full/Closed is fatal",
            "bounded AccountOrder ingress capacity 8192 uses try_send and treats Full/Closed as fatal; Nautilus internal DataEvent and ExecutionEvent channels are unbounded and guarded by conservation plus timeout",
        ),
        LiveTopology::Ws5Strategy20 => (
            "twenty_real_strategies_one_per_public_ws",
            "native_owner_plus_custom_non_owner",
            "twenty real Strategy handlers in one LiveNode; each subscribes to the five instruments owned by one logical public WS; signal callbacks are synchronously dispatched on the single LiveNode engine thread",
            "one OS thread + one current-thread Tokio runtime + one LiveNode for the complete 20-WS fanout domain",
            "each order is owned by the Strategy mapped to its originating public WS, so owner selection varies across all twenty handlers",
            "each raw private frame is decoded once, then produces one native owner order-event callback plus nineteen non-owner CustomData callbacks on its owner-specific topic",
            "twenty zero-network logical public WS producer tasks each multiplex five instruments in message-round order, share one LiveNode DataEvent sender, and yield cooperatively after every successful publish",
            "one bounded cooperative AccountOrder mpsc consumer for the complete fanout domain; submit_order uses try_send and queue Full/Closed is fatal",
            "bounded AccountOrder ingress capacity 8192 uses try_send and treats Full/Closed as fatal; Nautilus internal DataEvent and ExecutionEvent channels are unbounded and guarded by conservation plus timeout",
        ),
    };
    let result = json!({
        "framework": "nautilus_trader",
        "workload": "live_pipeline",
        "run": run,
        "warmup_runs": warmup_runs,
        "measured_runs": measured_runs,
        "runtime_worker_threads": runtime_worker_threads,
        "topology": report.topology.as_str(),
        "batch_count": report.batch_count,
        "live_nodes": report.live_nodes,
        "engine_threads": report.engine_threads,
        "physical_sockets": report.physical_sockets,
        "producer_tasks": report.producer_tasks,
        "public_ws_tasks": report.public_ws_tasks,
        "public_ws_tasks_per_fanout_domain": report.public_ws_tasks_per_fanout_domain,
        "symbols_per_public_ws": report.symbols_per_public_ws,
        "symbols_per_signal_handler": report.symbols_per_signal_handler,
        "trade_task_keys": report.trade_task_keys,
        "trade_lanes": report.trade_ingress_lanes,
        "trade_ingress_lanes": report.trade_ingress_lanes,
        "public_cooperative_yields": report.public_cooperative_yields,
        "public_producer_scheduling_model": "one explicit tokio::task::yield_now after every successful DataEvent publish",
        "signal_handlers": report.signal_handlers,
        "strategy_handlers": report.strategy_handlers,
        "trade_lanes_per_signal_handler": report.trade_lanes_per_signal_handler,
        "instruments_per_handler": report.instruments_per_handler,
        "account_ingress_tasks": report.account_ingress_tasks,
        "account_ingress_lanes": report.account_ingress_lanes,
        "account_broadcast_rings": report.account_broadcast_rings,
        "account_broadcast_topics": report.account_broadcast_topics,
        "account_fanout_domains": report.account_fanout_domains,
        "account_receivers_per_ring": report.account_receivers_per_ring,
        "account_handlers_per_fanout_domain": report.account_handlers_per_fanout_domain,
        "account_non_owner_subscribers_per_topic": report.account_non_owner_subscribers_per_topic,
        "broadcast_lag_observable": false,
        "account_owner_handlers": report.account_owner_handlers,
        "venue_handlers": report.venue_handlers,
        "order_runners": report.order_runners,
        "private_ingress_capacity": report.private_ingress_capacity,
        "trade_handler_kind": trade_handler_kind,
        "account_handler_kind": account_handler_kind,
        "signal_handler_model": signal_handler_model,
        "batch_isolation_model": batch_isolation_model,
        "account_owner_selection_model": account_owner_selection_model,
        "private_fanout_model": private_fanout_model,
        "public_ingress_model": public_ingress_model,
        "private_ingress_model": private_ingress_model,
        "overflow_model": overflow_model,
        "mode": config.mode.as_str(),
        "scenario": config.scenario.as_str(),
        "tasks": config.tasks,
        "instruments_per_task": config.instruments_per_task,
        "messages_per_instrument": config.messages_per_instrument,
        "order_every": config.order_every,
        "order_cadence": "per_instrument",
        "reject_every": config.reject_every,
        "total_ticks": report.total_ticks,
        "expected_orders": report.expected_orders,
        "expected_success_orders": report.expected_success_orders,
        "public_parsed": report.public_parsed,
        "trade_callbacks": report.trade_callbacks,
        "signal_compute_ns": report.signal_compute_ns,
        "signal_compute_calls": report.signal_compute_calls,
        "orders_submitted": report.orders_submitted,
        "private_frames_parsed": report.private_frames_parsed,
        "acks": report.acks,
        "fills": report.fills,
        "rejections": report.rejections,
        "drops": report.drops,
        "missing_correlations": report.drops,
        "duplicates": report.duplicates,
        "route_errors": report.route_errors,
        "business_errors": report.business_errors,
        "expected_account_callbacks": report.expected_account_callbacks,
        "account_observation_sources": report.account_observation_sources,
        "account_observation_callbacks": report.account_observation_callbacks,
        "native_owner_callbacks": report.native_owner_callbacks,
        "account_non_owner_callbacks": report.account_non_owner_callbacks,
        "cross_batch_errors": report.cross_batch_errors,
        "max_in_flight": report.max_in_flight,
        "ending_in_flight": report.ending_in_flight,
        "per_task_sent_min": report.per_task_sent_min,
        "per_task_sent_max": report.per_task_sent_max,
        "per_task_completed_min": report.per_task_completed_min,
        "per_task_completed_max": report.per_task_completed_max,
        "per_signal_trade_callbacks_min": report.per_signal_trade_callbacks_min,
        "per_signal_trade_callbacks_max": report.per_signal_trade_callbacks_max,
        "per_signal_private_callbacks_min": report.per_signal_private_callbacks_min,
        "per_signal_private_callbacks_max": report.per_signal_private_callbacks_max,
        "elapsed_ns": report.elapsed.as_nanos(),
        "wall_throughput_ticks_s": report.wall_throughput_ticks_s,
        "risk_commands": report.risk_commands,
        "execution_commands": report.execution_commands,
        "public_decode_ns": latency_json(&report.public_decode_ns),
        "tick_to_order_ns": latency_json(&report.tick_to_order_ns),
        "tick_to_ack_ns": latency_json(&report.tick_to_ack_ns),
        "tick_to_fill_ns": latency_json(&report.tick_to_fill_ns),
        "native_route": "LiveNode DataEvent -> owner Strategy::on_trade -> Strategy::submit_order -> ExecutionClient::submit_order -> ExecutionEventEmitter -> LiveNode execution engine -> owner strategy order callback",
        "order_route_detail": "LiveNode AsyncRunner routes the strategy command directly to the execution engine/client; RiskEngine is not traversed (validated by risk_commands=0)",
        "private_path": private_path,
        "error_path": error_path,
        "bridges": ["benchmark-local in-memory venue", "benchmark-local private frame correlation/dispatch; success reuses production Binance order-update structs and parse_exec"],
        "included": included,
        "excluded": ["TLS", "socket IO", "real exchange latency", "reconnect/backoff", "persistence", "PnL reporting"],
    });
    println!("LIVE_PIPELINE_RESULT {result}");
}

fn latency_json(samples: &[u64]) -> serde_json::Value {
    json!({
        "samples": samples.len(),
        "p50": percentile(samples, 0.50),
        "p95": percentile(samples, 0.95),
        "p99": percentile(samples, 0.99),
        "max": samples.last().copied().unwrap_or(0),
    })
}

fn positive_env(name: &str, default: usize) -> anyhow::Result<usize> {
    let value = match std::env::var(name) {
        Ok(raw) => raw
            .parse::<usize>()
            .map_err(|error| anyhow::anyhow!("invalid {name}='{raw}': {error}"))?,
        Err(std::env::VarError::NotPresent) => default,
        Err(error) => return Err(error.into()),
    };
    anyhow::ensure!(value > 0, "{name} must be greater than zero");
    Ok(value)
}

fn nonnegative_env(name: &str, default: usize) -> anyhow::Result<usize> {
    match std::env::var(name) {
        Ok(raw) => raw
            .parse::<usize>()
            .map_err(|error| anyhow::anyhow!("invalid {name}='{raw}': {error}")),
        Err(std::env::VarError::NotPresent) => Ok(default),
        Err(error) => Err(error.into()),
    }
}

fn nonnegative_u64_env(name: &str, default: u64) -> anyhow::Result<u64> {
    match std::env::var(name) {
        Ok(raw) => raw
            .parse::<u64>()
            .map_err(|error| anyhow::anyhow!("invalid {name}='{raw}': {error}")),
        Err(std::env::VarError::NotPresent) => Ok(default),
        Err(error) => Err(error.into()),
    }
}

fn enum_env<T>(name: &str, default: T) -> anyhow::Result<T>
where
    T: FromStr<Err = anyhow::Error>,
{
    match std::env::var(name) {
        Ok(raw) => raw.parse(),
        Err(std::env::VarError::NotPresent) => Ok(default),
        Err(error) => Err(error.into()),
    }
}
