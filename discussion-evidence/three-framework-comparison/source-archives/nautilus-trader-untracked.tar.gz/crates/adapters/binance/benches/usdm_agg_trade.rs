// -------------------------------------------------------------------------------------------------
//  Copyright (C) 2015-2026 Nautech Systems Pty Ltd. All rights reserved.
//  https://nautechsystems.io
//
//  Licensed under the GNU Lesser General Public License Version 3.0 (the "License");
//  You may not use this file except in compliance with the License.
//  You may obtain a copy of the License at https://www.gnu.org/licenses/lgpl-3.0.en.html
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// -------------------------------------------------------------------------------------------------

//! Binance USD-M aggregate-trade decode and normalization benchmarks.

use std::hint::black_box;

use criterion::{Criterion, Throughput, criterion_group, criterion_main};
use nautilus_binance::futures::websocket::streams::{
    messages::BinanceFuturesAggTradeMsg, parse_data::parse_agg_trade,
};
use nautilus_core::UnixNanos;
use nautilus_model::{
    data::TradeTick,
    enums::AggressorSide,
    identifiers::{InstrumentId, Symbol},
    instruments::{CryptoPerpetual, InstrumentAny},
    types::{Currency, Price, Quantity},
};

const AGG_TRADE_JSON: &[u8] = br#"{"e":"aggTrade","E":1735689600000,"s":"BTCUSDT","a":5933014,"p":"0.001","q":"100","f":100,"l":105,"T":1735689599996,"m":true}"#;
const TS_INIT: UnixNanos = UnixNanos::from_millis(1_735_689_600_000);

fn btcusdt_usdm_perpetual() -> InstrumentAny {
    InstrumentAny::CryptoPerpetual(CryptoPerpetual::new(
        InstrumentId::from("BTCUSDT-PERP.BINANCE"),
        Symbol::from("BTCUSDT"),
        Currency::from("BTC"),
        Currency::from("USDT"),
        Currency::from("USDT"),
        false,
        3,
        3,
        Price::from("0.001"),
        Quantity::from("0.001"),
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        UnixNanos::default(),
        UnixNanos::default(),
    ))
}

fn decode_message(raw: &[u8]) -> BinanceFuturesAggTradeMsg {
    serde_json::from_slice(raw).expect("valid Binance USD-M aggTrade fixture")
}

fn normalize(msg: &BinanceFuturesAggTradeMsg, instrument: &InstrumentAny) -> TradeTick {
    parse_agg_trade(msg, instrument, TS_INIT).expect("aggTrade fixture should normalize")
}

fn assert_expected_message(msg: &BinanceFuturesAggTradeMsg) {
    assert_eq!(msg.event_type, "aggTrade");
    assert_eq!(msg.event_time, 1_735_689_600_000);
    assert_eq!(msg.symbol.as_str(), "BTCUSDT");
    assert_eq!(msg.agg_trade_id, 5_933_014);
    assert_eq!(msg.price, "0.001");
    assert_eq!(msg.quantity, "100");
    assert_eq!(msg.first_trade_id, 100);
    assert_eq!(msg.last_trade_id, 105);
    assert_eq!(msg.trade_time, 1_735_689_599_996);
    assert!(msg.is_buyer_maker);
}

fn assert_expected_tick(tick: &TradeTick) {
    assert_eq!(
        tick.instrument_id,
        InstrumentId::from("BTCUSDT-PERP.BINANCE")
    );
    assert_eq!(tick.price, Price::from("0.001"));
    assert_eq!(tick.price.precision, 3);
    assert_eq!(tick.size, Quantity::from("100.000"));
    assert_eq!(tick.size.precision, 3);
    assert_eq!(tick.aggressor_side, AggressorSide::Seller);
    assert_eq!(tick.trade_id.as_str(), "5933014");
    assert_eq!(tick.ts_event, UnixNanos::from_millis(1_735_689_599_996));
    assert_eq!(tick.ts_init, TS_INIT);
}

fn bench_usdm_agg_trade(c: &mut Criterion) {
    let instrument = btcusdt_usdm_perpetual();
    let decoded = decode_message(AGG_TRADE_JSON);
    assert_expected_message(&decoded);
    assert_expected_tick(&normalize(&decoded, &instrument));

    let mut group = c.benchmark_group("binance_usdm_agg_trade");
    group.throughput(Throughput::Elements(1));

    group.bench_function("parse_normalize", |b| {
        b.iter(|| {
            let msg = decode_message(black_box(AGG_TRADE_JSON));
            let tick = normalize(&msg, black_box(&instrument));
            black_box(tick)
        });
    });

    group.bench_function("normalize_only", |b| {
        b.iter(|| {
            let tick = normalize(black_box(&decoded), black_box(&instrument));
            black_box(tick)
        });
    });

    group.finish();
}

criterion_group!(benches, bench_usdm_agg_trade);
criterion_main!(benches);
