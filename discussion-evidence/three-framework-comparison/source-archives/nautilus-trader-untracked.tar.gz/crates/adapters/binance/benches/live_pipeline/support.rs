// -------------------------------------------------------------------------------------------------
//  Copyright (C) 2015-2026 Nautech Systems Pty Ltd. All rights reserved.
//  https://nautechsystems.io
//
//  Licensed under the GNU Lesser General Public License Version 3.0 (the "License");
//  You may not use this file except in compliance with the License.
//  You may obtain a copy of the License at https://www.gnu.org/licenses/lgpl-3.0.en.html
// -------------------------------------------------------------------------------------------------

use std::{
    any::Any,
    collections::HashMap,
    fmt::Debug,
    str::FromStr,
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering},
        mpsc,
    },
    thread,
    time::{Duration, Instant},
};

use async_trait::async_trait;
use nautilus_binance::futures::websocket::streams::{
    messages::{
        BinanceFuturesAggTradeMsg, BinanceFuturesOrderUpdateMsg, BinanceFuturesWsErrorResponse,
    },
    parse_data::parse_agg_trade,
    parse_exec::{parse_futures_order_update_to_fill, parse_futures_order_update_to_order_status},
};
use nautilus_common::{
    actor::DataActor,
    cache::CacheView,
    clients::ExecutionClient,
    enums::Environment,
    factories::{ClientConfig, ExecutionClientFactory},
    live::runner::{get_data_event_sender, get_exec_event_sender},
    logging::logger::LoggerConfig,
    messages::{DataEvent, execution::SubmitOrder},
};
use nautilus_core::{Params, UnixNanos, time::get_atomic_clock_realtime};
use nautilus_live::{
    ExecutionEventEmitter,
    builder::LiveNodeBuilder,
    config::{LiveExecEngineConfig, LiveNodeConfig},
    node::{LiveNodeHandle, NodeState},
};
use nautilus_model::{
    accounts::AccountAny,
    data::{CustomData, CustomDataTrait, Data, DataType, HasTsInit, TradeTick},
    enums::{AccountType, CurrencyType, OmsType, OrderSide},
    events::{OrderAccepted, OrderFilled, OrderRejected},
    identifiers::{
        AccountId, ClientId, ClientOrderId, InstrumentId, StrategyId, Symbol, TradeId, TraderId,
        Venue,
    },
    instruments::{CryptoPerpetual, Instrument, InstrumentAny},
    orders::OrderAny,
    types::{AccountBalance, Currency, MarginBalance, Price, Quantity},
};
use nautilus_trading::{
    nautilus_strategy,
    strategy::{Strategy, StrategyConfig, StrategyCore},
};
use serde::Serialize;
use tokio::sync::{Barrier, Notify};

const CLIENT_ID: &str = "LIVE-PIPELINE-EXEC";
const ACCOUNT_ID: &str = "LIVE-PIPELINE-EXEC-001";
const STRATEGY_ID: &str = "LIVE-PIPELINE-STRATEGY-001";
const TRADER_ID: &str = "LIVE-PIPELINE-TRADER-001";
const ORDER_PREFIX: &str = "LP-ORDER-";
const ACCOUNT_OBSERVATION_TYPE: &str = "LivePipelineAccountObservation";
const BATCH_INSTRUMENTS: usize = 20;
const HANDLERS_PER_BATCH: usize = 5;
const INSTRUMENTS_PER_HANDLER: usize = 4;
const WS5_STRATEGY20_PUBLIC_WS_TASKS: usize = 20;
const WS5_STRATEGY20_SYMBOLS_PER_PUBLIC_WS: usize = 5;
const WS5_STRATEGY20_SIGNAL_HANDLERS: usize = 20;
const WS5_STRATEGY20_INSTRUMENTS: usize =
    WS5_STRATEGY20_PUBLIC_WS_TASKS * WS5_STRATEGY20_SYMBOLS_PER_PUBLIC_WS;
const PRIVATE_INGRESS_CAPACITY: usize = 8_192;
const EVENT_TIME_MS: i64 = 1_735_689_600_000;
const PRICE_PRECISION: u8 = 2;
const SIZE_PRECISION: u8 = 3;
const USD_M_SYMBOLS: &[&str] = &[
    "BTCUSDT",
    "ETHUSDT",
    "BNBUSDT",
    "SOLUSDT",
    "XRPUSDT",
    "DOGEUSDT",
    "ADAUSDT",
    "AVAXUSDT",
    "LINKUSDT",
    "DOTUSDT",
    "LTCUSDT",
    "BCHUSDT",
    "TRXUSDT",
    "SUIUSDT",
    "XLMUSDT",
    "HBARUSDT",
    "1000SHIBUSDT",
    "1000PEPEUSDT",
    "UNIUSDT",
    "NEARUSDT",
    "AAVEUSDT",
    "ETCUSDT",
    "ICPUSDT",
    "APTUSDT",
    "ATOMUSDT",
    "FILUSDT",
    "ARBUSDT",
    "OPUSDT",
    "INJUSDT",
    "TIAUSDT",
    "SEIUSDT",
    "WIFUSDT",
    "1000BONKUSDT",
    "1000FLOKIUSDT",
    "RENDERUSDT",
    "FETUSDT",
    "TAOUSDT",
    "GRTUSDT",
    "ALGOUSDT",
    "VETUSDT",
    "RUNEUSDT",
    "PENDLEUSDT",
    "JUPUSDT",
    "ENAUSDT",
    "STXUSDT",
    "MKRUSDT",
    "LDOUSDT",
    "IMXUSDT",
    "THETAUSDT",
    "SANDUSDT",
    "MANAUSDT",
    "GALAUSDT",
    "AXSUSDT",
    "CHZUSDT",
    "CRVUSDT",
    "DYDXUSDT",
    "SNXUSDT",
    "COMPUSDT",
    "ZECUSDT",
    "DASHUSDT",
    "EOSUSDT",
    "IOTAUSDT",
    "ZILUSDT",
    "KAVAUSDT",
    "ROSEUSDT",
    "MINAUSDT",
    "CELOUSDT",
    "ONEUSDT",
    "LRCUSDT",
    "MASKUSDT",
    "YFIUSDT",
    "SUSHIUSDT",
    "1INCHUSDT",
    "QTUMUSDT",
    "ONTUSDT",
    "NEOUSDT",
    "XTZUSDT",
    "EGLDUSDT",
    "KSMUSDT",
    "FLOWUSDT",
    "BLURUSDT",
    "STRKUSDT",
    "ZROUSDT",
    "WLDUSDT",
    "NOTUSDT",
    "JTOUSDT",
    "PYTHUSDT",
    "ORDIUSDT",
    "1000SATSUSDT",
    "PEOPLEUSDT",
    "MEMEUSDT",
    "ACEUSDT",
    "AIUSDT",
    "PORTALUSDT",
    "PIXELUSDT",
    "METISUSDT",
    "DYMUSDT",
    "MANTAUSDT",
    "ALTUSDT",
    "OMUSDT",
];

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum LiveMode {
    Stress,
    MixedLive,
}

impl LiveMode {
    pub(crate) const fn as_str(self) -> &'static str {
        match self {
            Self::Stress => "stress",
            Self::MixedLive => "mixed_live",
        }
    }
}

impl FromStr for LiveMode {
    type Err = anyhow::Error;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        match value.to_ascii_lowercase().as_str() {
            "stress" => Ok(Self::Stress),
            "mixed_live" => Ok(Self::MixedLive),
            _ => anyhow::bail!("LIVE_MODE must be stress or mixed_live"),
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum LiveScenario {
    Success,
    BusinessError,
}

impl LiveScenario {
    pub(crate) const fn as_str(self) -> &'static str {
        match self {
            Self::Success => "success",
            Self::BusinessError => "business_error",
        }
    }
}

impl FromStr for LiveScenario {
    type Err = anyhow::Error;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        match value.to_ascii_lowercase().as_str() {
            "success" => Ok(Self::Success),
            "business_error" => Ok(Self::BusinessError),
            _ => anyhow::bail!("LIVE_SCENARIO must be success or business_error"),
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(crate) enum LiveTopology {
    #[default]
    SharedHandler,
    BatchSharded,
    Ws5Strategy20,
}

impl LiveTopology {
    pub(crate) const fn as_str(self) -> &'static str {
        match self {
            Self::SharedHandler => "shared_handler",
            Self::BatchSharded => "batch_sharded",
            Self::Ws5Strategy20 => "ws5_strategy20",
        }
    }

    const fn batch_count(self, tasks: usize) -> usize {
        match self {
            Self::SharedHandler => 1,
            Self::BatchSharded => tasks,
            Self::Ws5Strategy20 => 1,
        }
    }

    const fn account_handlers_per_fanout_domain(self) -> usize {
        match self {
            Self::SharedHandler => 1,
            Self::BatchSharded => HANDLERS_PER_BATCH,
            Self::Ws5Strategy20 => WS5_STRATEGY20_SIGNAL_HANDLERS,
        }
    }

    const fn uses_bounded_account_ingress(self) -> bool {
        !matches!(self, Self::SharedHandler)
    }
}

impl FromStr for LiveTopology {
    type Err = anyhow::Error;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        match value.to_ascii_lowercase().as_str() {
            "shared_handler" => Ok(Self::SharedHandler),
            "batch_sharded" => Ok(Self::BatchSharded),
            "ws5_strategy20" => Ok(Self::Ws5Strategy20),
            _ => anyhow::bail!(
                "LIVE_TOPOLOGY must be shared_handler, batch_sharded, or ws5_strategy20"
            ),
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub(crate) struct PipelineConfig {
    pub tasks: usize,
    pub instruments_per_task: usize,
    pub messages_per_instrument: usize,
    pub topology: LiveTopology,
    pub mode: LiveMode,
    pub order_every: usize,
    pub scenario: LiveScenario,
    pub reject_every: usize,
    pub signal_compute_ns: u64,
    pub timeout: Duration,
}

impl PipelineConfig {
    fn total_instruments(self) -> anyhow::Result<usize> {
        self.tasks
            .checked_mul(self.instruments_per_task)
            .ok_or_else(|| anyhow::anyhow!("instrument count overflow"))
    }

    fn total_ticks(self) -> anyhow::Result<usize> {
        self.total_instruments()?
            .checked_mul(self.messages_per_instrument)
            .ok_or_else(|| anyhow::anyhow!("tick count overflow"))
    }

    fn should_order(self, message_index: usize) -> bool {
        self.mode == LiveMode::Stress || (message_index + 1).is_multiple_of(self.order_every)
    }

    fn expected_private_sources_by_task(self) -> anyhow::Result<Vec<usize>> {
        let ordered_messages = (0..self.messages_per_instrument)
            .filter(|&message_index| self.should_order(message_index))
            .count();
        let orders_per_task = ordered_messages
            .checked_mul(self.instruments_per_task)
            .ok_or_else(|| anyhow::anyhow!("orders per task overflow"))?;
        let mut sources = Vec::with_capacity(self.tasks);
        for task in 0..self.tasks {
            let first_order = task
                .checked_mul(orders_per_task)
                .ok_or_else(|| anyhow::anyhow!("task order offset overflow"))?;
            let order_end = first_order
                .checked_add(orders_per_task)
                .ok_or_else(|| anyhow::anyhow!("task order range overflow"))?;
            let rejections = if self.scenario == LiveScenario::BusinessError {
                (first_order..order_end)
                    .filter(|order_index| order_index.is_multiple_of(self.reject_every))
                    .count()
            } else {
                0
            };
            sources.push(
                orders_per_task
                    .checked_mul(2)
                    .and_then(|frames| frames.checked_sub(rejections))
                    .ok_or_else(|| anyhow::anyhow!("private source count overflow"))?,
            );
        }
        Ok(sources)
    }

    fn producer_tasks(self) -> anyhow::Result<usize> {
        match self.topology {
            LiveTopology::SharedHandler | LiveTopology::Ws5Strategy20 => Ok(self.tasks),
            LiveTopology::BatchSharded => self.total_instruments(),
        }
    }

    fn signal_handlers(self) -> anyhow::Result<usize> {
        match self.topology {
            LiveTopology::SharedHandler => Ok(1),
            LiveTopology::BatchSharded => self
                .topology
                .batch_count(self.tasks)
                .checked_mul(HANDLERS_PER_BATCH)
                .ok_or_else(|| anyhow::anyhow!("signal handler count overflow")),
            LiveTopology::Ws5Strategy20 => Ok(WS5_STRATEGY20_SIGNAL_HANDLERS),
        }
    }

    fn public_ws_tasks_per_fanout_domain(self) -> anyhow::Result<usize> {
        self.producer_tasks()?
            .checked_div(self.topology.batch_count(self.tasks))
            .ok_or_else(|| anyhow::anyhow!("public WS tasks per fanout domain division by zero"))
    }

    const fn symbols_per_public_ws(self) -> usize {
        match self.topology {
            LiveTopology::SharedHandler => self.instruments_per_task,
            LiveTopology::BatchSharded => 1,
            LiveTopology::Ws5Strategy20 => WS5_STRATEGY20_SYMBOLS_PER_PUBLIC_WS,
        }
    }

    fn symbols_per_signal_handler(self) -> anyhow::Result<usize> {
        match self.topology {
            LiveTopology::SharedHandler => self.total_instruments(),
            LiveTopology::BatchSharded => Ok(INSTRUMENTS_PER_HANDLER),
            LiveTopology::Ws5Strategy20 => Ok(WS5_STRATEGY20_SYMBOLS_PER_PUBLIC_WS),
        }
    }

    fn trade_lanes_per_signal_handler(self) -> anyhow::Result<usize> {
        match self.topology {
            LiveTopology::SharedHandler => self.total_instruments(),
            LiveTopology::BatchSharded => Ok(INSTRUMENTS_PER_HANDLER),
            LiveTopology::Ws5Strategy20 => Ok(1),
        }
    }

    const fn signal_handler_index(self, batch: usize, handler: usize) -> usize {
        match self.topology {
            LiveTopology::SharedHandler => 0,
            LiveTopology::BatchSharded => batch * HANDLERS_PER_BATCH + handler,
            LiveTopology::Ws5Strategy20 => handler,
        }
    }
}

#[derive(Clone, Debug, Default)]
pub(crate) struct PipelineReport {
    pub topology: LiveTopology,
    pub batch_count: usize,
    pub live_nodes: usize,
    pub engine_threads: usize,
    pub physical_sockets: usize,
    pub producer_tasks: usize,
    pub public_ws_tasks: usize,
    pub public_ws_tasks_per_fanout_domain: usize,
    pub symbols_per_public_ws: usize,
    pub symbols_per_signal_handler: usize,
    pub trade_task_keys: usize,
    pub trade_ingress_lanes: usize,
    pub public_cooperative_yields: usize,
    pub signal_handlers: usize,
    pub strategy_handlers: usize,
    pub trade_lanes_per_signal_handler: usize,
    pub instruments_per_handler: usize,
    pub account_ingress_tasks: usize,
    pub account_ingress_lanes: usize,
    pub account_broadcast_rings: usize,
    pub account_broadcast_topics: usize,
    pub account_fanout_domains: usize,
    pub account_receivers_per_ring: usize,
    pub account_handlers_per_fanout_domain: usize,
    pub account_non_owner_subscribers_per_topic: usize,
    pub account_owner_handlers: usize,
    pub venue_handlers: usize,
    pub order_runners: usize,
    pub private_ingress_capacity: usize,
    pub total_ticks: usize,
    pub expected_orders: usize,
    pub expected_success_orders: usize,
    pub public_parsed: usize,
    pub trade_callbacks: usize,
    pub signal_compute_ns: u64,
    pub signal_compute_calls: usize,
    pub orders_submitted: usize,
    pub private_frames_parsed: usize,
    pub acks: usize,
    pub fills: usize,
    pub rejections: usize,
    pub drops: usize,
    pub duplicates: usize,
    pub route_errors: usize,
    pub business_errors: usize,
    pub expected_account_callbacks: usize,
    pub account_observation_sources: usize,
    pub account_observation_callbacks: usize,
    pub native_owner_callbacks: usize,
    pub account_non_owner_callbacks: usize,
    pub cross_batch_errors: usize,
    pub max_in_flight: usize,
    pub ending_in_flight: usize,
    pub per_task_sent_min: usize,
    pub per_task_sent_max: usize,
    pub per_task_completed_min: usize,
    pub per_task_completed_max: usize,
    pub per_signal_trade_callbacks_min: usize,
    pub per_signal_trade_callbacks_max: usize,
    pub per_signal_private_callbacks_min: usize,
    pub per_signal_private_callbacks_max: usize,
    pub elapsed: Duration,
    pub wall_throughput_ticks_s: f64,
    pub public_decode_ns: Vec<u64>,
    pub tick_to_order_ns: Vec<u64>,
    pub tick_to_ack_ns: Vec<u64>,
    pub tick_to_fill_ns: Vec<u64>,
    pub risk_commands: u64,
    pub execution_commands: u64,
}

impl PipelineReport {
    pub(crate) fn sort_latencies(&mut self) {
        self.public_decode_ns.sort_unstable();
        self.tick_to_order_ns.sort_unstable();
        self.tick_to_ack_ns.sort_unstable();
        self.tick_to_fill_ns.sort_unstable();
    }

    pub(crate) fn validate(&self, config: PipelineConfig) -> anyhow::Result<()> {
        let expected_ticks = config.total_ticks()?;
        let expected_private = self.expected_success_orders * 2 + self.business_errors;
        let expected_account_callbacks =
            expected_private * config.topology.account_handlers_per_fanout_domain();
        let expected_private_by_task = config.expected_private_sources_by_task()?;
        anyhow::ensure!(
            expected_private_by_task.iter().sum::<usize>() == expected_private,
            "configured private source count mismatch"
        );
        let batch_count = config.topology.batch_count(config.tasks);
        let producer_tasks = config.producer_tasks()?;
        let signal_handlers = config.signal_handlers()?;
        let public_ws_tasks_per_fanout_domain = config.public_ws_tasks_per_fanout_domain()?;
        let symbols_per_signal_handler = config.symbols_per_signal_handler()?;
        let trade_lanes_per_signal_handler = config.trade_lanes_per_signal_handler()?;
        let expected_signal_trade_callbacks = symbols_per_signal_handler
            .checked_mul(config.messages_per_instrument)
            .ok_or_else(|| anyhow::anyhow!("signal trade callback count overflow"))?;
        let (expected_signal_private_min, expected_signal_private_max) =
            if config.topology == LiveTopology::BatchSharded {
                (
                    expected_private_by_task.iter().copied().min().unwrap_or(0),
                    expected_private_by_task.iter().copied().max().unwrap_or(0),
                )
            } else {
                (expected_private, expected_private)
            };
        anyhow::ensure!(self.topology == config.topology, "topology mismatch");
        anyhow::ensure!(!self.topology.as_str().is_empty(), "empty topology name");
        anyhow::ensure!(self.batch_count == batch_count, "batch count mismatch");
        anyhow::ensure!(
            self.live_nodes == batch_count
                && self.engine_threads == batch_count
                && self.physical_sockets == 0,
            "engine topology count mismatch"
        );
        anyhow::ensure!(
            self.producer_tasks == producer_tasks
                && self.public_ws_tasks == producer_tasks
                && self.public_ws_tasks_per_fanout_domain == public_ws_tasks_per_fanout_domain
                && self.symbols_per_public_ws == config.symbols_per_public_ws()
                && self.symbols_per_signal_handler == symbols_per_signal_handler
                && self.trade_task_keys == 0
                && self.trade_ingress_lanes == producer_tasks,
            "public ingress topology mismatch"
        );
        anyhow::ensure!(
            self.public_cooperative_yields == expected_ticks,
            "public producer cooperative-yield mismatch"
        );
        anyhow::ensure!(
            self.signal_handlers == signal_handlers
                && self.strategy_handlers == signal_handlers
                && self.account_owner_handlers == signal_handlers,
            "strategy handler topology mismatch"
        );
        anyhow::ensure!(
            self.trade_lanes_per_signal_handler == trade_lanes_per_signal_handler
                && self.instruments_per_handler == symbols_per_signal_handler,
            "strategy instrument ownership mismatch"
        );
        anyhow::ensure!(
            self.per_signal_trade_callbacks_min == expected_signal_trade_callbacks
                && self.per_signal_trade_callbacks_max == expected_signal_trade_callbacks,
            "per-strategy trade callback distribution mismatch"
        );
        anyhow::ensure!(
            self.per_signal_private_callbacks_min == expected_signal_private_min
                && self.per_signal_private_callbacks_max == expected_signal_private_max,
            "per-strategy private callback distribution mismatch"
        );
        let bounded_account_ingress = config.topology.uses_bounded_account_ingress();
        let handlers_per_fanout_domain = config.topology.account_handlers_per_fanout_domain();
        anyhow::ensure!(
            self.account_ingress_tasks
                == if bounded_account_ingress {
                    batch_count
                } else {
                    0
                }
                && self.account_ingress_lanes == batch_count
                && self.order_runners
                    == if bounded_account_ingress {
                        batch_count
                    } else {
                        0
                    },
            "account ingress topology mismatch"
        );
        anyhow::ensure!(
            self.account_broadcast_rings == 0
                && self.account_broadcast_topics
                    == if bounded_account_ingress {
                        signal_handlers
                    } else {
                        0
                    }
                && self.account_fanout_domains == batch_count
                && self.account_receivers_per_ring == 0
                && self.account_handlers_per_fanout_domain == handlers_per_fanout_domain
                && self.account_non_owner_subscribers_per_topic
                    == if bounded_account_ingress {
                        handlers_per_fanout_domain - 1
                    } else {
                        0
                    },
            "account fanout topology mismatch"
        );
        anyhow::ensure!(
            self.venue_handlers == batch_count
                && self.private_ingress_capacity
                    == if bounded_account_ingress {
                        PRIVATE_INGRESS_CAPACITY
                    } else {
                        0
                    },
            "venue handler topology mismatch"
        );
        anyhow::ensure!(self.total_ticks == expected_ticks, "total tick mismatch");
        anyhow::ensure!(self.public_parsed == expected_ticks, "public decode loss");
        anyhow::ensure!(
            self.trade_callbacks == expected_ticks,
            "trade callback loss"
        );
        anyhow::ensure!(
            self.signal_compute_ns == config.signal_compute_ns,
            "signal compute duration mismatch"
        );
        anyhow::ensure!(
            self.signal_compute_calls == expected_ticks,
            "signal compute call loss"
        );
        anyhow::ensure!(
            self.orders_submitted == self.expected_orders,
            "order endpoint loss"
        );
        anyhow::ensure!(
            self.private_frames_parsed == expected_private,
            "private frame conservation mismatch"
        );
        anyhow::ensure!(self.acks == self.expected_success_orders, "ACK loss");
        anyhow::ensure!(self.fills == self.expected_success_orders, "fill loss");
        anyhow::ensure!(
            self.rejections == self.business_errors,
            "business rejection callback loss"
        );
        anyhow::ensure!(self.drops == 0, "pipeline drops observed");
        anyhow::ensure!(self.duplicates == 0, "duplicate correlations observed");
        anyhow::ensure!(self.route_errors == 0, "route mismatch observed");
        anyhow::ensure!(
            self.cross_batch_errors == 0,
            "cross-batch route mismatch observed"
        );
        anyhow::ensure!(
            self.account_observation_sources == expected_private,
            "account observation source mismatch"
        );
        anyhow::ensure!(
            self.expected_account_callbacks == expected_account_callbacks,
            "expected account callback count mismatch"
        );
        anyhow::ensure!(
            self.account_observation_callbacks == expected_account_callbacks,
            "account callback conservation mismatch"
        );
        anyhow::ensure!(
            self.native_owner_callbacks == expected_private,
            "native owner callback mismatch"
        );
        let expected_non_owner = if bounded_account_ingress {
            expected_private * (handlers_per_fanout_domain - 1)
        } else {
            0
        };
        anyhow::ensure!(
            self.account_non_owner_callbacks == expected_non_owner,
            "non-owner observation callback mismatch"
        );
        anyhow::ensure!(self.ending_in_flight == 0, "orders remained in flight");
        anyhow::ensure!(
            self.public_decode_ns.len() == expected_ticks,
            "public latency sample loss"
        );
        anyhow::ensure!(
            self.tick_to_order_ns.len() == self.expected_orders,
            "order latency sample loss"
        );
        anyhow::ensure!(
            self.tick_to_ack_ns.len() == self.expected_success_orders,
            "ACK latency sample loss"
        );
        anyhow::ensure!(
            self.tick_to_fill_ns.len() == self.expected_success_orders,
            "fill latency sample loss"
        );
        anyhow::ensure!(
            self.execution_commands == self.expected_orders as u64,
            "execution engine command count mismatch"
        );
        anyhow::ensure!(
            self.risk_commands == 0,
            "orders unexpectedly used RiskEngine"
        );
        anyhow::ensure!(self.elapsed > Duration::ZERO, "wall duration was zero");
        for (name, samples) in [
            ("public decode", &self.public_decode_ns),
            ("tick-to-order", &self.tick_to_order_ns),
            ("tick-to-ACK", &self.tick_to_ack_ns),
            ("tick-to-fill", &self.tick_to_fill_ns),
        ] {
            let max_sample = samples.iter().copied().max().unwrap_or(0);
            anyhow::ensure!(
                u128::from(max_sample) <= self.elapsed.as_nanos(),
                "{name} latency exceeded wall duration"
            );
        }
        if config.scenario == LiveScenario::Success {
            anyhow::ensure!(self.business_errors == 0, "unexpected business errors");
            anyhow::ensure!(
                self.expected_orders == self.expected_success_orders,
                "success scenario rejected orders"
            );
        } else {
            anyhow::ensure!(
                self.business_errors > 0,
                "business error scenario injected no errors"
            );
        }
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
enum AccountObservationKind {
    Accepted,
    Filled,
    Rejected,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
struct AccountObservation {
    observation_index: usize,
    batch: usize,
    owner_handler: usize,
    order_index: usize,
    client_order_id: ClientOrderId,
    kind: AccountObservationKind,
    ts_event: UnixNanos,
    ts_init: UnixNanos,
}

impl HasTsInit for AccountObservation {
    fn ts_init(&self) -> UnixNanos {
        self.ts_init
    }
}

impl CustomDataTrait for AccountObservation {
    fn type_name(&self) -> &'static str {
        ACCOUNT_OBSERVATION_TYPE
    }

    fn as_any(&self) -> &dyn Any {
        self
    }

    fn ts_event(&self) -> UnixNanos {
        self.ts_event
    }

    fn to_json(&self) -> anyhow::Result<String> {
        Ok(serde_json::to_string(self)?)
    }

    fn clone_arc(&self) -> Arc<dyn CustomDataTrait> {
        Arc::new(self.clone())
    }

    fn eq_arc(&self, other: &dyn CustomDataTrait) -> bool {
        other.as_any().downcast_ref::<Self>() == Some(self)
    }
}

fn account_observation_data_type(batch: usize, owner_handler: usize) -> DataType {
    let mut metadata = Params::new();
    metadata.insert("batch".to_string(), serde_json::json!(batch));
    metadata.insert(
        "owner_handler".to_string(),
        serde_json::json!(owner_handler),
    );
    DataType::new(ACCOUNT_OBSERVATION_TYPE, Some(metadata), None)
}

#[derive(Clone, Debug)]
struct TickSpec {
    task: usize,
    batch: usize,
    handler: usize,
    strategy_id: StrategyId,
    instrument_index: usize,
    instrument_id: InstrumentId,
    trade_id: TradeId,
    order_index: Option<usize>,
    raw_public: Vec<u8>,
}

#[derive(Clone, Debug)]
struct OrderSpec {
    batch: usize,
    owner_handler: usize,
    strategy_id: StrategyId,
    tick_correlation: usize,
    instrument_id: InstrumentId,
    client_order_id: ClientOrderId,
    reject: bool,
    raw_ack: Vec<u8>,
    raw_fill: Vec<u8>,
    raw_reject: Vec<u8>,
    ack_observation_index: Option<usize>,
    fill_observation_index: Option<usize>,
    reject_observation_index: Option<usize>,
}

#[derive(Debug)]
struct BenchmarkState {
    epoch: Instant,
    config: PipelineConfig,
    instruments: Vec<InstrumentAny>,
    ticks: Vec<TickSpec>,
    orders: Vec<OrderSpec>,
    tick_by_trade_id: HashMap<TradeId, usize>,
    order_by_client_id: HashMap<ClientOrderId, usize>,
    phase_start_ns: AtomicU64,
    phase_end_ns: AtomicU64,
    t0_ns: Vec<AtomicU64>,
    t_public_ns: Vec<AtomicU64>,
    t_order_ns: Vec<AtomicU64>,
    t_ack_ns: Vec<AtomicU64>,
    t_fill_ns: Vec<AtomicU64>,
    public_seen: Vec<AtomicBool>,
    trade_seen: Vec<AtomicBool>,
    completed_seen: Vec<AtomicBool>,
    order_seen: Vec<AtomicBool>,
    ack_seen: Vec<AtomicBool>,
    fill_seen: Vec<AtomicBool>,
    reject_seen: Vec<AtomicBool>,
    observation_source_seen: Vec<AtomicBool>,
    observation_delivery_seen: Vec<AtomicBool>,
    public_parsed: AtomicUsize,
    trade_callbacks: AtomicUsize,
    signal_compute_calls: AtomicUsize,
    orders_submitted: AtomicUsize,
    private_frames_parsed: AtomicUsize,
    ack_callbacks: AtomicUsize,
    fill_callbacks: AtomicUsize,
    reject_callbacks: AtomicUsize,
    business_errors: AtomicUsize,
    account_observation_sources: AtomicUsize,
    account_observation_callbacks: AtomicUsize,
    account_non_owner_callbacks: AtomicUsize,
    cross_batch_errors: AtomicUsize,
    public_cooperative_yields: AtomicUsize,
    completed_ticks: AtomicUsize,
    duplicates: AtomicUsize,
    route_errors: AtomicUsize,
    in_flight: AtomicUsize,
    max_in_flight: AtomicUsize,
    task_sent: Vec<AtomicUsize>,
    task_completed: Vec<AtomicUsize>,
    trade_callbacks_by_signal_handler: Vec<AtomicUsize>,
    private_callbacks_by_signal_handler: Vec<AtomicUsize>,
    all_completed: Notify,
    fatal: AtomicBool,
    fatal_message: Mutex<Option<String>>,
    fatal_notify: Notify,
}

impl BenchmarkState {
    fn new(config: PipelineConfig) -> anyhow::Result<Self> {
        validate_config(config)?;
        let total_instruments = config.total_instruments()?;
        let signal_handler_count = config.signal_handlers()?;
        let instruments = build_instruments(total_instruments);
        let (ticks, orders) = build_fixtures(config, &instruments)?;
        let tick_by_trade_id = ticks
            .iter()
            .enumerate()
            .map(|(index, spec)| (spec.trade_id, index))
            .collect();
        let order_by_client_id = orders
            .iter()
            .enumerate()
            .map(|(index, spec)| (spec.client_order_id, index))
            .collect();
        let tick_count = ticks.len();
        let order_count = orders.len();
        let observation_source_count = orders
            .iter()
            .map(|spec| usize::from(spec.reject) + usize::from(!spec.reject) * 2)
            .sum::<usize>();
        let observation_delivery_count = observation_source_count
            .checked_mul(config.topology.account_handlers_per_fanout_domain())
            .ok_or_else(|| anyhow::anyhow!("account observation delivery count overflow"))?;
        Ok(Self {
            epoch: Instant::now(),
            config,
            instruments,
            ticks,
            orders,
            tick_by_trade_id,
            order_by_client_id,
            phase_start_ns: AtomicU64::new(0),
            phase_end_ns: AtomicU64::new(0),
            t0_ns: atomic_u64_vec(tick_count),
            t_public_ns: atomic_u64_vec(tick_count),
            t_order_ns: atomic_u64_vec(order_count),
            t_ack_ns: atomic_u64_vec(order_count),
            t_fill_ns: atomic_u64_vec(order_count),
            public_seen: atomic_bool_vec(tick_count),
            trade_seen: atomic_bool_vec(tick_count),
            completed_seen: atomic_bool_vec(tick_count),
            order_seen: atomic_bool_vec(order_count),
            ack_seen: atomic_bool_vec(order_count),
            fill_seen: atomic_bool_vec(order_count),
            reject_seen: atomic_bool_vec(order_count),
            observation_source_seen: atomic_bool_vec(observation_source_count),
            observation_delivery_seen: atomic_bool_vec(observation_delivery_count),
            public_parsed: AtomicUsize::new(0),
            trade_callbacks: AtomicUsize::new(0),
            signal_compute_calls: AtomicUsize::new(0),
            orders_submitted: AtomicUsize::new(0),
            private_frames_parsed: AtomicUsize::new(0),
            ack_callbacks: AtomicUsize::new(0),
            fill_callbacks: AtomicUsize::new(0),
            reject_callbacks: AtomicUsize::new(0),
            business_errors: AtomicUsize::new(0),
            account_observation_sources: AtomicUsize::new(0),
            account_observation_callbacks: AtomicUsize::new(0),
            account_non_owner_callbacks: AtomicUsize::new(0),
            cross_batch_errors: AtomicUsize::new(0),
            public_cooperative_yields: AtomicUsize::new(0),
            completed_ticks: AtomicUsize::new(0),
            duplicates: AtomicUsize::new(0),
            route_errors: AtomicUsize::new(0),
            in_flight: AtomicUsize::new(0),
            max_in_flight: AtomicUsize::new(0),
            task_sent: atomic_usize_vec(config.tasks),
            task_completed: atomic_usize_vec(config.tasks),
            trade_callbacks_by_signal_handler: atomic_usize_vec(signal_handler_count),
            private_callbacks_by_signal_handler: atomic_usize_vec(signal_handler_count),
            all_completed: Notify::new(),
            fatal: AtomicBool::new(false),
            fatal_message: Mutex::new(None),
            fatal_notify: Notify::new(),
        })
    }

    fn monotonic_ns(&self) -> u64 {
        self.epoch.elapsed().as_nanos().min(u128::from(u64::MAX)) as u64
    }

    fn set_fatal(&self, message: impl Into<String>) {
        if self.fatal.swap(true, Ordering::AcqRel) {
            return;
        }
        *self.fatal_message.lock().expect("fatal mutex poisoned") = Some(message.into());
        self.fatal_notify.notify_waiters();
        self.fatal_notify.notify_one();
    }

    fn check_fatal(&self) -> anyhow::Result<()> {
        if !self.fatal.load(Ordering::Acquire) {
            return Ok(());
        }
        let message = self
            .fatal_message
            .lock()
            .expect("fatal mutex poisoned")
            .clone()
            .unwrap_or_else(|| "live pipeline entered fatal state".to_string());
        anyhow::bail!(message)
    }

    fn mark_duplicate(&self, context: &str, correlation: usize) {
        self.duplicates.fetch_add(1, Ordering::Relaxed);
        self.set_fatal(format!("duplicate {context} correlation {correlation}"));
    }

    fn prepare_public_start(&self, correlation: usize) -> anyhow::Result<()> {
        anyhow::ensure!(
            self.phase_start_ns.load(Ordering::Acquire) > 0,
            "public producer started before phase boundary"
        );
        if self.t0_ns[correlation]
            .compare_exchange(0, u64::MAX, Ordering::AcqRel, Ordering::Acquire)
            .is_err()
        {
            self.mark_duplicate("public start", correlation);
            anyhow::bail!("duplicate public start");
        }
        self.task_sent[self.ticks[correlation].task].fetch_add(1, Ordering::Relaxed);
        Ok(())
    }

    fn record_public_start(&self, correlation: usize, entry_ns: u64) {
        self.t0_ns[correlation].store(entry_ns, Ordering::Release);
    }

    fn record_public_decoded(&self, correlation: usize, entry_ns: u64) {
        self.t_public_ns[correlation].store(entry_ns, Ordering::Release);
        self.public_parsed.fetch_add(1, Ordering::Relaxed);
        if self.public_seen[correlation].swap(true, Ordering::AcqRel) {
            self.mark_duplicate("public", correlation);
        }
    }

    fn record_trade_callback(
        &self,
        batch: usize,
        handler: usize,
        strategy_id: StrategyId,
        correlation: usize,
        tick: &TradeTick,
    ) -> anyhow::Result<()> {
        self.trade_callbacks.fetch_add(1, Ordering::Relaxed);
        if self.trade_seen[correlation].swap(true, Ordering::AcqRel) {
            self.mark_duplicate("trade", correlation);
            anyhow::bail!("duplicate strategy trade callback");
        }
        let spec = &self.ticks[correlation];
        if batch != spec.batch {
            self.cross_batch_errors.fetch_add(1, Ordering::Relaxed);
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            self.set_fatal(format!(
                "trade crossed from batch {} to {batch} for correlation {correlation}",
                spec.batch
            ));
            anyhow::bail!("cross-batch trade route mismatch");
        }
        if handler != spec.handler
            || strategy_id != spec.strategy_id
            || tick.instrument_id != spec.instrument_id
            || tick.trade_id != spec.trade_id
        {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            self.set_fatal(format!(
                "trade route mismatch for correlation {correlation}"
            ));
            anyhow::bail!("trade route mismatch");
        }
        let signal_counter_index = self.config.signal_handler_index(batch, handler);
        self.trade_callbacks_by_signal_handler[signal_counter_index]
            .fetch_add(1, Ordering::Relaxed);
        Ok(())
    }

    fn run_signal_compute(&self) {
        if self.config.signal_compute_ns > 0 {
            let started = Instant::now();
            while started.elapsed().as_nanos() < u128::from(self.config.signal_compute_ns) {
                std::hint::spin_loop();
            }
        }
        self.signal_compute_calls.fetch_add(1, Ordering::Relaxed);
    }

    fn record_order_entry(
        &self,
        batch: usize,
        cmd: &SubmitOrder,
        entry_ns: u64,
    ) -> anyhow::Result<usize> {
        let Some(order_index) = self.order_by_client_id.get(&cmd.client_order_id).copied() else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            anyhow::bail!("unknown client order ID {}", cmd.client_order_id);
        };
        let spec = &self.orders[order_index];
        if batch != spec.batch {
            self.cross_batch_errors.fetch_add(1, Ordering::Relaxed);
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            anyhow::bail!(
                "order crossed from batch {} to {batch} for order {order_index}",
                spec.batch
            );
        }
        if cmd.instrument_id != spec.instrument_id
            || cmd.strategy_id != spec.strategy_id
            || cmd.client_id != Some(benchmark_client_id(self.config.topology, batch))
            || cmd.trader_id != benchmark_trader_id(self.config.topology, batch)
        {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            anyhow::bail!("execution owner route mismatch for order {order_index}");
        }
        if self.order_seen[order_index].swap(true, Ordering::AcqRel) {
            self.mark_duplicate("order", order_index);
            anyhow::bail!("duplicate order endpoint call");
        }
        self.t_order_ns[order_index].store(entry_ns, Ordering::Release);
        self.orders_submitted.fetch_add(1, Ordering::Relaxed);
        let in_flight = self.in_flight.fetch_add(1, Ordering::AcqRel) + 1;
        self.max_in_flight.fetch_max(in_flight, Ordering::AcqRel);
        Ok(order_index)
    }

    fn record_private_source(
        &self,
        observation_index: usize,
        batch: usize,
        order_index: usize,
        kind: AccountObservationKind,
        ts_event: UnixNanos,
    ) -> anyhow::Result<AccountObservation> {
        let Some(spec) = self.orders.get(order_index) else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            anyhow::bail!("unknown private source order index {order_index}");
        };
        if batch != spec.batch {
            self.cross_batch_errors.fetch_add(1, Ordering::Relaxed);
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            anyhow::bail!(
                "private source crossed from batch {} to {batch} for order {order_index}",
                spec.batch
            );
        }
        let expected_index = match kind {
            AccountObservationKind::Accepted => spec.ack_observation_index,
            AccountObservationKind::Filled => spec.fill_observation_index,
            AccountObservationKind::Rejected => spec.reject_observation_index,
        };
        if expected_index != Some(observation_index) {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            anyhow::bail!("private source kind/index mismatch for order {order_index}");
        }
        let Some(seen) = self.observation_source_seen.get(observation_index) else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            anyhow::bail!("private source observation index out of bounds");
        };
        if seen.swap(true, Ordering::AcqRel) {
            self.mark_duplicate("private source", observation_index);
            anyhow::bail!("duplicate private source frame");
        }
        self.private_frames_parsed.fetch_add(1, Ordering::Relaxed);
        self.account_observation_sources
            .fetch_add(1, Ordering::Relaxed);
        Ok(AccountObservation {
            observation_index,
            batch,
            owner_handler: spec.owner_handler,
            order_index,
            client_order_id: spec.client_order_id,
            kind,
            ts_event,
            ts_init: get_atomic_clock_realtime().get_time_ns(),
        })
    }

    fn mark_account_delivery(
        &self,
        observation_index: usize,
        batch: usize,
        handler: usize,
        owner_handler: usize,
        native_owner: bool,
    ) -> anyhow::Result<()> {
        if !self
            .observation_source_seen
            .get(observation_index)
            .is_some_and(|seen| seen.load(Ordering::Acquire))
        {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            anyhow::bail!("account delivery preceded its private source");
        }
        let handlers = self.config.topology.account_handlers_per_fanout_domain();
        let delivery_slot = if self.config.topology == LiveTopology::SharedHandler {
            if batch != 0 || handler != 0 || owner_handler != 0 || !native_owner {
                self.route_errors.fetch_add(1, Ordering::Relaxed);
                anyhow::bail!("shared handler account delivery route mismatch");
            }
            observation_index
        } else {
            if batch >= self.config.topology.batch_count(self.config.tasks) {
                self.cross_batch_errors.fetch_add(1, Ordering::Relaxed);
                self.route_errors.fetch_add(1, Ordering::Relaxed);
                anyhow::bail!("account delivery batch out of bounds");
            }
            if handler >= handlers {
                self.route_errors.fetch_add(1, Ordering::Relaxed);
                anyhow::bail!("handler out of bounds");
            }
            if native_owner != (handler == owner_handler) {
                self.route_errors.fetch_add(1, Ordering::Relaxed);
                anyhow::bail!("native/custom account owner split mismatch");
            }
            observation_index
                .checked_mul(handlers)
                .and_then(|offset| offset.checked_add(handler))
                .ok_or_else(|| anyhow::anyhow!("account delivery slot overflow"))?
        };
        let Some(seen) = self.observation_delivery_seen.get(delivery_slot) else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            anyhow::bail!("account delivery slot out of bounds");
        };
        if seen.swap(true, Ordering::AcqRel) {
            self.mark_duplicate("account delivery", delivery_slot);
            anyhow::bail!("duplicate account delivery");
        }
        let signal_counter_index = self.config.signal_handler_index(batch, handler);
        self.private_callbacks_by_signal_handler[signal_counter_index]
            .fetch_add(1, Ordering::Relaxed);
        self.account_observation_callbacks
            .fetch_add(1, Ordering::Relaxed);
        if !native_owner {
            self.account_non_owner_callbacks
                .fetch_add(1, Ordering::Relaxed);
        }
        self.try_finish_phase();
        Ok(())
    }

    fn record_non_owner_observation(
        &self,
        batch: usize,
        handler: usize,
        observation: &AccountObservation,
    ) -> anyhow::Result<()> {
        let Some(spec) = self.orders.get(observation.order_index) else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            anyhow::bail!("unknown account observation order index");
        };
        if observation.batch != batch || observation.batch != spec.batch {
            self.cross_batch_errors.fetch_add(1, Ordering::Relaxed);
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            anyhow::bail!("cross-batch account observation route mismatch");
        }
        let expected_index = match observation.kind {
            AccountObservationKind::Accepted => spec.ack_observation_index,
            AccountObservationKind::Filled => spec.fill_observation_index,
            AccountObservationKind::Rejected => spec.reject_observation_index,
        };
        if expected_index != Some(observation.observation_index)
            || observation.owner_handler != spec.owner_handler
            || observation.client_order_id != spec.client_order_id
            || handler == spec.owner_handler
        {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            anyhow::bail!("non-owner account observation route mismatch");
        }
        self.mark_account_delivery(
            observation.observation_index,
            batch,
            handler,
            observation.owner_handler,
            false,
        )
    }

    fn record_native_owner_delivery(
        &self,
        order_index: usize,
        batch: usize,
        handler: usize,
        kind: AccountObservationKind,
    ) -> anyhow::Result<()> {
        let spec = &self.orders[order_index];
        let observation_index = match kind {
            AccountObservationKind::Accepted => spec.ack_observation_index,
            AccountObservationKind::Filled => spec.fill_observation_index,
            AccountObservationKind::Rejected => spec.reject_observation_index,
        }
        .ok_or_else(|| anyhow::anyhow!("native owner callback kind mismatch"))?;
        self.mark_account_delivery(observation_index, batch, handler, spec.owner_handler, true)
    }

    fn record_ack_callback(
        &self,
        batch: usize,
        handler: usize,
        strategy_id: StrategyId,
        event: &OrderAccepted,
        entry_ns: u64,
    ) {
        let Some(order_index) = self.order_by_client_id.get(&event.client_order_id).copied() else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            self.set_fatal("unknown ACK client order ID");
            return;
        };
        let spec = &self.orders[order_index];
        if batch != spec.batch {
            self.cross_batch_errors.fetch_add(1, Ordering::Relaxed);
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            self.set_fatal(format!("cross-batch ACK route for order {order_index}"));
            return;
        }
        if handler != spec.owner_handler
            || strategy_id != spec.strategy_id
            || event.strategy_id != spec.strategy_id
            || event.trader_id != benchmark_trader_id(self.config.topology, batch)
            || event.instrument_id != spec.instrument_id
            || event.account_id != benchmark_account_id(self.config.topology, batch)
        {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            self.set_fatal(format!("ACK route mismatch for order {order_index}"));
            return;
        }
        if self.ack_seen[order_index].swap(true, Ordering::AcqRel) {
            self.mark_duplicate("ACK", order_index);
            return;
        }
        self.t_ack_ns[order_index].store(entry_ns, Ordering::Release);
        self.ack_callbacks.fetch_add(1, Ordering::Relaxed);
        if let Err(error) = self.record_native_owner_delivery(
            order_index,
            batch,
            handler,
            AccountObservationKind::Accepted,
        ) {
            self.set_fatal(error.to_string());
        }
    }

    fn record_fill_callback(
        &self,
        batch: usize,
        handler: usize,
        strategy_id: StrategyId,
        event: &OrderFilled,
        entry_ns: u64,
    ) {
        let Some(order_index) = self.order_by_client_id.get(&event.client_order_id).copied() else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            self.set_fatal("unknown fill client order ID");
            return;
        };
        let spec = &self.orders[order_index];
        if batch != spec.batch {
            self.cross_batch_errors.fetch_add(1, Ordering::Relaxed);
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            self.set_fatal(format!("cross-batch fill route for order {order_index}"));
            return;
        }
        if handler != spec.owner_handler
            || strategy_id != spec.strategy_id
            || event.strategy_id != spec.strategy_id
            || event.trader_id != benchmark_trader_id(self.config.topology, batch)
            || event.instrument_id != spec.instrument_id
            || event.account_id != benchmark_account_id(self.config.topology, batch)
            || spec.reject
        {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            self.set_fatal(format!("fill route mismatch for order {order_index}"));
            return;
        }
        if self.fill_seen[order_index].swap(true, Ordering::AcqRel) {
            self.mark_duplicate("fill", order_index);
            return;
        }
        self.t_fill_ns[order_index].store(entry_ns, Ordering::Release);
        self.fill_callbacks.fetch_add(1, Ordering::Relaxed);
        if let Err(error) = self.record_native_owner_delivery(
            order_index,
            batch,
            handler,
            AccountObservationKind::Filled,
        ) {
            self.set_fatal(error.to_string());
            return;
        }
        if let Err(error) = self.complete_order(order_index) {
            self.set_fatal(error.to_string());
        }
    }

    fn record_reject_callback(
        &self,
        batch: usize,
        handler: usize,
        strategy_id: StrategyId,
        event: &OrderRejected,
    ) {
        let Some(order_index) = self.order_by_client_id.get(&event.client_order_id).copied() else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            self.set_fatal("unknown rejection client order ID");
            return;
        };
        let spec = &self.orders[order_index];
        if batch != spec.batch {
            self.cross_batch_errors.fetch_add(1, Ordering::Relaxed);
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            self.set_fatal(format!(
                "cross-batch rejection route for order {order_index}"
            ));
            return;
        }
        if handler != spec.owner_handler
            || strategy_id != spec.strategy_id
            || event.strategy_id != spec.strategy_id
            || event.trader_id != benchmark_trader_id(self.config.topology, batch)
            || event.instrument_id != spec.instrument_id
            || event.account_id != benchmark_account_id(self.config.topology, batch)
            || !spec.reject
        {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            self.set_fatal(format!("rejection route mismatch for order {order_index}"));
            return;
        }
        if self.reject_seen[order_index].swap(true, Ordering::AcqRel) {
            self.mark_duplicate("rejection", order_index);
            return;
        }
        self.reject_callbacks.fetch_add(1, Ordering::Relaxed);
        if let Err(error) = self.record_native_owner_delivery(
            order_index,
            batch,
            handler,
            AccountObservationKind::Rejected,
        ) {
            self.set_fatal(error.to_string());
            return;
        }
        if let Err(error) = self.complete_order(order_index) {
            self.set_fatal(error.to_string());
        }
    }

    fn complete_order(&self, order_index: usize) -> anyhow::Result<()> {
        let previous = self.in_flight.fetch_sub(1, Ordering::AcqRel);
        anyhow::ensure!(previous > 0, "in-flight counter underflow");
        self.complete_tick(self.orders[order_index].tick_correlation)
    }

    fn complete_tick(&self, correlation: usize) -> anyhow::Result<()> {
        if self.completed_seen[correlation].swap(true, Ordering::AcqRel) {
            self.mark_duplicate("completion", correlation);
            anyhow::bail!("duplicate tick completion");
        }
        let task = self.ticks[correlation].task;
        self.task_completed[task].fetch_add(1, Ordering::Relaxed);
        self.completed_ticks.fetch_add(1, Ordering::AcqRel);
        self.try_finish_phase();
        Ok(())
    }

    fn try_finish_phase(&self) {
        if self.completed_ticks.load(Ordering::Acquire) != self.ticks.len()
            || self.account_observation_callbacks.load(Ordering::Acquire)
                != self.observation_delivery_seen.len()
        {
            return;
        }
        let completion_ns = self.monotonic_ns();
        if self
            .phase_end_ns
            .compare_exchange(0, completion_ns, Ordering::AcqRel, Ordering::Acquire)
            .is_ok()
        {
            self.all_completed.notify_one();
        }
    }

    async fn wait_for_completion_or_fatal(&self) -> anyhow::Result<()> {
        self.check_fatal()?;
        tokio::select! {
            () = self.all_completed.notified() => self.check_fatal(),
            () = self.fatal_notify.notified() => self.check_fatal(),
        }
    }
}

fn atomic_u64_vec(len: usize) -> Vec<AtomicU64> {
    (0..len).map(|_| AtomicU64::new(0)).collect()
}

fn atomic_usize_vec(len: usize) -> Vec<AtomicUsize> {
    (0..len).map(|_| AtomicUsize::new(0)).collect()
}

fn atomic_bool_vec(len: usize) -> Vec<AtomicBool> {
    (0..len).map(|_| AtomicBool::new(false)).collect()
}

fn validate_config(config: PipelineConfig) -> anyhow::Result<()> {
    anyhow::ensure!(config.tasks > 0, "tasks must be greater than zero");
    anyhow::ensure!(
        config.instruments_per_task > 0,
        "instruments_per_task must be greater than zero"
    );
    anyhow::ensure!(
        config.messages_per_instrument > 0,
        "messages_per_instrument must be greater than zero"
    );
    anyhow::ensure!(
        config.order_every > 0,
        "order_every must be greater than zero"
    );
    anyhow::ensure!(
        config.reject_every > 0,
        "reject_every must be greater than zero"
    );
    anyhow::ensure!(config.timeout > Duration::ZERO, "timeout must be positive");
    anyhow::ensure!(
        BATCH_INSTRUMENTS == HANDLERS_PER_BATCH * INSTRUMENTS_PER_HANDLER,
        "invalid batch topology constants"
    );
    if config.topology == LiveTopology::BatchSharded {
        anyhow::ensure!(
            config.instruments_per_task == BATCH_INSTRUMENTS,
            "batch_sharded requires exactly {BATCH_INSTRUMENTS} instruments per batch"
        );
    }
    if config.topology == LiveTopology::Ws5Strategy20 {
        anyhow::ensure!(
            config.tasks == WS5_STRATEGY20_PUBLIC_WS_TASKS,
            "ws5_strategy20 requires exactly {WS5_STRATEGY20_PUBLIC_WS_TASKS} public WS tasks"
        );
        anyhow::ensure!(
            config.instruments_per_task == WS5_STRATEGY20_SYMBOLS_PER_PUBLIC_WS,
            "ws5_strategy20 requires exactly {WS5_STRATEGY20_SYMBOLS_PER_PUBLIC_WS} symbols per public WS"
        );
        anyhow::ensure!(
            config.total_instruments()? == WS5_STRATEGY20_INSTRUMENTS,
            "ws5_strategy20 requires exactly {WS5_STRATEGY20_INSTRUMENTS} instruments"
        );
    }
    Ok(())
}

fn build_instruments(total: usize) -> Vec<InstrumentAny> {
    (0..total)
        .map(|index| {
            let symbol = USD_M_SYMBOLS
                .get(index)
                .map_or_else(|| format!("SIM{index:04}USDT"), |symbol| symbol.to_string());
            let base = symbol
                .strip_suffix("USDT")
                .expect("USD-M symbol must end in USDT");
            InstrumentAny::CryptoPerpetual(CryptoPerpetual::new(
                InstrumentId::from(format!("{symbol}-PERP.BINANCE").as_str()),
                Symbol::from(symbol.as_str()),
                Currency::new(base, 8, 0, base, CurrencyType::Crypto),
                Currency::USDT(),
                Currency::USDT(),
                false,
                PRICE_PRECISION,
                SIZE_PRECISION,
                Price::from("0.01"),
                Quantity::from("0.001"),
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                UnixNanos::default(),
                UnixNanos::default(),
            ))
        })
        .collect()
}

fn build_fixtures(
    config: PipelineConfig,
    instruments: &[InstrumentAny],
) -> anyhow::Result<(Vec<TickSpec>, Vec<OrderSpec>)> {
    let total_ticks = config.total_ticks()?;
    let mut ticks = Vec::with_capacity(total_ticks);
    let mut orders = Vec::with_capacity(total_ticks);
    let mut observation_index = 0;

    for task in 0..config.tasks {
        for message_index in 0..config.messages_per_instrument {
            for local_instrument in 0..config.instruments_per_task {
                let (batch, handler) = match config.topology {
                    LiveTopology::SharedHandler => (0, 0),
                    LiveTopology::BatchSharded => {
                        (task, local_instrument / INSTRUMENTS_PER_HANDLER)
                    }
                    LiveTopology::Ws5Strategy20 => (0, task),
                };
                let strategy_id = benchmark_strategy_id(config.topology, batch, handler);
                let instrument_index = task * config.instruments_per_task + local_instrument;
                let instrument = &instruments[instrument_index];
                let raw_symbol = instrument.raw_symbol();
                let symbol = raw_symbol.as_str();
                let correlation = ticks.len();
                let trade_number = correlation as u64 + 1;
                let trade_id = TradeId::new(trade_number.to_string());
                let raw_public = serde_json::to_vec(&serde_json::json!({
                    "e": "aggTrade",
                    "E": EVENT_TIME_MS,
                    "s": symbol,
                    "a": trade_number,
                    "p": "1000.00",
                    "q": "1.000",
                    "f": trade_number,
                    "l": trade_number,
                    "T": EVENT_TIME_MS,
                    "m": false,
                }))?;

                let order_index = config.should_order(message_index).then_some(orders.len());
                if let Some(order_index) = order_index {
                    let client_order_id =
                        ClientOrderId::from(format!("{ORDER_PREFIX}{order_index}").as_str());
                    let reject = config.scenario == LiveScenario::BusinessError
                        && order_index % config.reject_every == 0;
                    let venue_order_id = 10_000_000_i64 + order_index as i64;
                    let venue_trade_id = 20_000_000_i64 + order_index as i64;
                    let raw_ack = private_order_frame(
                        symbol,
                        client_order_id,
                        venue_order_id,
                        venue_trade_id,
                        "NEW",
                        "NEW",
                        "0",
                        "0",
                        "0",
                    )?;
                    let raw_fill = private_order_frame(
                        symbol,
                        client_order_id,
                        venue_order_id,
                        venue_trade_id,
                        "TRADE",
                        "FILLED",
                        "1.000",
                        "1.000",
                        "1000.00",
                    )?;
                    let raw_reject = serde_json::to_vec(&serde_json::json!({
                        "code": -2010,
                        "msg": "deterministic benchmark venue rejection",
                        "id": order_index as u64,
                    }))?;
                    let (ack_observation_index, fill_observation_index, reject_observation_index) =
                        if reject {
                            let reject_index = observation_index;
                            observation_index += 1;
                            (None, None, Some(reject_index))
                        } else {
                            let ack_index = observation_index;
                            let fill_index = observation_index + 1;
                            observation_index += 2;
                            (Some(ack_index), Some(fill_index), None)
                        };
                    orders.push(OrderSpec {
                        batch,
                        owner_handler: handler,
                        strategy_id,
                        tick_correlation: correlation,
                        instrument_id: instrument.id(),
                        client_order_id,
                        reject,
                        raw_ack,
                        raw_fill,
                        raw_reject,
                        ack_observation_index,
                        fill_observation_index,
                        reject_observation_index,
                    });
                }

                ticks.push(TickSpec {
                    task,
                    batch,
                    handler,
                    strategy_id,
                    instrument_index,
                    instrument_id: instrument.id(),
                    trade_id,
                    order_index,
                    raw_public,
                });
            }
        }
    }

    anyhow::ensure!(ticks.len() == total_ticks, "fixture tick count mismatch");
    let expected_observations = orders
        .iter()
        .map(|spec| if spec.reject { 1 } else { 2 })
        .sum::<usize>();
    anyhow::ensure!(
        observation_index == expected_observations,
        "fixture private observation count mismatch"
    );
    Ok((ticks, orders))
}

#[expect(clippy::too_many_arguments)]
fn private_order_frame(
    symbol: &str,
    client_order_id: ClientOrderId,
    venue_order_id: i64,
    venue_trade_id: i64,
    execution_type: &str,
    order_status: &str,
    last_filled_qty: &str,
    cumulative_filled_qty: &str,
    last_filled_price: &str,
) -> anyhow::Result<Vec<u8>> {
    Ok(serde_json::to_vec(&serde_json::json!({
        "e": "ORDER_TRADE_UPDATE",
        "E": EVENT_TIME_MS,
        "T": EVENT_TIME_MS,
        "o": {
            "s": symbol,
            "c": client_order_id.as_str(),
            "S": "BUY",
            "o": "MARKET",
            "f": "GTC",
            "q": "1.000",
            "p": "0",
            "ap": if execution_type == "TRADE" { "1000.00" } else { "0" },
            "sp": "0",
            "x": execution_type,
            "X": order_status,
            "i": venue_order_id,
            "l": last_filled_qty,
            "z": cumulative_filled_qty,
            "L": last_filled_price,
            "N": "USDT",
            "n": "0",
            "T": EVENT_TIME_MS,
            "t": venue_trade_id,
            "b": "0",
            "a": "0",
            "m": false,
            "R": false,
            "wt": "CONTRACT_PRICE",
            "ot": "MARKET",
            "ps": "BOTH",
            "cp": false,
            "AP": "0",
            "cr": "0",
            "pP": false,
            "rp": "0",
            "V": "NONE",
        }
    }))?)
}

#[derive(Debug)]
struct LivePipelineStrategy {
    core: StrategyCore,
    state: Arc<BenchmarkState>,
    batch: usize,
    handler: usize,
    strategy_id: StrategyId,
}

impl LivePipelineStrategy {
    fn new(state: Arc<BenchmarkState>, batch: usize, handler: usize) -> Self {
        let strategy_id = benchmark_strategy_id(state.config.topology, batch, handler);
        Self {
            core: StrategyCore::new(StrategyConfig {
                strategy_id: Some(strategy_id),
                ..Default::default()
            }),
            state,
            batch,
            handler,
            strategy_id,
        }
    }
}

impl DataActor for LivePipelineStrategy {
    fn on_start(&mut self) -> anyhow::Result<()> {
        let instrument_ids: Vec<_> = match self.state.config.topology {
            LiveTopology::SharedHandler => {
                self.state.instruments.iter().map(Instrument::id).collect()
            }
            LiveTopology::BatchSharded => {
                let start = self.batch * BATCH_INSTRUMENTS + self.handler * INSTRUMENTS_PER_HANDLER;
                self.state.instruments[start..start + INSTRUMENTS_PER_HANDLER]
                    .iter()
                    .map(Instrument::id)
                    .collect()
            }
            LiveTopology::Ws5Strategy20 => {
                let start = self.handler * WS5_STRATEGY20_SYMBOLS_PER_PUBLIC_WS;
                self.state.instruments[start..start + WS5_STRATEGY20_SYMBOLS_PER_PUBLIC_WS]
                    .iter()
                    .map(Instrument::id)
                    .collect()
            }
        };
        for instrument_id in instrument_ids {
            self.subscribe_trades(instrument_id, None, None);
        }
        if self.state.config.topology.uses_bounded_account_ingress() {
            for owner_handler in 0..self
                .state
                .config
                .topology
                .account_handlers_per_fanout_domain()
            {
                if owner_handler != self.handler {
                    self.subscribe_data(
                        account_observation_data_type(self.batch, owner_handler),
                        None,
                        None,
                    );
                }
            }
        }
        Ok(())
    }

    fn on_data(&mut self, data: &CustomData) -> anyhow::Result<()> {
        let Some(observation) = data.data.as_any().downcast_ref::<AccountObservation>() else {
            self.state.route_errors.fetch_add(1, Ordering::Relaxed);
            self.state
                .set_fatal("unexpected custom data payload in live pipeline strategy");
            anyhow::bail!("unexpected custom data payload");
        };
        if data.data_type
            != account_observation_data_type(observation.batch, observation.owner_handler)
        {
            self.state.route_errors.fetch_add(1, Ordering::Relaxed);
            self.state
                .set_fatal("account observation data type mismatch");
            anyhow::bail!("account observation data type mismatch");
        }
        if let Err(error) =
            self.state
                .record_non_owner_observation(self.batch, self.handler, observation)
        {
            self.state.set_fatal(error.to_string());
            return Err(error);
        }
        Ok(())
    }

    fn on_trade(&mut self, tick: &TradeTick) -> anyhow::Result<()> {
        let Some(correlation) = self.state.tick_by_trade_id.get(&tick.trade_id).copied() else {
            self.state.route_errors.fetch_add(1, Ordering::Relaxed);
            self.state.set_fatal("unknown strategy trade correlation");
            anyhow::bail!("unknown strategy trade correlation");
        };
        self.state.record_trade_callback(
            self.batch,
            self.handler,
            self.strategy_id,
            correlation,
            tick,
        )?;
        self.state.run_signal_compute();
        let Some(order_index) = self.state.ticks[correlation].order_index else {
            self.state.complete_tick(correlation)?;
            return Ok(());
        };
        let order = self.order().market(
            tick.instrument_id,
            OrderSide::Buy,
            tick.size,
            None,
            None,
            None,
            None,
            None,
            None,
            Some(self.state.orders[order_index].client_order_id),
        );
        if let Err(error) = self.submit_order(
            order,
            None,
            Some(benchmark_client_id(self.state.config.topology, self.batch)),
            None,
        ) {
            self.state.route_errors.fetch_add(1, Ordering::Relaxed);
            self.state
                .set_fatal(format!("strategy order submission failed: {error}"));
            return Err(error);
        }
        Ok(())
    }
}

nautilus_strategy!(LivePipelineStrategy, {
    fn on_order_accepted(&mut self, event: OrderAccepted) {
        let entry_ns = self.state.monotonic_ns();
        self.state.record_ack_callback(
            self.batch,
            self.handler,
            self.strategy_id,
            &event,
            entry_ns,
        );
    }

    fn on_order_filled(&mut self, event: &OrderFilled) {
        let entry_ns = self.state.monotonic_ns();
        self.state.record_fill_callback(
            self.batch,
            self.handler,
            self.strategy_id,
            event,
            entry_ns,
        );
    }

    fn on_order_rejected(&mut self, event: OrderRejected) {
        self.state
            .record_reject_callback(self.batch, self.handler, self.strategy_id, &event);
    }
});

#[derive(Debug)]
struct BenchmarkExecutionClientConfig;

impl ClientConfig for BenchmarkExecutionClientConfig {
    fn as_any(&self) -> &dyn Any {
        self
    }
}

#[derive(Debug)]
struct BenchmarkExecutionClientFactory {
    state: Arc<BenchmarkState>,
    batch: usize,
}

impl ExecutionClientFactory for BenchmarkExecutionClientFactory {
    fn create(
        &self,
        _name: &str,
        _config: &dyn ClientConfig,
        cache: CacheView,
    ) -> anyhow::Result<Box<dyn ExecutionClient>> {
        let (private_tx, private_rx) = tokio::sync::mpsc::channel(PRIVATE_INGRESS_CAPACITY);
        Ok(Box::new(BenchmarkExecutionClient {
            state: self.state.clone(),
            batch: self.batch,
            cache,
            emitter: ExecutionEventEmitter::new(
                get_atomic_clock_realtime(),
                benchmark_trader_id(self.state.config.topology, self.batch),
                benchmark_account_id(self.state.config.topology, self.batch),
                AccountType::Margin,
                None,
            ),
            connected: AtomicBool::new(false),
            private_tx,
            private_rx: Some(private_rx),
            account_task: None,
        }))
    }

    fn name(&self) -> &'static str {
        "nautilus-live-pipeline"
    }

    fn config_type(&self) -> &'static str {
        stringify!(BenchmarkExecutionClientConfig)
    }
}

struct BenchmarkExecutionClient {
    state: Arc<BenchmarkState>,
    batch: usize,
    cache: CacheView,
    emitter: ExecutionEventEmitter,
    connected: AtomicBool,
    private_tx: tokio::sync::mpsc::Sender<PrivateIngress>,
    private_rx: Option<tokio::sync::mpsc::Receiver<PrivateIngress>>,
    account_task: Option<tokio::task::JoinHandle<()>>,
}

#[derive(Debug)]
struct PrivateIngress {
    order_index: usize,
    order: OrderAny,
}

fn publish_account_observation(
    state: &BenchmarkState,
    data_sender: Option<&tokio::sync::mpsc::UnboundedSender<DataEvent>>,
    observation: AccountObservation,
) -> anyhow::Result<()> {
    if state.config.topology == LiveTopology::SharedHandler {
        anyhow::ensure!(
            data_sender.is_none(),
            "shared handler unexpectedly published custom data"
        );
        return Ok(());
    }
    let data_sender =
        data_sender.ok_or_else(|| anyhow::anyhow!("account observation sender missing"))?;
    let data_type = account_observation_data_type(observation.batch, observation.owner_handler);
    data_sender
        .send(DataEvent::Data(Data::Custom(CustomData::new(
            Arc::new(observation),
            data_type,
        ))))
        .map_err(|_| anyhow::anyhow!("LiveNode account observation channel closed"))
}

fn process_private_ingress(
    state: &BenchmarkState,
    batch: usize,
    emitter: &ExecutionEventEmitter,
    data_sender: Option<&tokio::sync::mpsc::UnboundedSender<DataEvent>>,
    ingress: &PrivateIngress,
) -> anyhow::Result<()> {
    let spec = &state.orders[ingress.order_index];
    if spec.batch != batch {
        state.cross_batch_errors.fetch_add(1, Ordering::Relaxed);
        anyhow::bail!("private ingress batch mismatch");
    }

    if spec.reject {
        let response: BinanceFuturesWsErrorResponse = serde_json::from_slice(&spec.raw_reject)?;
        anyhow::ensure!(
            response.code < 0 && response.id == Some(ingress.order_index as u64),
            "business error code/correlation mismatch"
        );
        state.business_errors.fetch_add(1, Ordering::Relaxed);
        let ts_event = UnixNanos::from_millis(EVENT_TIME_MS as u64);
        let observation = state.record_private_source(
            spec.reject_observation_index
                .expect("rejected order missing observation index"),
            batch,
            ingress.order_index,
            AccountObservationKind::Rejected,
            ts_event,
        )?;
        publish_account_observation(state, data_sender, observation)?;
        emitter.emit_order_rejected(&ingress.order, &response.msg, ts_event, false);
        return Ok(());
    }

    let ack: BinanceFuturesOrderUpdateMsg = serde_json::from_slice(&spec.raw_ack)?;
    let instrument = &state.instruments[state.ticks[spec.tick_correlation].instrument_index];
    anyhow::ensure!(
        ack.event_type == "ORDER_TRADE_UPDATE"
            && ack.order.symbol.as_str() == instrument.raw_symbol().as_str()
            && ack.order.client_order_id == spec.client_order_id.as_str(),
        "decoded ACK raw route mismatch"
    );
    let ack_report = parse_futures_order_update_to_order_status(
        &ack,
        spec.instrument_id,
        PRICE_PRECISION,
        SIZE_PRECISION,
        benchmark_account_id(state.config.topology, batch),
        false,
        get_atomic_clock_realtime().get_time_ns(),
    )?;
    anyhow::ensure!(
        ack_report.client_order_id == Some(spec.client_order_id)
            && ack_report.instrument_id == spec.instrument_id,
        "decoded ACK route mismatch"
    );
    let ack_observation = state.record_private_source(
        spec.ack_observation_index
            .expect("successful order missing ACK observation index"),
        batch,
        ingress.order_index,
        AccountObservationKind::Accepted,
        ack_report.ts_last,
    )?;
    publish_account_observation(state, data_sender, ack_observation)?;
    emitter.emit_order_accepted(
        &ingress.order,
        ack_report.venue_order_id,
        ack_report.ts_last,
    );

    let fill: BinanceFuturesOrderUpdateMsg = serde_json::from_slice(&spec.raw_fill)?;
    anyhow::ensure!(
        fill.event_type == "ORDER_TRADE_UPDATE"
            && fill.order.symbol.as_str() == instrument.raw_symbol().as_str()
            && fill.order.client_order_id == spec.client_order_id.as_str(),
        "decoded fill raw route mismatch"
    );
    let fill_report = parse_futures_order_update_to_fill(
        &fill,
        benchmark_account_id(state.config.topology, batch),
        spec.instrument_id,
        PRICE_PRECISION,
        SIZE_PRECISION,
        None,
        Some(Currency::USDT()),
        Currency::USDT(),
        None,
        get_atomic_clock_realtime().get_time_ns(),
    )?;
    anyhow::ensure!(
        fill_report.client_order_id == Some(spec.client_order_id)
            && fill_report.instrument_id == spec.instrument_id,
        "decoded fill route mismatch"
    );
    let fill_observation = state.record_private_source(
        spec.fill_observation_index
            .expect("successful order missing fill observation index"),
        batch,
        ingress.order_index,
        AccountObservationKind::Filled,
        fill_report.ts_event,
    )?;
    publish_account_observation(state, data_sender, fill_observation)?;
    emitter.emit_order_filled(
        &ingress.order,
        fill_report.venue_order_id,
        fill_report.venue_position_id,
        fill_report.trade_id,
        fill_report.last_qty,
        fill_report.last_px,
        Currency::USDT(),
        Some(fill_report.commission),
        fill_report.liquidity_side,
        fill_report.ts_event,
    );
    Ok(())
}

#[async_trait(?Send)]
impl ExecutionClient for BenchmarkExecutionClient {
    fn is_connected(&self) -> bool {
        self.connected.load(Ordering::Acquire)
    }

    fn client_id(&self) -> ClientId {
        benchmark_client_id(self.state.config.topology, self.batch)
    }

    fn account_id(&self) -> AccountId {
        benchmark_account_id(self.state.config.topology, self.batch)
    }

    fn venue(&self) -> Venue {
        Venue::from("BINANCE")
    }

    fn oms_type(&self) -> OmsType {
        OmsType::Netting
    }

    fn get_account(&self) -> Option<AccountAny> {
        None
    }

    fn generate_account_state(
        &self,
        _balances: Vec<AccountBalance>,
        _margins: Vec<MarginBalance>,
        _reported: bool,
        _ts_event: UnixNanos,
    ) -> anyhow::Result<()> {
        Ok(())
    }

    fn start(&mut self) -> anyhow::Result<()> {
        self.emitter.set_sender(get_exec_event_sender());
        if self.state.config.topology.uses_bounded_account_ingress() && self.account_task.is_none()
        {
            let mut private_rx = self
                .private_rx
                .take()
                .ok_or_else(|| anyhow::anyhow!("account ingress receiver already taken"))?;
            let state = self.state.clone();
            let emitter = self.emitter.clone();
            let data_sender = get_data_event_sender();
            let batch = self.batch;
            self.account_task = Some(tokio::spawn(async move {
                while let Some(ingress) = private_rx.recv().await {
                    if let Err(error) = process_private_ingress(
                        &state,
                        batch,
                        &emitter,
                        Some(&data_sender),
                        &ingress,
                    ) {
                        state.route_errors.fetch_add(1, Ordering::Relaxed);
                        state.set_fatal(format!("account ingress failed: {error:#}"));
                        break;
                    }
                    tokio::task::yield_now().await;
                }
            }));
        }
        self.connected.store(true, Ordering::Release);
        Ok(())
    }

    fn stop(&mut self) -> anyhow::Result<()> {
        self.connected.store(false, Ordering::Release);
        if let Some(task) = self.account_task.take() {
            task.abort();
        }
        Ok(())
    }

    async fn connect(&mut self) -> anyhow::Result<()> {
        self.connected.store(true, Ordering::Release);
        Ok(())
    }

    async fn disconnect(&mut self) -> anyhow::Result<()> {
        self.connected.store(false, Ordering::Release);
        Ok(())
    }

    fn submit_order(&self, cmd: SubmitOrder) -> anyhow::Result<()> {
        let entry_ns = self.state.monotonic_ns();
        let result = (|| {
            let order_index = self.state.record_order_entry(self.batch, &cmd, entry_ns)?;
            let order = self.cache.borrow().try_order_owned(&cmd.client_order_id)?;
            self.emitter.emit_order_submitted(&order);
            let ingress = PrivateIngress { order_index, order };
            if self.state.config.topology.uses_bounded_account_ingress() {
                self.private_tx
                    .try_send(ingress)
                    .map_err(|error| anyhow::anyhow!("account ingress enqueue failed: {error}"))
            } else {
                process_private_ingress(&self.state, self.batch, &self.emitter, None, &ingress)
            }
        })();
        if let Err(error) = &result {
            self.state.route_errors.fetch_add(1, Ordering::Relaxed);
            self.state
                .set_fatal(format!("simulated venue failed: {error:#}"));
        }
        result
    }
}

fn benchmark_client_id(topology: LiveTopology, batch: usize) -> ClientId {
    match topology {
        LiveTopology::SharedHandler => ClientId::from(CLIENT_ID),
        LiveTopology::BatchSharded | LiveTopology::Ws5Strategy20 => {
            ClientId::from(format!("LIVE-PIPELINE-EXEC-{batch:03}").as_str())
        }
    }
}

fn benchmark_account_id(topology: LiveTopology, batch: usize) -> AccountId {
    match topology {
        LiveTopology::SharedHandler => AccountId::from(ACCOUNT_ID),
        LiveTopology::BatchSharded | LiveTopology::Ws5Strategy20 => {
            AccountId::from(format!("LIVE-PIPELINE-ACCOUNT-{batch:03}").as_str())
        }
    }
}

fn benchmark_strategy_id(topology: LiveTopology, batch: usize, handler: usize) -> StrategyId {
    match topology {
        LiveTopology::SharedHandler => StrategyId::from(STRATEGY_ID),
        LiveTopology::BatchSharded | LiveTopology::Ws5Strategy20 => {
            StrategyId::from(format!("LIVE-PIPELINE-{batch:03}-STRATEGY-{handler:03}").as_str())
        }
    }
}

fn benchmark_trader_id(topology: LiveTopology, batch: usize) -> TraderId {
    match topology {
        LiveTopology::SharedHandler => TraderId::from(TRADER_ID),
        LiveTopology::BatchSharded | LiveTopology::Ws5Strategy20 => {
            TraderId::from(format!("LIVE-PIPELINE-TRADER-{batch:03}").as_str())
        }
    }
}

#[derive(Clone, Copy, Debug, Default)]
struct EngineCounters {
    risk_commands: u64,
    execution_commands: u64,
}

type ReadyResult = (
    usize,
    Result<
        (
            tokio::sync::mpsc::UnboundedSender<DataEvent>,
            LiveNodeHandle,
        ),
        String,
    >,
);
type EngineCompletion = (usize, Result<EngineCounters, String>);

pub(crate) async fn run_pipeline(config: PipelineConfig) -> anyhow::Result<PipelineReport> {
    let state = Arc::new(BenchmarkState::new(config)?);
    let engine_count = config.topology.batch_count(config.tasks);
    let (ready_tx, ready_rx) = mpsc::sync_channel::<ReadyResult>(engine_count);
    let (completion_tx, completion_rx) = mpsc::sync_channel::<EngineCompletion>(engine_count);
    let mut engine_threads = Vec::with_capacity(engine_count);

    for batch in 0..engine_count {
        let ready_tx = ready_tx.clone();
        let completion_tx = completion_tx.clone();
        let engine_state = state.clone();
        let completion_state = state.clone();
        let engine_thread = thread::Builder::new()
            .name(format!("nautilus-live-pipeline-engine-{batch:03}"))
            .spawn(move || {
                let completion =
                    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                        run_engine(engine_state, batch, ready_tx)
                    })) {
                        Ok(result) => result.map_err(|error| format!("{error:#}")),
                        Err(payload) => Err(format!(
                            "live pipeline engine {batch} panicked: {}",
                            panic_payload_message(payload.as_ref())
                        )),
                    };
                if let Err(error) = &completion {
                    completion_state
                        .set_fatal(format!("live pipeline engine {batch} failed: {error}"));
                }
                let _ = completion_tx.send((batch, completion));
            })?;
        engine_threads.push(engine_thread);
    }
    drop(ready_tx);
    drop(completion_tx);

    let startup_deadline = Instant::now() + config.timeout;
    let mut senders = vec![None; engine_count];
    let mut handles = vec![None; engine_count];
    let mut startup_error = None;
    for _ in 0..engine_count {
        let remaining = startup_deadline.saturating_duration_since(Instant::now());
        if remaining == Duration::ZERO {
            state.set_fatal("live pipeline startup timed out");
            drop(engine_threads);
            anyhow::bail!("live pipeline startup timed out after {:?}", config.timeout);
        }
        match ready_rx.recv_timeout(remaining) {
            Ok((batch, Ok((sender, handle)))) => {
                if batch >= engine_count {
                    startup_error = Some(format!("invalid ready batch {batch}"));
                } else if senders[batch].replace(sender).is_some()
                    || handles[batch].replace(handle).is_some()
                {
                    startup_error = Some(format!("duplicate ready batch {batch}"));
                }
            }
            Ok((batch, Err(error))) => {
                startup_error = Some(format!("batch {batch} startup failed: {error}"));
            }
            Err(mpsc::RecvTimeoutError::Timeout) => {
                state.set_fatal("live pipeline startup timed out");
                drop(engine_threads);
                anyhow::bail!("live pipeline startup timed out after {:?}", config.timeout);
            }
            Err(mpsc::RecvTimeoutError::Disconnected) => {
                state.set_fatal("live pipeline startup channel disconnected");
                drop(engine_threads);
                anyhow::bail!("live pipeline startup channel disconnected");
            }
        }
    }

    if let Some(error) = startup_error {
        state.set_fatal(error.clone());
        for handle in handles.iter().flatten() {
            handle.stop();
        }
        let _ = collect_engine_completions(
            engine_threads,
            &completion_rx,
            engine_count,
            config.timeout,
            &state,
        );
        anyhow::bail!(error);
    }
    let handles: Vec<_> = handles
        .into_iter()
        .enumerate()
        .map(|(batch, handle)| {
            handle.ok_or_else(|| anyhow::anyhow!("batch {batch} did not return a node handle"))
        })
        .collect::<anyhow::Result<_>>()?;
    let senders: Vec<_> = senders
        .into_iter()
        .enumerate()
        .map(|(batch, sender)| {
            sender.ok_or_else(|| anyhow::anyhow!("batch {batch} did not return a data sender"))
        })
        .collect::<anyhow::Result<_>>()?;

    let drive_result = match tokio::time::timeout(config.timeout, async {
        for handle in &handles {
            wait_until_running(handle).await?;
        }
        drive_producers(senders, state.clone()).await
    })
    .await
    {
        Ok(result) => result,
        Err(_) => Err(anyhow::anyhow!(
            "live pipeline timed out after {:?}",
            config.timeout
        )),
    };
    if let Err(error) = &drive_result {
        state.set_fatal(format!("live pipeline drive failed: {error:#}"));
    }

    for handle in &handles {
        handle.stop();
    }
    let counters_result = collect_engine_completions(
        engine_threads,
        &completion_rx,
        engine_count,
        config.timeout,
        &state,
    );
    drive_result?;
    let counters = counters_result?;
    state.build_report(counters)
}

fn run_engine(
    state: Arc<BenchmarkState>,
    batch: usize,
    ready_tx: mpsc::SyncSender<ReadyResult>,
) -> anyhow::Result<EngineCounters> {
    let runtime = match tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
    {
        Ok(runtime) => runtime,
        Err(error) => {
            let _ = ready_tx.send((batch, Err(error.to_string())));
            return Err(error.into());
        }
    };
    runtime.block_on(async move {
        let mut node = match build_node(state, batch) {
            Ok(node) => node,
            Err(error) => {
                let _ = ready_tx.send((batch, Err(error.to_string())));
                return Err(error);
            }
        };
        let handle = node.handle();
        ready_tx
            .send((batch, Ok((get_data_event_sender(), handle))))
            .map_err(|_| anyhow::anyhow!("live pipeline driver dropped before startup"))?;
        node.run().await?;
        Ok(EngineCounters {
            risk_commands: node.kernel().risk_engine().borrow().command_count(),
            execution_commands: node.kernel().exec_engine().borrow().command_count(),
        })
    })
}

fn build_node(
    state: Arc<BenchmarkState>,
    batch: usize,
) -> anyhow::Result<nautilus_live::node::LiveNode> {
    let topology = state.config.topology;
    let config = LiveNodeConfig {
        environment: Environment::Live,
        trader_id: benchmark_trader_id(topology, batch),
        exec_engine: LiveExecEngineConfig {
            reconciliation: false,
            ..Default::default()
        },
        delay_post_stop: Duration::ZERO,
        timeout_disconnection: Duration::ZERO,
        logging: LoggerConfig {
            bypass_logging: true,
            ..Default::default()
        },
        ..Default::default()
    };
    let factory = BenchmarkExecutionClientFactory {
        state: state.clone(),
        batch,
    };
    let mut node = LiveNodeBuilder::from_config(config)?
        .with_name("NautilusLivePipelineBenchmark")
        .add_exec_client(
            Some(format!("live-pipeline-{batch:03}")),
            Box::new(factory),
            Box::new(BenchmarkExecutionClientConfig),
        )?
        .build()?;
    let instrument_range = match topology {
        LiveTopology::SharedHandler | LiveTopology::Ws5Strategy20 => 0..state.instruments.len(),
        LiveTopology::BatchSharded => {
            let start = batch * BATCH_INSTRUMENTS;
            start..start + BATCH_INSTRUMENTS
        }
    };
    for instrument in &state.instruments[instrument_range] {
        node.kernel()
            .cache()
            .borrow_mut()
            .add_instrument(instrument.clone())?;
    }
    match topology {
        LiveTopology::SharedHandler => {
            node.add_strategy(LivePipelineStrategy::new(state, 0, 0))?;
        }
        LiveTopology::BatchSharded | LiveTopology::Ws5Strategy20 => {
            for handler in 0..topology.account_handlers_per_fanout_domain() {
                node.add_strategy(LivePipelineStrategy::new(state.clone(), batch, handler))?;
            }
        }
    }
    Ok(node)
}

async fn wait_until_running(handle: &LiveNodeHandle) -> anyhow::Result<()> {
    loop {
        match handle.state() {
            NodeState::Running => return Ok(()),
            NodeState::Stopped => anyhow::bail!("live pipeline node stopped during startup"),
            _ => tokio::task::yield_now().await,
        }
    }
}

async fn drive_producers(
    senders: Vec<tokio::sync::mpsc::UnboundedSender<DataEvent>>,
    state: Arc<BenchmarkState>,
) -> anyhow::Result<()> {
    let lane_count = state.config.producer_tasks()?;
    let mut lane_correlations = vec![Vec::new(); lane_count];
    for (correlation, spec) in state.ticks.iter().enumerate() {
        let lane = match state.config.topology {
            LiveTopology::SharedHandler | LiveTopology::Ws5Strategy20 => spec.task,
            LiveTopology::BatchSharded => spec.instrument_index,
        };
        lane_correlations[lane].push(correlation);
    }
    let barrier = Arc::new(Barrier::new(lane_count + 1));
    let go = Arc::new(AtomicBool::new(false));
    let mut tasks = tokio::task::JoinSet::new();

    for correlations in lane_correlations {
        anyhow::ensure!(!correlations.is_empty(), "public producer lane was empty");
        let batch = state.ticks[correlations[0]].batch;
        let sender = senders
            .get(batch)
            .ok_or_else(|| anyhow::anyhow!("missing LiveNode sender for batch {batch}"))?
            .clone();
        let state = state.clone();
        let barrier = barrier.clone();
        let go = go.clone();
        tasks.spawn(async move {
            barrier.wait().await;
            while !go.load(Ordering::Acquire) {
                tokio::task::yield_now().await;
            }
            for correlation in correlations {
                state.check_fatal()?;
                state.prepare_public_start(correlation)?;
                let spec = &state.ticks[correlation];
                if spec.batch != batch {
                    state.cross_batch_errors.fetch_add(1, Ordering::Relaxed);
                    state.route_errors.fetch_add(1, Ordering::Relaxed);
                    anyhow::bail!("public producer lane crossed batches");
                }
                let instrument = &state.instruments[spec.instrument_index];
                let public_entry_ns = state.monotonic_ns();
                state.record_public_start(correlation, public_entry_ns);
                let message: BinanceFuturesAggTradeMsg = serde_json::from_slice(&spec.raw_public)?;
                let tick = parse_agg_trade(
                    &message,
                    instrument,
                    get_atomic_clock_realtime().get_time_ns(),
                )?;
                let decoded_ns = state.monotonic_ns();
                state.record_public_decoded(correlation, decoded_ns);
                anyhow::ensure!(
                    message.symbol.as_str() == instrument.raw_symbol().as_str(),
                    "public symbol route mismatch for correlation {correlation}"
                );
                sender
                    .send(DataEvent::Data(Data::Trade(tick)))
                    .map_err(|_| anyhow::anyhow!("LiveNode data event channel closed"))?;
                tokio::task::yield_now().await;
                state
                    .public_cooperative_yields
                    .fetch_add(1, Ordering::Relaxed);
            }
            anyhow::Ok(())
        });
    }

    barrier.wait().await;
    let phase_start = state.monotonic_ns();
    anyhow::ensure!(phase_start > 0, "phase start timestamp was zero");
    state.phase_start_ns.store(phase_start, Ordering::Release);
    go.store(true, Ordering::Release);

    while let Some(task) = tasks.join_next().await {
        task.map_err(|error| anyhow::anyhow!("public producer failed: {error}"))??;
    }
    state.wait_for_completion_or_fatal().await?;
    Ok(())
}

fn collect_engine_completions(
    engine_threads: Vec<thread::JoinHandle<()>>,
    completion_rx: &mpsc::Receiver<EngineCompletion>,
    engine_count: usize,
    timeout: Duration,
    state: &BenchmarkState,
) -> anyhow::Result<EngineCounters> {
    let deadline = Instant::now() + timeout;
    let mut seen = vec![false; engine_count];
    let mut counters = EngineCounters::default();
    let mut first_error = None;
    for _ in 0..engine_count {
        let remaining = deadline.saturating_duration_since(Instant::now());
        if remaining == Duration::ZERO {
            state.set_fatal(format!(
                "live pipeline shutdown timed out after {timeout:?}"
            ));
            drop(engine_threads);
            anyhow::bail!("live pipeline shutdown timed out after {timeout:?}");
        }
        match completion_rx.recv_timeout(remaining) {
            Ok((batch, completion)) => {
                if batch >= engine_count || seen[batch] {
                    first_error = Some(format!("duplicate or invalid completion batch {batch}"));
                    continue;
                }
                seen[batch] = true;
                match completion {
                    Ok(batch_counters) => {
                        counters.risk_commands += batch_counters.risk_commands;
                        counters.execution_commands += batch_counters.execution_commands;
                    }
                    Err(error) => {
                        first_error.get_or_insert(error);
                    }
                }
            }
            Err(mpsc::RecvTimeoutError::Disconnected) => {
                state.set_fatal("live pipeline completion channel disconnected");
                for engine_thread in engine_threads {
                    let _ = engine_thread.join();
                }
                anyhow::bail!("live pipeline completion channel disconnected");
            }
            Err(mpsc::RecvTimeoutError::Timeout) => {
                state.set_fatal(format!(
                    "live pipeline shutdown timed out after {timeout:?}"
                ));
                drop(engine_threads);
                anyhow::bail!("live pipeline shutdown timed out after {timeout:?}");
            }
        }
    }
    for engine_thread in engine_threads {
        engine_thread
            .join()
            .map_err(|_| anyhow::anyhow!("live pipeline engine thread panicked"))?;
    }
    if let Some(error) = first_error {
        anyhow::bail!(error);
    }
    anyhow::ensure!(
        seen.into_iter().all(|value| value),
        "engine completion loss"
    );
    Ok(counters)
}

fn panic_payload_message(payload: &(dyn Any + Send)) -> String {
    if let Some(message) = payload.downcast_ref::<&str>() {
        (*message).to_string()
    } else if let Some(message) = payload.downcast_ref::<String>() {
        message.clone()
    } else {
        "unknown panic payload".to_string()
    }
}

impl BenchmarkState {
    fn build_report(&self, counters: EngineCounters) -> anyhow::Result<PipelineReport> {
        self.check_fatal()?;
        let expected_success_orders = self.orders.iter().filter(|spec| !spec.reject).count();
        let mut drops = 0;
        let mut public_decode_ns = Vec::with_capacity(self.ticks.len());
        for correlation in 0..self.ticks.len() {
            let complete = self.public_seen[correlation].load(Ordering::Acquire)
                && self.trade_seen[correlation].load(Ordering::Acquire)
                && self.completed_seen[correlation].load(Ordering::Acquire);
            if !complete {
                drops += 1;
                continue;
            }
            let t0 = self.t0_ns[correlation].load(Ordering::Acquire);
            let t_public = self.t_public_ns[correlation].load(Ordering::Acquire);
            anyhow::ensure!(t0 > 0 && t_public >= t0, "invalid public timing boundary");
            public_decode_ns.push(t_public - t0);
        }

        let mut tick_to_order_ns = Vec::with_capacity(self.orders.len());
        let mut tick_to_ack_ns = Vec::with_capacity(expected_success_orders);
        let mut tick_to_fill_ns = Vec::with_capacity(expected_success_orders);
        for (order_index, spec) in self.orders.iter().enumerate() {
            if !self.order_seen[order_index].load(Ordering::Acquire) {
                drops += 1;
                continue;
            }
            let t0 = self.t0_ns[spec.tick_correlation].load(Ordering::Acquire);
            let t_order = self.t_order_ns[order_index].load(Ordering::Acquire);
            anyhow::ensure!(t_order >= t0, "order endpoint preceded public decode");
            tick_to_order_ns.push(t_order - t0);

            if spec.reject {
                if !self.reject_seen[order_index].load(Ordering::Acquire) {
                    drops += 1;
                }
                continue;
            }
            if !self.ack_seen[order_index].load(Ordering::Acquire)
                || !self.fill_seen[order_index].load(Ordering::Acquire)
            {
                drops += 1;
                continue;
            }
            let t_ack = self.t_ack_ns[order_index].load(Ordering::Acquire);
            let t_fill = self.t_fill_ns[order_index].load(Ordering::Acquire);
            anyhow::ensure!(
                t_ack >= t_order && t_fill >= t_ack,
                "private callback timing order violated"
            );
            tick_to_ack_ns.push(t_ack - t0);
            tick_to_fill_ns.push(t_fill - t0);
        }
        drops += self
            .observation_source_seen
            .iter()
            .filter(|seen| !seen.load(Ordering::Acquire))
            .count();
        drops += self
            .observation_delivery_seen
            .iter()
            .filter(|seen| !seen.load(Ordering::Acquire))
            .count();

        let phase_start = self.phase_start_ns.load(Ordering::Acquire);
        let phase_end = self.phase_end_ns.load(Ordering::Acquire);
        anyhow::ensure!(
            phase_start > 0 && phase_end >= phase_start,
            "invalid wall boundary"
        );
        let elapsed = Duration::from_nanos(phase_end - phase_start);
        let task_sent: Vec<_> = self
            .task_sent
            .iter()
            .map(|count| count.load(Ordering::Acquire))
            .collect();
        let task_completed: Vec<_> = self
            .task_completed
            .iter()
            .map(|count| count.load(Ordering::Acquire))
            .collect();
        let signal_trade_callbacks: Vec<_> = self
            .trade_callbacks_by_signal_handler
            .iter()
            .map(|count| count.load(Ordering::Acquire))
            .collect();
        let signal_private_callbacks: Vec<_> = self
            .private_callbacks_by_signal_handler
            .iter()
            .map(|count| count.load(Ordering::Acquire))
            .collect();
        let topology = self.config.topology;
        let batch_count = topology.batch_count(self.config.tasks);
        let producer_tasks = self.config.producer_tasks()?;
        let signal_handlers = self.config.signal_handlers()?;
        let private_sources = self.observation_source_seen.len();
        let account_handlers_per_fanout_domain = topology.account_handlers_per_fanout_domain();
        let bounded_account_ingress = topology.uses_bounded_account_ingress();

        Ok(PipelineReport {
            topology,
            batch_count,
            live_nodes: batch_count,
            engine_threads: batch_count,
            physical_sockets: 0,
            producer_tasks,
            public_ws_tasks: producer_tasks,
            public_ws_tasks_per_fanout_domain: self.config.public_ws_tasks_per_fanout_domain()?,
            symbols_per_public_ws: self.config.symbols_per_public_ws(),
            symbols_per_signal_handler: self.config.symbols_per_signal_handler()?,
            trade_task_keys: 0,
            trade_ingress_lanes: producer_tasks,
            public_cooperative_yields: self.public_cooperative_yields.load(Ordering::Acquire),
            signal_handlers,
            strategy_handlers: signal_handlers,
            trade_lanes_per_signal_handler: self.config.trade_lanes_per_signal_handler()?,
            instruments_per_handler: self.config.symbols_per_signal_handler()?,
            account_ingress_tasks: if bounded_account_ingress {
                batch_count
            } else {
                0
            },
            account_ingress_lanes: batch_count,
            account_broadcast_rings: 0,
            account_broadcast_topics: if bounded_account_ingress {
                signal_handlers
            } else {
                0
            },
            account_fanout_domains: batch_count,
            account_receivers_per_ring: 0,
            account_handlers_per_fanout_domain,
            account_non_owner_subscribers_per_topic: if bounded_account_ingress {
                account_handlers_per_fanout_domain - 1
            } else {
                0
            },
            account_owner_handlers: signal_handlers,
            venue_handlers: batch_count,
            order_runners: if bounded_account_ingress {
                batch_count
            } else {
                0
            },
            private_ingress_capacity: if bounded_account_ingress {
                PRIVATE_INGRESS_CAPACITY
            } else {
                0
            },
            total_ticks: self.ticks.len(),
            expected_orders: self.orders.len(),
            expected_success_orders,
            public_parsed: self.public_parsed.load(Ordering::Acquire),
            trade_callbacks: self.trade_callbacks.load(Ordering::Acquire),
            signal_compute_ns: self.config.signal_compute_ns,
            signal_compute_calls: self.signal_compute_calls.load(Ordering::Acquire),
            orders_submitted: self.orders_submitted.load(Ordering::Acquire),
            private_frames_parsed: self.private_frames_parsed.load(Ordering::Acquire),
            acks: self.ack_callbacks.load(Ordering::Acquire),
            fills: self.fill_callbacks.load(Ordering::Acquire),
            rejections: self.reject_callbacks.load(Ordering::Acquire),
            drops,
            duplicates: self.duplicates.load(Ordering::Acquire),
            route_errors: self.route_errors.load(Ordering::Acquire),
            business_errors: self.business_errors.load(Ordering::Acquire),
            expected_account_callbacks: private_sources * account_handlers_per_fanout_domain,
            account_observation_sources: self.account_observation_sources.load(Ordering::Acquire),
            account_observation_callbacks: self
                .account_observation_callbacks
                .load(Ordering::Acquire),
            native_owner_callbacks: self.ack_callbacks.load(Ordering::Acquire)
                + self.fill_callbacks.load(Ordering::Acquire)
                + self.reject_callbacks.load(Ordering::Acquire),
            account_non_owner_callbacks: self.account_non_owner_callbacks.load(Ordering::Acquire),
            cross_batch_errors: self.cross_batch_errors.load(Ordering::Acquire),
            max_in_flight: self.max_in_flight.load(Ordering::Acquire),
            ending_in_flight: self.in_flight.load(Ordering::Acquire),
            per_task_sent_min: task_sent.iter().copied().min().unwrap_or(0),
            per_task_sent_max: task_sent.iter().copied().max().unwrap_or(0),
            per_task_completed_min: task_completed.iter().copied().min().unwrap_or(0),
            per_task_completed_max: task_completed.iter().copied().max().unwrap_or(0),
            per_signal_trade_callbacks_min: signal_trade_callbacks
                .iter()
                .copied()
                .min()
                .unwrap_or(0),
            per_signal_trade_callbacks_max: signal_trade_callbacks
                .iter()
                .copied()
                .max()
                .unwrap_or(0),
            per_signal_private_callbacks_min: signal_private_callbacks
                .iter()
                .copied()
                .min()
                .unwrap_or(0),
            per_signal_private_callbacks_max: signal_private_callbacks
                .iter()
                .copied()
                .max()
                .unwrap_or(0),
            elapsed,
            wall_throughput_ticks_s: self.ticks.len() as f64 / elapsed.as_secs_f64(),
            public_decode_ns,
            tick_to_order_ns,
            tick_to_ack_ns,
            tick_to_fill_ns,
            risk_commands: counters.risk_commands,
            execution_commands: counters.execution_commands,
        })
    }
}

pub(crate) fn percentile(sorted: &[u64], percentile: f64) -> u64 {
    if sorted.is_empty() {
        return 0;
    }
    let rank = (percentile.clamp(0.0, 1.0) * sorted.len() as f64).ceil() as usize;
    sorted[rank.saturating_sub(1).min(sorted.len() - 1)]
}
