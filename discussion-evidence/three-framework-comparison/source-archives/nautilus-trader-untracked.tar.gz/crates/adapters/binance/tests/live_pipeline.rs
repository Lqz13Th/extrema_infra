// -------------------------------------------------------------------------------------------------
//  Copyright (C) 2015-2026 Nautech Systems Pty Ltd. All rights reserved.
//  https://nautechsystems.io
//
//  Licensed under the GNU Lesser General Public License Version 3.0 (the "License");
//  You may not use this file except in compliance with the License.
//  You may obtain a copy of the License at https://www.gnu.org/licenses/lgpl-3.0.en.html
// -------------------------------------------------------------------------------------------------

#![recursion_limit = "256"]

#[path = "../benches/live_pipeline/support.rs"]
mod support;

use std::time::Duration;

use support::{LiveMode, LiveScenario, LiveTopology, PipelineConfig, percentile, run_pipeline};

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn live_pipeline_routes_two_tasks_across_six_instruments_without_loss() {
    for mode in [LiveMode::Stress, LiveMode::MixedLive] {
        assert!(!mode.as_str().is_empty());
        let config = PipelineConfig {
            tasks: 2,
            instruments_per_task: 3,
            messages_per_instrument: 4,
            topology: LiveTopology::SharedHandler,
            mode,
            order_every: 3,
            scenario: LiveScenario::Success,
            reject_every: 2,
            signal_compute_ns: 0,
            timeout: Duration::from_secs(10),
        };
        assert_eq!(config.scenario.as_str(), "success");
        let mut report = run_pipeline(config).await.unwrap();
        report.validate(config).unwrap();
        report.sort_latencies();
        assert_eq!(report.total_ticks, 24);
        assert_eq!(
            report.expected_orders,
            if mode == LiveMode::Stress { 24 } else { 6 }
        );
        assert_eq!(report.public_parsed, 24);
        assert_eq!(report.trade_callbacks, 24);
        assert_eq!(report.trade_task_keys, 0);
        assert_eq!(report.public_cooperative_yields, 24);
        assert_eq!(report.account_broadcast_rings, 0);
        assert_eq!(report.account_receivers_per_ring, 0);
        assert_eq!(report.account_handlers_per_fanout_domain, 1);
        assert_eq!(report.account_non_owner_subscribers_per_topic, 0);
        assert_eq!(report.drops, 0);
        assert_eq!(report.duplicates, 0);
        assert_eq!(report.route_errors, 0);
        assert_eq!(report.per_task_sent_min, 12);
        assert_eq!(report.per_task_sent_max, 12);
        assert_eq!(report.per_task_completed_min, 12);
        assert_eq!(report.per_task_completed_max, 12);
        assert_eq!(report.per_signal_trade_callbacks_min, 24);
        assert_eq!(report.per_signal_trade_callbacks_max, 24);
        assert_eq!(
            report.per_signal_private_callbacks_min,
            report.private_frames_parsed
        );
        assert_eq!(
            report.per_signal_private_callbacks_max,
            report.private_frames_parsed
        );
        assert!(report.max_in_flight > 0);
        assert!(report.wall_throughput_ticks_s.is_finite());
        assert!(
            percentile(&report.public_decode_ns, 0.5)
                <= report.public_decode_ns.last().copied().unwrap()
        );
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn live_pipeline_counts_deterministic_business_rejections_separately() {
    let config = PipelineConfig {
        tasks: 2,
        instruments_per_task: 3,
        messages_per_instrument: 2,
        topology: LiveTopology::SharedHandler,
        mode: LiveMode::Stress,
        order_every: 20,
        scenario: LiveScenario::BusinessError,
        reject_every: 2,
        signal_compute_ns: 0,
        timeout: Duration::from_secs(10),
    };
    let report = run_pipeline(config).await.unwrap();
    report.validate(config).unwrap();
    assert_eq!(report.total_ticks, 12);
    assert_eq!(report.expected_orders, 12);
    assert_eq!(report.business_errors, 6);
    assert_eq!(report.rejections, 6);
    assert_eq!(report.expected_success_orders, 6);
    assert_eq!(report.acks, 6);
    assert_eq!(report.fills, 6);
    assert_eq!(report.private_frames_parsed, 18);
    assert_eq!(report.per_signal_trade_callbacks_min, 12);
    assert_eq!(report.per_signal_trade_callbacks_max, 12);
    assert_eq!(report.per_signal_private_callbacks_min, 18);
    assert_eq!(report.per_signal_private_callbacks_max, 18);
    assert_eq!(report.drops, 0);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 8)]
async fn batch_sharded_routes_two_batches_through_five_strategies_each() {
    let config = PipelineConfig {
        tasks: 2,
        instruments_per_task: 20,
        messages_per_instrument: 2,
        topology: LiveTopology::BatchSharded,
        mode: LiveMode::MixedLive,
        order_every: 2,
        scenario: LiveScenario::Success,
        reject_every: 2,
        signal_compute_ns: 0,
        timeout: Duration::from_secs(20),
    };
    let report = run_pipeline(config).await.unwrap();
    report.validate(config).unwrap();

    assert_eq!(report.total_ticks, 80);
    assert_eq!(report.expected_orders, 40);
    assert_eq!(report.batch_count, 2);
    assert_eq!(report.live_nodes, 2);
    assert_eq!(report.engine_threads, 2);
    assert_eq!(report.producer_tasks, 40);
    assert_eq!(report.trade_task_keys, 0);
    assert_eq!(report.trade_ingress_lanes, 40);
    assert_eq!(report.public_cooperative_yields, 80);
    assert_eq!(report.signal_handlers, 10);
    assert_eq!(report.instruments_per_handler, 4);
    assert_eq!(report.account_ingress_tasks, 2);
    assert_eq!(report.account_ingress_lanes, 2);
    assert_eq!(report.order_runners, 2);
    assert_eq!(report.private_ingress_capacity, 8_192);
    assert_eq!(report.account_broadcast_rings, 0);
    assert_eq!(report.account_broadcast_topics, 10);
    assert_eq!(report.account_fanout_domains, 2);
    assert_eq!(report.account_receivers_per_ring, 0);
    assert_eq!(report.account_handlers_per_fanout_domain, 5);
    assert_eq!(report.account_non_owner_subscribers_per_topic, 4);
    assert_eq!(report.account_observation_sources, 80);
    assert_eq!(report.native_owner_callbacks, 80);
    assert_eq!(report.account_non_owner_callbacks, 320);
    assert_eq!(report.account_observation_callbacks, 400);
    assert_eq!(report.per_signal_trade_callbacks_min, 8);
    assert_eq!(report.per_signal_trade_callbacks_max, 8);
    assert_eq!(report.per_signal_private_callbacks_min, 40);
    assert_eq!(report.per_signal_private_callbacks_max, 40);
    assert_eq!(report.cross_batch_errors, 0);
    assert_eq!(report.drops, 0);
    assert_eq!(report.duplicates, 0);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 8)]
async fn batch_sharded_conserves_business_errors_without_cross_batch_delivery() {
    let config = PipelineConfig {
        tasks: 2,
        instruments_per_task: 20,
        messages_per_instrument: 1,
        topology: LiveTopology::BatchSharded,
        mode: LiveMode::Stress,
        order_every: 20,
        scenario: LiveScenario::BusinessError,
        reject_every: 2,
        signal_compute_ns: 0,
        timeout: Duration::from_secs(20),
    };
    let report = run_pipeline(config).await.unwrap();
    report.validate(config).unwrap();

    assert_eq!(report.total_ticks, 40);
    assert_eq!(report.expected_orders, 40);
    assert_eq!(report.business_errors, 20);
    assert_eq!(report.rejections, 20);
    assert_eq!(report.expected_success_orders, 20);
    assert_eq!(report.acks, 20);
    assert_eq!(report.fills, 20);
    assert_eq!(report.private_frames_parsed, 60);
    assert_eq!(report.account_observation_sources, 60);
    assert_eq!(report.native_owner_callbacks, 60);
    assert_eq!(report.account_non_owner_callbacks, 240);
    assert_eq!(report.expected_account_callbacks, 300);
    assert_eq!(report.account_observation_callbacks, 300);
    assert_eq!(report.per_signal_trade_callbacks_min, 4);
    assert_eq!(report.per_signal_trade_callbacks_max, 4);
    assert_eq!(report.per_signal_private_callbacks_min, 30);
    assert_eq!(report.per_signal_private_callbacks_max, 30);
    assert_eq!(report.cross_batch_errors, 0);
    assert_eq!(report.route_errors, 0);
    assert_eq!(report.drops, 0);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 8)]
async fn ws5_strategy20_routes_twenty_public_ws_tasks_to_twenty_strategies() {
    let config = PipelineConfig {
        tasks: 20,
        instruments_per_task: 5,
        messages_per_instrument: 1,
        topology: LiveTopology::Ws5Strategy20,
        mode: LiveMode::Stress,
        order_every: 20,
        scenario: LiveScenario::Success,
        reject_every: 2,
        signal_compute_ns: 0,
        timeout: Duration::from_secs(30),
    };
    assert_eq!(config.topology.as_str(), "ws5_strategy20");
    let report = run_pipeline(config).await.unwrap();
    report.validate(config).unwrap();

    assert_eq!(report.total_ticks, 100);
    assert_eq!(report.expected_orders, 100);
    assert_eq!(report.expected_success_orders, 100);
    assert_eq!(report.batch_count, 1);
    assert_eq!(report.live_nodes, 1);
    assert_eq!(report.engine_threads, 1);
    assert_eq!(report.physical_sockets, 0);
    assert_eq!(report.producer_tasks, 20);
    assert_eq!(report.public_ws_tasks, 20);
    assert_eq!(report.public_ws_tasks_per_fanout_domain, 20);
    assert_eq!(report.symbols_per_public_ws, 5);
    assert_eq!(report.symbols_per_signal_handler, 5);
    assert_eq!(report.trade_ingress_lanes, 20);
    assert_eq!(report.public_cooperative_yields, 100);
    assert_eq!(report.signal_handlers, 20);
    assert_eq!(report.strategy_handlers, 20);
    assert_eq!(report.trade_lanes_per_signal_handler, 1);
    assert_eq!(report.instruments_per_handler, 5);
    assert_eq!(report.per_signal_trade_callbacks_min, 5);
    assert_eq!(report.per_signal_trade_callbacks_max, 5);
    assert_eq!(report.account_ingress_tasks, 1);
    assert_eq!(report.account_ingress_lanes, 1);
    assert_eq!(report.order_runners, 1);
    assert_eq!(report.account_broadcast_topics, 20);
    assert_eq!(report.account_fanout_domains, 1);
    assert_eq!(report.account_handlers_per_fanout_domain, 20);
    assert_eq!(report.account_non_owner_subscribers_per_topic, 19);
    assert_eq!(report.private_frames_parsed, 200);
    assert_eq!(report.account_observation_sources, 200);
    assert_eq!(report.native_owner_callbacks, 200);
    assert_eq!(report.account_non_owner_callbacks, 3_800);
    assert_eq!(report.expected_account_callbacks, 4_000);
    assert_eq!(report.account_observation_callbacks, 4_000);
    assert_eq!(report.per_signal_private_callbacks_min, 200);
    assert_eq!(report.per_signal_private_callbacks_max, 200);
    assert_eq!(report.per_task_sent_min, 5);
    assert_eq!(report.per_task_sent_max, 5);
    assert_eq!(report.per_task_completed_min, 5);
    assert_eq!(report.per_task_completed_max, 5);
    assert_eq!(report.cross_batch_errors, 0);
    assert_eq!(report.route_errors, 0);
    assert_eq!(report.drops, 0);
    assert_eq!(report.duplicates, 0);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 8)]
async fn ws5_strategy20_runs_signal_compute_for_order_and_no_order_ticks() {
    let config = PipelineConfig {
        tasks: 20,
        instruments_per_task: 5,
        messages_per_instrument: 2,
        topology: LiveTopology::Ws5Strategy20,
        mode: LiveMode::MixedLive,
        order_every: 2,
        scenario: LiveScenario::Success,
        reject_every: 2,
        signal_compute_ns: 1_000,
        timeout: Duration::from_secs(30),
    };
    let report = run_pipeline(config).await.unwrap();
    report.validate(config).unwrap();

    assert_eq!(report.total_ticks, 200);
    assert_eq!(report.expected_orders, 100);
    assert_eq!(report.trade_callbacks, 200);
    assert_eq!(report.signal_compute_ns, 1_000);
    assert_eq!(report.signal_compute_calls, 200);
    assert_eq!(report.per_signal_trade_callbacks_min, 10);
    assert_eq!(report.per_signal_trade_callbacks_max, 10);
    assert_eq!(report.drops, 0);
    assert_eq!(report.duplicates, 0);
    assert_eq!(report.route_errors, 0);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 8)]
async fn ws5_strategy20_fans_business_errors_out_to_all_twenty_strategies() {
    let config = PipelineConfig {
        tasks: 20,
        instruments_per_task: 5,
        messages_per_instrument: 1,
        topology: LiveTopology::Ws5Strategy20,
        mode: LiveMode::Stress,
        order_every: 20,
        scenario: LiveScenario::BusinessError,
        reject_every: 2,
        signal_compute_ns: 0,
        timeout: Duration::from_secs(30),
    };
    let report = run_pipeline(config).await.unwrap();
    report.validate(config).unwrap();

    assert_eq!(report.total_ticks, 100);
    assert_eq!(report.expected_orders, 100);
    assert_eq!(report.business_errors, 50);
    assert_eq!(report.rejections, 50);
    assert_eq!(report.expected_success_orders, 50);
    assert_eq!(report.acks, 50);
    assert_eq!(report.fills, 50);
    assert_eq!(report.private_frames_parsed, 150);
    assert_eq!(report.account_observation_sources, 150);
    assert_eq!(report.native_owner_callbacks, 150);
    assert_eq!(report.account_non_owner_callbacks, 2_850);
    assert_eq!(report.expected_account_callbacks, 3_000);
    assert_eq!(report.account_observation_callbacks, 3_000);
    assert_eq!(report.per_signal_trade_callbacks_min, 5);
    assert_eq!(report.per_signal_trade_callbacks_max, 5);
    assert_eq!(report.per_signal_private_callbacks_min, 150);
    assert_eq!(report.per_signal_private_callbacks_max, 150);
    assert_eq!(report.cross_batch_errors, 0);
    assert_eq!(report.route_errors, 0);
    assert_eq!(report.drops, 0);
    assert_eq!(report.duplicates, 0);
}
