// -------------------------------------------------------------------------------------------------
//  Copyright (C) 2015-2026 Nautech Systems Pty Ltd. All rights reserved.
//  https://nautechsystems.io
//
//  Licensed under the GNU Lesser General Public License Version 3.0 (the "License");
//  You may not use this file except in compliance with the License.
//  You may obtain a copy of the License at https://www.gnu.org/licenses/lgpl-3.0.en.html
// -------------------------------------------------------------------------------------------------

#[path = "../benches/tick_to_trade/support.rs"]
mod support;

use std::time::Duration;

use support::{ScenarioConfig, ScenarioSelection, percentile, run_scenario, scenario_configs};

#[tokio::test(flavor = "multi_thread", worker_threads = 16)]
async fn native_tick_to_order_path_conserves_unloaded_and_saturated_events() {
    for config in [
        ScenarioConfig {
            producers: 1,
            messages_per_producer: 8,
            one_in_flight: true,
            timeout: Duration::from_secs(5),
        },
        ScenarioConfig {
            producers: 16,
            messages_per_producer: 8,
            one_in_flight: false,
            timeout: Duration::from_secs(5),
        },
    ] {
        let expected = config.producers * config.messages_per_producer;
        let report = run_scenario(config).await.unwrap();
        report.validate(expected).unwrap();
        assert_eq!(report.execution_commands, expected as u64);
        assert_eq!(report.risk_commands, 0);
        assert_eq!(config.queue_inclusive(), !config.one_in_flight);
        assert!(report.phase_start_ns > 0);
        assert!(report.last_endpoint_ns >= report.phase_start_ns);
        assert!(report.measured_elapsed > Duration::ZERO);
        assert!(report.latencies_ns.iter().all(|latency| *latency > 0));
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 16)]
async fn saturated_producer_ladder_conserves_events() {
    for producers in [1, 5, 10, 16, 32, 64] {
        let config = ScenarioConfig {
            producers,
            messages_per_producer: 1,
            one_in_flight: false,
            timeout: Duration::from_secs(5),
        };
        let report = run_scenario(config).await.unwrap();
        report.validate(producers).unwrap();
        assert_eq!(report.execution_commands, producers as u64);
        assert_eq!(report.risk_commands, 0);
    }
}

#[test]
fn scenario_selection_preserves_defaults_and_allows_single_producer_saturation() {
    let timeout = Duration::from_secs(5);
    let defaults = scenario_configs(ScenarioSelection::All, 16, 8, timeout);
    assert_eq!(defaults.len(), 2);
    assert_eq!(defaults[0].0, "unloaded");
    assert_eq!(defaults[0].1.producers, 1);
    assert!(defaults[0].1.one_in_flight);
    assert_eq!(defaults[1].0, "saturated");
    assert_eq!(defaults[1].1.producers, 16);
    assert!(!defaults[1].1.one_in_flight);

    let single = scenario_configs(ScenarioSelection::Saturated, 1, 8, timeout);
    assert_eq!(single.len(), 1);
    assert_eq!(single[0].1.producers, 1);
    assert!(!single[0].1.one_in_flight);

    assert_eq!(
        "unloaded".parse::<ScenarioSelection>().unwrap(),
        ScenarioSelection::Unloaded
    );
    assert_eq!(
        "SATURATED".parse::<ScenarioSelection>().unwrap(),
        ScenarioSelection::Saturated
    );
    assert!("other".parse::<ScenarioSelection>().is_err());
}

#[test]
fn percentile_uses_nearest_rank_over_sorted_samples() {
    let samples = [10, 20, 30, 40, 50];
    assert_eq!(percentile(&samples, 0.0), 10);
    assert_eq!(percentile(&samples, 0.5), 30);
    assert_eq!(percentile(&samples, 0.95), 50);
    assert_eq!(percentile(&samples, 1.0), 50);
    assert_eq!(percentile(&[10, 20], 0.5), 10);
}
