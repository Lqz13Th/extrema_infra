// -------------------------------------------------------------------------------------------------
//  Copyright (C) 2015-2026 Nautech Systems Pty Ltd. All rights reserved.
//  https://nautechsystems.io
//
//  Licensed under the GNU Lesser General Public License Version 3.0 (the "License");
//  You may not use this file except in compliance with the License.
//  You may obtain a copy of the License at https://www.gnu.org/licenses/lgpl-3.0.en.html
// -------------------------------------------------------------------------------------------------

mod support;

use std::time::Duration;

use serde_json::json;
use support::{
    ScenarioConfig, ScenarioReport, ScenarioSelection, percentile, run_scenario, scenario_configs,
};

const DEFAULT_MESSAGES_PER_PRODUCER: usize = 4096;
const DEFAULT_WARMUP_RUNS: usize = 1;
const DEFAULT_MEASURED_RUNS: usize = 5;
const DEFAULT_SATURATED_PRODUCERS: usize = 16;
const RUNTIME_WORKER_THREADS: usize = 16;

fn main() -> anyhow::Result<()> {
    let runtime = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(RUNTIME_WORKER_THREADS)
        .enable_all()
        .build()?;
    runtime.block_on(run())
}

async fn run() -> anyhow::Result<()> {
    let messages_per_producer = positive_env(
        &[
            "T2T_MESSAGES_PER_TASK",
            "NAUTILUS_T2T_MESSAGES_PER_PRODUCER",
        ],
        DEFAULT_MESSAGES_PER_PRODUCER,
    )?;
    let saturated_producers = positive_env(
        &[
            "T2T_PRODUCERS",
            "NAUTILUS_T2T_PRODUCERS",
            "NAUTILUS_T2T_SATURATED_PRODUCERS",
        ],
        DEFAULT_SATURATED_PRODUCERS,
    )?;
    let warmup_runs = nonnegative_env(
        &["T2T_WARMUP_RUNS", "NAUTILUS_T2T_WARMUP_RUNS"],
        DEFAULT_WARMUP_RUNS,
    )?;
    let measured_runs = positive_env(
        &["T2T_MEASURED_RUNS", "NAUTILUS_T2T_MEASURED_RUNS"],
        DEFAULT_MEASURED_RUNS,
    )?;
    let timeout = Duration::from_secs(positive_env(
        &["T2T_TIMEOUT_SECS", "NAUTILUS_T2T_TIMEOUT_SECS"],
        60,
    )? as u64);
    let scenario = scenario_env()?;

    for (scenario, config) in scenario_configs(
        scenario,
        saturated_producers,
        messages_per_producer,
        timeout,
    ) {
        for _ in 0..warmup_runs {
            let report = run_scenario(config).await?;
            validate_report(&report, config)?;
        }

        for run in 1..=measured_runs {
            let report = run_scenario(config).await?;
            validate_report(&report, config)?;
            print_report(scenario, run, warmup_runs, measured_runs, config, report);
        }
    }

    Ok(())
}

fn validate_report(report: &ScenarioReport, config: ScenarioConfig) -> anyhow::Result<()> {
    let expected = config.producers * config.messages_per_producer;
    report.validate(expected)?;
    anyhow::ensure!(
        report.risk_commands == 0,
        "live runner unexpectedly dispatched commands through RiskEngine"
    );
    anyhow::ensure!(
        report.execution_commands == expected as u64,
        "execution engine command count mismatch"
    );
    Ok(())
}

fn print_report(
    scenario: &str,
    run: usize,
    warmup_runs: usize,
    measured_runs: usize,
    config: ScenarioConfig,
    mut report: ScenarioReport,
) {
    report.latencies_ns.sort_unstable();
    let total = config.producers * config.messages_per_producer;
    let elapsed_ns = report.measured_elapsed.as_nanos().min(u128::from(u64::MAX)) as u64;
    let throughput_orders_per_second = total as f64 / report.measured_elapsed.as_secs_f64();
    let result = json!({
        "scenario": scenario,
        "run": run,
        "warmup_runs": warmup_runs,
        "measured_runs": measured_runs,
        "runtime_worker_threads": RUNTIME_WORKER_THREADS,
        "producer_tasks": config.producers,
        "producers": config.producers,
        "messages_per_task": config.messages_per_producer,
        "messages_per_producer": config.messages_per_producer,
        "one_in_flight": config.one_in_flight,
        "queue_inclusive": config.queue_inclusive(),
        "total_messages": total,
        "elapsed_ns": elapsed_ns,
        "phase_start_ns": report.phase_start_ns,
        "last_endpoint_ns": report.last_endpoint_ns,
        "throughput_orders_per_second": throughput_orders_per_second,
        "latency_ns": {
            "p50": percentile(&report.latencies_ns, 0.50),
            "p95": percentile(&report.latencies_ns, 0.95),
            "p99": percentile(&report.latencies_ns, 0.99),
            "max": report.latencies_ns.last().copied().unwrap_or(0),
        },
        "sent": report.sent,
        "strategy_callbacks": report.strategy_callbacks,
        "execution_calls": report.execution_calls,
        "unique_valid_execution_calls": report.unique_valid_execution_calls,
        "latency_samples": report.latencies_ns.len(),
        "risk_commands": report.risk_commands,
        "execution_commands": report.execution_commands,
        "duplicate_orders": report.duplicate_orders,
        "missing_orders": report.missing_orders,
        "route_mismatches": report.route_mismatches,
        "start_boundary": "before UnboundedSender<DataEvent>::send(Data::Trade)",
        "end_boundary": "BenchmarkExecutionClient::submit_order entry",
        "excluded": ["JSON decode", "network IO", "venue ACK", "fills", "PnL"],
    });
    println!("T2T_RESULT {result}");
}

fn scenario_env() -> anyhow::Result<ScenarioSelection> {
    let Some((name, value)) = first_env(&["T2T_SCENARIO", "NAUTILUS_T2T_SCENARIO"]) else {
        return Ok(ScenarioSelection::All);
    };

    value
        .parse()
        .map_err(|error| anyhow::anyhow!("invalid {name}={value:?}: {error}"))
}

fn positive_env(names: &[&str], default: usize) -> anyhow::Result<usize> {
    let value = nonnegative_env(names, default)?;
    anyhow::ensure!(value > 0, "{} must be greater than zero", names[0]);
    Ok(value)
}

fn nonnegative_env(names: &[&str], default: usize) -> anyhow::Result<usize> {
    first_env(names).map_or(Ok(default), |(name, value)| {
        value
            .parse()
            .map_err(|error| anyhow::anyhow!("invalid {name}={value:?}: {error}"))
    })
}

fn first_env<'a>(names: &'a [&'a str]) -> Option<(&'a str, String)> {
    names
        .iter()
        .find_map(|name| std::env::var(name).ok().map(|value| (*name, value)))
}
