// -------------------------------------------------------------------------------------------------
//  Copyright (C) 2015-2026 Nautech Systems Pty Ltd. All rights reserved.
//  https://nautechsystems.io
//
//  Licensed under the GNU Lesser General Public License Version 3.0 (the "License");
//  You may not use this file except in compliance with the License.
//  You may obtain a copy of the License at https://www.gnu.org/licenses/lgpl-3.0.en.html
// -------------------------------------------------------------------------------------------------

use std::{
    any::Any,
    collections::HashMap,
    fmt::Debug,
    str::FromStr,
    sync::{
        Arc, Mutex, OnceLock,
        atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering},
        mpsc,
    },
    thread,
    time::{Duration, Instant},
};

use async_trait::async_trait;
use nautilus_common::{
    actor::DataActor,
    cache::CacheView,
    clients::ExecutionClient,
    enums::Environment,
    factories::{ClientConfig, ExecutionClientFactory},
    live::runner::get_data_event_sender,
    logging::logger::LoggerConfig,
    messages::{DataEvent, execution::SubmitOrder},
};
use nautilus_core::UnixNanos;
use nautilus_live::{
    builder::LiveNodeBuilder,
    config::{LiveExecEngineConfig, LiveNodeConfig},
    node::{LiveNodeHandle, NodeState},
};
use nautilus_model::{
    accounts::AccountAny,
    data::{Data, trade::TradeTick},
    enums::{AggressorSide, OmsType, OrderSide, OrderType},
    identifiers::{
        AccountId, ClientId, ClientOrderId, InstrumentId, StrategyId, TradeId, TraderId,
    },
    instruments::{Instrument, InstrumentAny, stubs::crypto_perpetual_ethusdt},
    types::{AccountBalance, MarginBalance, Price, Quantity},
};
use nautilus_trading::{
    nautilus_strategy,
    strategy::{Strategy, StrategyConfig, StrategyCore},
};
use tokio::sync::{Barrier, Notify};

const CORRELATION_PREFIX: &str = "T2T-TICK-";
const ORDER_PREFIX: &str = "T2T-ORDER-";
const CLIENT_ID: &str = "T2T-EXEC";
const ACCOUNT_ID: &str = "T2T-EXEC-001";
const STRATEGY_ID: &str = "T2T-STRATEGY-001";
const TRADER_ID: &str = "T2T-TRADER-001";

#[derive(Clone, Copy, Debug)]
pub(crate) struct ScenarioConfig {
    pub producers: usize,
    pub messages_per_producer: usize,
    pub one_in_flight: bool,
    pub timeout: Duration,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum ScenarioSelection {
    Unloaded,
    Saturated,
    All,
}

impl FromStr for ScenarioSelection {
    type Err = anyhow::Error;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        match value.to_ascii_lowercase().as_str() {
            "unloaded" => Ok(Self::Unloaded),
            "saturated" => Ok(Self::Saturated),
            "all" => Ok(Self::All),
            _ => anyhow::bail!("expected one of: unloaded, saturated, all"),
        }
    }
}

pub(crate) fn scenario_configs(
    selection: ScenarioSelection,
    saturated_producers: usize,
    messages_per_producer: usize,
    timeout: Duration,
) -> Vec<(&'static str, ScenarioConfig)> {
    let mut scenarios = Vec::with_capacity(2);

    if matches!(
        selection,
        ScenarioSelection::Unloaded | ScenarioSelection::All
    ) {
        scenarios.push((
            "unloaded",
            ScenarioConfig {
                producers: 1,
                messages_per_producer,
                one_in_flight: true,
                timeout,
            },
        ));
    }

    if matches!(
        selection,
        ScenarioSelection::Saturated | ScenarioSelection::All
    ) {
        scenarios.push((
            "saturated",
            ScenarioConfig {
                producers: saturated_producers,
                messages_per_producer,
                one_in_flight: false,
                timeout,
            },
        ));
    }

    scenarios
}

impl ScenarioConfig {
    pub(crate) const fn queue_inclusive(&self) -> bool {
        !self.one_in_flight
    }
}

#[derive(Clone, Debug, Default)]
pub(crate) struct ScenarioReport {
    pub sent: usize,
    pub strategy_callbacks: usize,
    pub execution_calls: usize,
    pub unique_valid_execution_calls: usize,
    pub risk_commands: u64,
    pub execution_commands: u64,
    pub duplicate_orders: usize,
    pub missing_orders: usize,
    pub route_mismatches: usize,
    pub phase_start_ns: u64,
    pub last_endpoint_ns: u64,
    pub measured_elapsed: Duration,
    pub latencies_ns: Vec<u64>,
}

impl ScenarioReport {
    pub(crate) fn validate(&self, expected: usize) -> anyhow::Result<()> {
        anyhow::ensure!(self.sent == expected, "sent count mismatch");
        anyhow::ensure!(
            self.strategy_callbacks == expected,
            "strategy callback count mismatch"
        );
        anyhow::ensure!(
            self.execution_calls == expected,
            "execution call count mismatch"
        );
        anyhow::ensure!(
            self.unique_valid_execution_calls == expected,
            "unique valid execution count mismatch"
        );
        anyhow::ensure!(self.duplicate_orders == 0, "duplicate orders observed");
        anyhow::ensure!(self.missing_orders == 0, "missing orders observed");
        anyhow::ensure!(self.route_mismatches == 0, "order route mismatch");
        anyhow::ensure!(self.phase_start_ns > 0, "phase start was not recorded");
        anyhow::ensure!(
            self.last_endpoint_ns >= self.phase_start_ns,
            "last endpoint preceded phase start"
        );
        anyhow::ensure!(
            self.measured_elapsed > Duration::ZERO,
            "wall duration was zero"
        );
        anyhow::ensure!(
            self.measured_elapsed.as_nanos()
                == u128::from(self.last_endpoint_ns - self.phase_start_ns),
            "wall duration does not match endpoint boundary"
        );
        anyhow::ensure!(
            self.latencies_ns.len() == expected,
            "latency sample count mismatch"
        );
        anyhow::ensure!(
            self.latencies_ns.iter().all(|latency| *latency > 0),
            "non-positive latency sample observed"
        );
        Ok(())
    }
}

#[derive(Debug)]
struct BenchmarkState {
    epoch: Instant,
    expected: usize,
    one_in_flight: bool,
    correlations: Vec<CorrelationSpec>,
    correlation_by_trade_id: HashMap<TradeId, usize>,
    starts_ns: Vec<AtomicU64>,
    acknowledgements: Vec<Notify>,
    all_executed: Notify,
    fatal: AtomicBool,
    fatal_notify: Notify,
    fatal_message: Mutex<Option<String>>,
    phase_start_ns: AtomicU64,
    last_endpoint_ns: AtomicU64,
    prepared_event_count: AtomicUsize,
    sent_count: AtomicUsize,
    strategy_callback_count: AtomicUsize,
    raw_execution_count: AtomicUsize,
    unique_valid_execution_count: AtomicUsize,
    duplicate_orders: AtomicUsize,
    route_mismatches: AtomicUsize,
    sent_correlations: Vec<AtomicBool>,
    callback_correlations: Vec<AtomicBool>,
    execution_correlations: Vec<AtomicBool>,
    immediate_endpoint_correlations: Vec<AtomicBool>,
    strategy_records: Mutex<Vec<(usize, TradeTick)>>,
    execution_observations: Box<[OnceLock<ObservedExecution>]>,
    latencies_ns: Mutex<Vec<u64>>,
}

#[derive(Clone, Copy, Debug)]
struct CorrelationSpec {
    trade_id: TradeId,
    client_order_id: ClientOrderId,
}

#[derive(Debug)]
struct ObservedExecution {
    end_ns: u64,
    command: SubmitOrder,
}

impl BenchmarkState {
    fn new(expected: usize, one_in_flight: bool) -> Self {
        let correlations: Vec<_> = (0..expected)
            .map(|correlation| CorrelationSpec {
                trade_id: TradeId::from(format!("{CORRELATION_PREFIX}{correlation}").as_str()),
                client_order_id: ClientOrderId::from(
                    format!("{ORDER_PREFIX}{correlation}").as_str(),
                ),
            })
            .collect();
        let correlation_by_trade_id = correlations
            .iter()
            .enumerate()
            .map(|(correlation, spec)| (spec.trade_id, correlation))
            .collect();
        Self {
            epoch: Instant::now(),
            expected,
            one_in_flight,
            correlations,
            correlation_by_trade_id,
            starts_ns: (0..expected).map(|_| AtomicU64::new(0)).collect(),
            acknowledgements: (0..expected).map(|_| Notify::new()).collect(),
            all_executed: Notify::new(),
            fatal: AtomicBool::new(false),
            fatal_notify: Notify::new(),
            fatal_message: Mutex::new(None),
            phase_start_ns: AtomicU64::new(0),
            last_endpoint_ns: AtomicU64::new(0),
            prepared_event_count: AtomicUsize::new(0),
            sent_count: AtomicUsize::new(0),
            strategy_callback_count: AtomicUsize::new(0),
            raw_execution_count: AtomicUsize::new(0),
            unique_valid_execution_count: AtomicUsize::new(0),
            duplicate_orders: AtomicUsize::new(0),
            route_mismatches: AtomicUsize::new(0),
            sent_correlations: (0..expected).map(|_| AtomicBool::new(false)).collect(),
            callback_correlations: (0..expected).map(|_| AtomicBool::new(false)).collect(),
            execution_correlations: (0..expected).map(|_| AtomicBool::new(false)).collect(),
            immediate_endpoint_correlations: (0..expected)
                .map(|_| AtomicBool::new(false))
                .collect(),
            strategy_records: Mutex::new(Vec::with_capacity(expected)),
            execution_observations: (0..expected)
                .map(|_| OnceLock::new())
                .collect::<Vec<_>>()
                .into_boxed_slice(),
            latencies_ns: Mutex::new(Vec::with_capacity(expected)),
        }
    }

    fn monotonic_ns(&self) -> u64 {
        self.epoch.elapsed().as_nanos().min(u128::from(u64::MAX)) as u64
    }

    fn record_sent(&self, correlation: usize) {
        let start_ns = self.monotonic_ns();
        let phase_start_ns = self.phase_start_ns.load(Ordering::Acquire);
        assert!(
            phase_start_ns > 0 && start_ns >= phase_start_ns,
            "message start {start_ns} preceded phase start {phase_start_ns}"
        );
        self.starts_ns[correlation].store(start_ns, Ordering::Release);
        self.sent_count.fetch_add(1, Ordering::Relaxed);
        if self.sent_correlations[correlation].swap(true, Ordering::Relaxed) {
            self.duplicate_orders.fetch_add(1, Ordering::Relaxed);
        }
    }

    fn correlation_for_trade_id(&self, trade_id: TradeId) -> Option<usize> {
        self.correlation_by_trade_id.get(&trade_id).copied()
    }

    fn record_strategy_callback(&self, correlation: usize, tick: TradeTick) -> anyhow::Result<()> {
        self.strategy_callback_count.fetch_add(1, Ordering::Relaxed);
        if self.callback_correlations[correlation].swap(true, Ordering::Relaxed) {
            self.duplicate_orders.fetch_add(1, Ordering::Relaxed);
            let error = format!("duplicate strategy correlation {correlation}");
            self.set_fatal(error.clone());
            anyhow::bail!(error);
        }
        self.strategy_records
            .lock()
            .expect("strategy records mutex poisoned")
            .push((correlation, tick));
        Ok(())
    }

    fn record_execution_entry(&self, cmd: SubmitOrder) {
        let end_ns = self.monotonic_ns();
        let arrival_index = self.raw_execution_count.fetch_add(1, Ordering::AcqRel);
        let Some(observation) = self.execution_observations.get(arrival_index) else {
            self.set_fatal(format!(
                "execution calls exceeded expected count {}",
                self.expected
            ));
            return;
        };
        let unloaded_correlation = if self.one_in_flight {
            parse_correlation(cmd.client_order_id.as_str(), ORDER_PREFIX)
        } else {
            None
        };
        if observation
            .set(ObservedExecution {
                end_ns,
                command: cmd,
            })
            .is_err()
        {
            self.set_fatal(format!(
                "execution observation slot {arrival_index} was initialized more than once"
            ));
            return;
        }
        if arrival_index + 1 == self.expected {
            self.all_executed.notify_one();
        }

        if self.one_in_flight {
            let Some(correlation) = unloaded_correlation.filter(|value| *value < self.expected)
            else {
                self.set_fatal("invalid unloaded execution correlation");
                return;
            };
            if self.immediate_endpoint_correlations[correlation].swap(true, Ordering::AcqRel) {
                self.duplicate_orders.fetch_add(1, Ordering::Relaxed);
                self.set_fatal(format!(
                    "duplicate unloaded execution correlation {correlation}"
                ));
                return;
            }
            self.acknowledgements[correlation].notify_one();
        }
    }

    fn mark_route_mismatch(&self) {
        self.route_mismatches.fetch_add(1, Ordering::Relaxed);
    }

    fn set_fatal(&self, message: impl Into<String>) {
        let mut fatal_message = self
            .fatal_message
            .lock()
            .expect("fatal message mutex poisoned");
        if self.fatal.load(Ordering::Acquire) {
            return;
        }
        *fatal_message = Some(message.into());
        self.fatal.store(true, Ordering::Release);
        drop(fatal_message);
        self.fatal_notify.notify_waiters();
        self.fatal_notify.notify_one();
    }

    fn check_fatal(&self) -> anyhow::Result<()> {
        if !self.fatal.load(Ordering::Acquire) {
            return Ok(());
        }
        let message = self
            .fatal_message
            .lock()
            .expect("fatal message mutex poisoned")
            .clone()
            .unwrap_or_else(|| "benchmark entered fatal state".to_string());
        anyhow::bail!(message)
    }

    async fn wait_for_ack_or_fatal(&self, correlation: usize) -> anyhow::Result<()> {
        self.check_fatal()?;
        tokio::select! {
            () = self.acknowledgements[correlation].notified() => self.check_fatal(),
            () = self.fatal_notify.notified() => self.check_fatal(),
        }
    }

    async fn wait_for_all_executed_or_fatal(&self) -> anyhow::Result<()> {
        self.check_fatal()?;
        tokio::select! {
            () = self.all_executed.notified() => self.check_fatal(),
            () = self.fatal_notify.notified() => self.check_fatal(),
        }
    }

    fn validate_offline(&self) -> anyhow::Result<()> {
        self.check_fatal()?;
        anyhow::ensure!(
            self.prepared_event_count.load(Ordering::Acquire) == self.expected,
            "prepared event count mismatch"
        );
        anyhow::ensure!(
            self.sent_count.load(Ordering::Acquire) == self.expected,
            "sent count mismatch before offline validation"
        );
        anyhow::ensure!(
            self.strategy_callback_count.load(Ordering::Acquire) == self.expected,
            "strategy callback count mismatch before offline validation"
        );
        anyhow::ensure!(
            self.raw_execution_count.load(Ordering::Acquire) == self.expected,
            "execution call count mismatch before offline validation"
        );
        anyhow::ensure!(
            self.sent_correlations
                .iter()
                .all(|seen| seen.load(Ordering::Acquire)),
            "sent correlation conservation mismatch"
        );
        anyhow::ensure!(
            self.callback_correlations
                .iter()
                .all(|seen| seen.load(Ordering::Acquire)),
            "callback correlation conservation mismatch"
        );

        let strategy_records = self
            .strategy_records
            .lock()
            .expect("strategy records mutex poisoned");
        anyhow::ensure!(
            strategy_records.len() == self.expected,
            "strategy record count mismatch"
        );
        let mut seen_strategy = vec![false; self.expected];
        for (correlation, tick) in strategy_records.iter() {
            anyhow::ensure!(
                *correlation < self.expected,
                "strategy correlation out of range"
            );
            anyhow::ensure!(
                !std::mem::replace(&mut seen_strategy[*correlation], true),
                "duplicate strategy correlation"
            );
            anyhow::ensure!(
                tick_matches_expectation(tick, self.correlations[*correlation]),
                "strategy tick content mismatch for correlation {correlation}"
            );
        }
        drop(strategy_records);

        anyhow::ensure!(
            self.execution_observations.len() == self.expected,
            "execution observation slot count mismatch"
        );
        let phase_start_ns = self.phase_start_ns.load(Ordering::Acquire);
        let mut seen_execution = vec![false; self.expected];
        let mut latencies_ns = Vec::with_capacity(self.expected);
        let mut max_endpoint_ns = 0;
        for (arrival_index, observation) in self.execution_observations.iter().enumerate() {
            let record = observation.get().ok_or_else(|| {
                anyhow::anyhow!("execution observation slot {arrival_index} was not initialized")
            })?;
            max_endpoint_ns = max_endpoint_ns.max(record.end_ns);
            let correlation =
                parse_correlation(record.command.client_order_id.as_str(), ORDER_PREFIX)
                    .ok_or_else(|| anyhow::anyhow!("invalid execution correlation"))?;
            anyhow::ensure!(
                correlation < self.expected,
                "execution correlation out of range"
            );
            anyhow::ensure!(
                !std::mem::replace(&mut seen_execution[correlation], true),
                "duplicate execution correlation"
            );
            anyhow::ensure!(
                command_matches_expectation(&record.command, self.correlations[correlation],),
                "execution route or order content mismatch for correlation {correlation}"
            );
            let start_ns = self.starts_ns[correlation].load(Ordering::Acquire);
            anyhow::ensure!(
                start_ns >= phase_start_ns && record.end_ns > start_ns,
                "invalid latency boundary for correlation {correlation}"
            );
            latencies_ns.push(record.end_ns - start_ns);
        }
        anyhow::ensure!(
            seen_strategy.iter().all(|seen| *seen) && seen_execution.iter().all(|seen| *seen),
            "offline correlation conservation mismatch"
        );

        for (correlation, seen) in seen_execution.into_iter().enumerate() {
            self.execution_correlations[correlation].store(seen, Ordering::Release);
        }
        *self.latencies_ns.lock().expect("latencies mutex poisoned") = latencies_ns;
        self.last_endpoint_ns
            .store(max_endpoint_ns, Ordering::Release);
        self.unique_valid_execution_count
            .store(self.expected, Ordering::Release);
        Ok(())
    }

    fn report(&self, elapsed: Duration, counters: EngineCounters) -> ScenarioReport {
        let missing_orders = (0..self.expected)
            .filter(|correlation| {
                !self.sent_correlations[*correlation].load(Ordering::Relaxed)
                    || !self.callback_correlations[*correlation].load(Ordering::Relaxed)
                    || !self.execution_correlations[*correlation].load(Ordering::Relaxed)
            })
            .count();

        ScenarioReport {
            sent: self.sent_count.load(Ordering::Relaxed),
            strategy_callbacks: self.strategy_callback_count.load(Ordering::Relaxed),
            execution_calls: self.raw_execution_count.load(Ordering::Relaxed),
            unique_valid_execution_calls: self.unique_valid_execution_count.load(Ordering::Relaxed),
            risk_commands: counters.risk_commands,
            execution_commands: counters.execution_commands,
            duplicate_orders: self.duplicate_orders.load(Ordering::Relaxed),
            missing_orders,
            route_mismatches: self.route_mismatches.load(Ordering::Relaxed),
            phase_start_ns: self.phase_start_ns.load(Ordering::Acquire),
            last_endpoint_ns: self.last_endpoint_ns.load(Ordering::Acquire),
            measured_elapsed: elapsed,
            latencies_ns: self
                .latencies_ns
                .lock()
                .expect("latencies mutex poisoned")
                .clone(),
        }
    }
}

#[derive(Debug)]
struct TickToTradeStrategy {
    core: StrategyCore,
    state: Arc<BenchmarkState>,
}

impl TickToTradeStrategy {
    fn new(state: Arc<BenchmarkState>) -> Self {
        Self {
            core: StrategyCore::new(StrategyConfig {
                strategy_id: Some(benchmark_strategy_id()),
                ..Default::default()
            }),
            state,
        }
    }
}

impl DataActor for TickToTradeStrategy {
    fn on_start(&mut self) -> anyhow::Result<()> {
        self.subscribe_trades(benchmark_instrument_id(), None, None);
        Ok(())
    }

    fn on_trade(&mut self, tick: &TradeTick) -> anyhow::Result<()> {
        let Some(correlation) = self.state.correlation_for_trade_id(tick.trade_id) else {
            self.state.set_fatal("unknown strategy trade correlation");
            anyhow::bail!("unknown strategy trade correlation");
        };
        let Some(order_side) = order_side_for_aggressor(tick.aggressor_side) else {
            self.state.set_fatal("unsupported strategy aggressor side");
            anyhow::bail!("unsupported strategy aggressor side");
        };
        self.state.record_strategy_callback(correlation, *tick)?;

        let client_order_id = self.state.correlations[correlation].client_order_id;
        let order = self.order().market(
            tick.instrument_id,
            order_side,
            tick.size,
            None,
            None,
            None,
            None,
            None,
            None,
            Some(client_order_id),
        );
        if let Err(error) = self.submit_order(order, None, Some(benchmark_client_id()), None) {
            self.state.mark_route_mismatch();
            self.state
                .set_fatal(format!("strategy order submission failed: {error}"));
            return Err(error);
        }
        Ok(())
    }
}

nautilus_strategy!(TickToTradeStrategy);

#[derive(Debug)]
struct BenchmarkExecutionClientConfig;

impl ClientConfig for BenchmarkExecutionClientConfig {
    fn as_any(&self) -> &dyn Any {
        self
    }
}

#[derive(Debug)]
struct BenchmarkExecutionClientFactory {
    state: Arc<BenchmarkState>,
}

impl ExecutionClientFactory for BenchmarkExecutionClientFactory {
    fn create(
        &self,
        _name: &str,
        _config: &dyn ClientConfig,
        _cache: CacheView,
    ) -> anyhow::Result<Box<dyn ExecutionClient>> {
        Ok(Box::new(BenchmarkExecutionClient {
            state: self.state.clone(),
            connected: AtomicBool::new(false),
        }))
    }

    fn name(&self) -> &'static str {
        "tick-to-trade"
    }

    fn config_type(&self) -> &'static str {
        stringify!(BenchmarkExecutionClientConfig)
    }
}

struct BenchmarkExecutionClient {
    state: Arc<BenchmarkState>,
    connected: AtomicBool,
}

#[async_trait(?Send)]
impl ExecutionClient for BenchmarkExecutionClient {
    fn is_connected(&self) -> bool {
        self.connected.load(Ordering::Acquire)
    }

    fn client_id(&self) -> ClientId {
        benchmark_client_id()
    }

    fn account_id(&self) -> AccountId {
        AccountId::from(ACCOUNT_ID)
    }

    fn venue(&self) -> nautilus_model::identifiers::Venue {
        benchmark_instrument_id().venue
    }

    fn oms_type(&self) -> OmsType {
        OmsType::Hedging
    }

    fn get_account(&self) -> Option<AccountAny> {
        None
    }

    fn generate_account_state(
        &self,
        _balances: Vec<AccountBalance>,
        _margins: Vec<MarginBalance>,
        _reported: bool,
        _ts_event: UnixNanos,
    ) -> anyhow::Result<()> {
        Ok(())
    }

    fn start(&mut self) -> anyhow::Result<()> {
        self.connected.store(true, Ordering::Release);
        Ok(())
    }

    fn stop(&mut self) -> anyhow::Result<()> {
        self.connected.store(false, Ordering::Release);
        Ok(())
    }

    async fn connect(&mut self) -> anyhow::Result<()> {
        self.connected.store(true, Ordering::Release);
        Ok(())
    }

    async fn disconnect(&mut self) -> anyhow::Result<()> {
        self.connected.store(false, Ordering::Release);
        Ok(())
    }

    fn submit_order(&self, cmd: SubmitOrder) -> anyhow::Result<()> {
        self.state.record_execution_entry(cmd);
        Ok(())
    }
}

#[derive(Clone, Copy, Debug)]
struct EngineCounters {
    risk_commands: u64,
    execution_commands: u64,
}

type ReadyResult = Result<
    (
        tokio::sync::mpsc::UnboundedSender<DataEvent>,
        LiveNodeHandle,
    ),
    String,
>;
type EngineCompletion = Result<EngineCounters, String>;

pub(crate) async fn run_scenario(config: ScenarioConfig) -> anyhow::Result<ScenarioReport> {
    anyhow::ensure!(config.producers > 0, "producers must be greater than zero");
    anyhow::ensure!(
        config.messages_per_producer > 0,
        "messages_per_producer must be greater than zero"
    );
    anyhow::ensure!(
        !config.one_in_flight || config.producers == 1,
        "one_in_flight requires exactly one producer"
    );

    let expected = config
        .producers
        .checked_mul(config.messages_per_producer)
        .ok_or_else(|| anyhow::anyhow!("message count overflow"))?;
    let state = Arc::new(BenchmarkState::new(expected, config.one_in_flight));
    let (ready_tx, ready_rx) = mpsc::sync_channel::<ReadyResult>(0);
    let (completion_tx, completion_rx) = mpsc::sync_channel::<EngineCompletion>(1);
    let engine_state = state.clone();
    let completion_state = state.clone();
    let engine_thread = thread::Builder::new()
        .name("nautilus-t2t-engine".to_string())
        .spawn(move || {
            let completion = match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                run_engine(engine_state, ready_tx)
            })) {
                Ok(result) => result.map_err(|error| format!("{error:#}")),
                Err(payload) => Err(format!(
                    "benchmark engine panicked: {}",
                    panic_payload_message(payload.as_ref())
                )),
            };
            if let Err(error) = &completion {
                completion_state.set_fatal(format!("benchmark engine failed: {error}"));
            } else if completion_state.raw_execution_count.load(Ordering::Acquire)
                < completion_state.expected
            {
                completion_state.set_fatal("benchmark engine completed before all submissions");
            }
            let _ = completion_tx.send(completion);
        })?;

    let ready = ready_rx.recv_timeout(config.timeout);
    let (sender, handle) = match ready {
        Ok(Ok(ready)) => ready,
        Ok(Err(error)) => {
            let completion =
                collect_engine_completion(engine_thread, &completion_rx, config.timeout, &state);
            return Err(match completion {
                Ok(_) => anyhow::anyhow!("benchmark engine startup failed: {error}"),
                Err(engine_error) => engine_error.context(error),
            });
        }
        Err(mpsc::RecvTimeoutError::Timeout) => {
            state.set_fatal("benchmark engine startup timed out");
            drop(ready_rx);
            drop(completion_rx);
            drop(engine_thread);
            anyhow::bail!(
                "timed out waiting for benchmark engine startup after {:?}",
                config.timeout
            );
        }
        Err(mpsc::RecvTimeoutError::Disconnected) => {
            let completion =
                collect_engine_completion(engine_thread, &completion_rx, config.timeout, &state);
            return Err(match completion {
                Ok(_) => anyhow::anyhow!("benchmark engine startup channel disconnected"),
                Err(engine_error) => {
                    engine_error.context("benchmark engine startup channel disconnected")
                }
            });
        }
    };

    let drive_result: anyhow::Result<()> = match tokio::time::timeout(config.timeout, async {
        wait_until_running(&handle).await?;
        drive_producers(config, sender, state.clone()).await
    })
    .await
    {
        Ok(result) => result,
        Err(_) => Err(anyhow::anyhow!(
            "tick-to-trade scenario timed out after {:?}",
            config.timeout
        )),
    };
    let validation_result = if drive_result.is_ok() {
        let result = state.validate_offline();
        if let Err(error) = &result {
            state.set_fatal(format!("offline validation failed: {error:#}"));
        }
        result
    } else {
        Ok(())
    };

    handle.stop();
    let counters_result =
        collect_engine_completion(engine_thread, &completion_rx, config.timeout, &state);
    drive_result?;
    validation_result?;
    let counters = counters_result?;
    let phase_start_ns = state.phase_start_ns.load(Ordering::Acquire);
    let last_endpoint_ns = state.last_endpoint_ns.load(Ordering::Acquire);
    let elapsed = Duration::from_nanos(last_endpoint_ns.saturating_sub(phase_start_ns));

    Ok(state.report(elapsed, counters))
}

fn collect_engine_completion(
    engine_thread: thread::JoinHandle<()>,
    completion_rx: &mpsc::Receiver<EngineCompletion>,
    timeout: Duration,
    state: &BenchmarkState,
) -> anyhow::Result<EngineCounters> {
    match completion_rx.recv_timeout(timeout) {
        Ok(completion) => {
            engine_thread
                .join()
                .map_err(|_| anyhow::anyhow!("benchmark engine thread panicked"))?;
            completion.map_err(anyhow::Error::msg)
        }
        Err(mpsc::RecvTimeoutError::Disconnected) => {
            state.set_fatal("benchmark engine completion channel disconnected");
            engine_thread
                .join()
                .map_err(|_| anyhow::anyhow!("benchmark engine thread panicked"))?;
            anyhow::bail!("benchmark engine completion channel disconnected")
        }
        Err(mpsc::RecvTimeoutError::Timeout) => {
            state.set_fatal(format!(
                "benchmark engine shutdown timed out after {timeout:?}"
            ));
            // The runner's sender is thread-local to the engine OS thread and cannot be
            // cleared safely from this caller. All external sender clones and producer
            // tasks are already dropped; detaching is the bounded fallback, and the
            // benchmark binary terminates on the returned error.
            drop(engine_thread);
            anyhow::bail!("benchmark engine shutdown timed out after {timeout:?}")
        }
    }
}

fn panic_payload_message(payload: &(dyn Any + Send)) -> String {
    if let Some(message) = payload.downcast_ref::<&str>() {
        (*message).to_string()
    } else if let Some(message) = payload.downcast_ref::<String>() {
        message.clone()
    } else {
        "unknown panic payload".to_string()
    }
}

fn run_engine(
    state: Arc<BenchmarkState>,
    ready_tx: mpsc::SyncSender<ReadyResult>,
) -> anyhow::Result<EngineCounters> {
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()?;
    runtime.block_on(async move {
        let setup = build_node(state);
        let mut node = match setup {
            Ok(node) => node,
            Err(error) => {
                let message = error.to_string();
                let _ = ready_tx.send(Err(message));
                return Err(error);
            }
        };
        let handle = node.handle();
        ready_tx
            .send(Ok((get_data_event_sender(), handle)))
            .map_err(|_| anyhow::anyhow!("benchmark driver dropped before engine startup"))?;

        node.run().await?;
        Ok(EngineCounters {
            risk_commands: node.kernel().risk_engine().borrow().command_count(),
            execution_commands: node.kernel().exec_engine().borrow().command_count(),
        })
    })
}

fn build_node(state: Arc<BenchmarkState>) -> anyhow::Result<nautilus_live::node::LiveNode> {
    let config = LiveNodeConfig {
        environment: Environment::Live,
        trader_id: benchmark_trader_id(),
        exec_engine: LiveExecEngineConfig {
            reconciliation: false,
            ..Default::default()
        },
        delay_post_stop: Duration::ZERO,
        timeout_disconnection: Duration::ZERO,
        logging: LoggerConfig {
            bypass_logging: true,
            ..Default::default()
        },
        ..Default::default()
    };
    let factory = BenchmarkExecutionClientFactory {
        state: state.clone(),
    };
    let mut node = LiveNodeBuilder::from_config(config)?
        .with_name("TickToTradeBenchmark")
        .add_exec_client(
            Some("tick-to-trade".to_string()),
            Box::new(factory),
            Box::new(BenchmarkExecutionClientConfig),
        )?
        .build()?;

    node.kernel()
        .cache()
        .borrow_mut()
        .add_instrument(InstrumentAny::CryptoPerpetual(crypto_perpetual_ethusdt()))?;
    node.add_strategy(TickToTradeStrategy::new(state))?;
    Ok(node)
}

async fn wait_until_running(handle: &LiveNodeHandle) -> anyhow::Result<()> {
    loop {
        match handle.state() {
            NodeState::Running => return Ok(()),
            NodeState::Stopped => anyhow::bail!("benchmark node stopped during startup"),
            _ => tokio::task::yield_now().await,
        }
    }
}

async fn drive_producers(
    config: ScenarioConfig,
    sender: tokio::sync::mpsc::UnboundedSender<DataEvent>,
    state: Arc<BenchmarkState>,
) -> anyhow::Result<()> {
    let producer_events = prebuild_producer_events(config, &state)?;
    let barrier = Arc::new(Barrier::new(config.producers + 1));
    let go = Arc::new(AtomicBool::new(false));
    let mut tasks = tokio::task::JoinSet::new();
    for events in producer_events {
        let sender = sender.clone();
        let state = state.clone();
        let barrier = barrier.clone();
        let go = go.clone();
        tasks.spawn(async move {
            barrier.wait().await;
            while !go.load(Ordering::Acquire) {
                tokio::task::yield_now().await;
            }
            for (correlation, event) in events {
                state.check_fatal()?;
                state.record_sent(correlation);
                sender
                    .send(event)
                    .map_err(|_| anyhow::anyhow!("benchmark data event channel closed"))?;
                if config.one_in_flight {
                    state.wait_for_ack_or_fatal(correlation).await?;
                }
            }
            anyhow::Ok(())
        });
    }

    barrier.wait().await;
    let phase_start_ns = state.monotonic_ns();
    anyhow::ensure!(phase_start_ns > 0, "phase start timestamp was zero");
    state
        .phase_start_ns
        .store(phase_start_ns, Ordering::Release);
    go.store(true, Ordering::Release);

    while let Some(task) = tasks.join_next().await {
        task.map_err(|error| anyhow::anyhow!("producer task failed: {error}"))??;
    }
    if !config.one_in_flight {
        state.wait_for_all_executed_or_fatal().await?;
    }
    state.check_fatal()?;
    Ok(())
}

fn prebuild_producer_events(
    config: ScenarioConfig,
    state: &BenchmarkState,
) -> anyhow::Result<Vec<Vec<(usize, DataEvent)>>> {
    anyhow::ensure!(
        state.phase_start_ns.load(Ordering::Acquire) == 0,
        "events must be prepared before the measured phase"
    );
    let mut producers = Vec::with_capacity(config.producers);
    for producer in 0..config.producers {
        let mut events = Vec::with_capacity(config.messages_per_producer);
        for offset in 0..config.messages_per_producer {
            let correlation = producer * config.messages_per_producer + offset;
            let trade = sample_trade(state.correlations[correlation].trade_id);
            events.push((correlation, DataEvent::Data(Data::Trade(trade))));
        }
        producers.push(events);
    }
    anyhow::ensure!(
        state.phase_start_ns.load(Ordering::Acquire) == 0,
        "measured phase started while events were being prepared"
    );
    state
        .prepared_event_count
        .store(state.expected, Ordering::Release);
    Ok(producers)
}

fn sample_trade(trade_id: TradeId) -> TradeTick {
    TradeTick {
        instrument_id: benchmark_instrument_id(),
        price: benchmark_price(),
        size: benchmark_quantity(),
        aggressor_side: AggressorSide::Buyer,
        trade_id,
        ts_event: UnixNanos::default(),
        ts_init: UnixNanos::default(),
    }
}

fn benchmark_instrument_id() -> InstrumentId {
    crypto_perpetual_ethusdt().id()
}

fn benchmark_strategy_id() -> StrategyId {
    StrategyId::from(STRATEGY_ID)
}

fn benchmark_trader_id() -> TraderId {
    TraderId::from(TRADER_ID)
}

fn benchmark_client_id() -> ClientId {
    ClientId::from(CLIENT_ID)
}

fn benchmark_price() -> Price {
    Price::from("1000.00")
}

fn benchmark_quantity() -> Quantity {
    Quantity::from(1)
}

const fn order_side_for_aggressor(aggressor_side: AggressorSide) -> Option<OrderSide> {
    match aggressor_side {
        AggressorSide::Buyer => Some(OrderSide::Buy),
        AggressorSide::Seller => Some(OrderSide::Sell),
        AggressorSide::NoAggressor => None,
    }
}

fn tick_matches_expectation(tick: &TradeTick, spec: CorrelationSpec) -> bool {
    tick.instrument_id == benchmark_instrument_id()
        && tick.price == benchmark_price()
        && tick.size == benchmark_quantity()
        && tick.aggressor_side == AggressorSide::Buyer
        && tick.trade_id == spec.trade_id
        && tick.ts_event == UnixNanos::default()
        && tick.ts_init == UnixNanos::default()
}

fn command_matches_expectation(cmd: &SubmitOrder, spec: CorrelationSpec) -> bool {
    cmd.trader_id == benchmark_trader_id()
        && cmd.instrument_id == benchmark_instrument_id()
        && cmd.strategy_id == benchmark_strategy_id()
        && cmd.client_id == Some(benchmark_client_id())
        && cmd.client_order_id == spec.client_order_id
        && cmd.order_init.trader_id == benchmark_trader_id()
        && cmd.order_init.strategy_id == benchmark_strategy_id()
        && cmd.order_init.instrument_id == benchmark_instrument_id()
        && cmd.order_init.client_order_id == spec.client_order_id
        && cmd.order_init.order_side == OrderSide::Buy
        && cmd.order_init.quantity == benchmark_quantity()
        && cmd.order_init.order_type == OrderType::Market
        && cmd.order_init.price.is_none()
}

fn parse_correlation(value: &str, prefix: &str) -> Option<usize> {
    value.strip_prefix(prefix)?.parse().ok()
}

pub(crate) fn percentile(sorted: &[u64], percentile: f64) -> u64 {
    if sorted.is_empty() {
        return 0;
    }
    if percentile.is_nan() || percentile <= 0.0 {
        return sorted[0];
    }
    let rank = (percentile.min(1.0) * sorted.len() as f64).ceil() as usize;
    sorted[rank.saturating_sub(1).min(sorted.len() - 1)]
}

#[cfg(test)]
#[allow(dead_code)]
mod tests {
    use super::*;
    use nautilus_core::UUID4;
    use nautilus_model::events::order::spec::OrderInitializedSpec;

    fn valid_command(state: &BenchmarkState, correlation: usize) -> SubmitOrder {
        let spec = state.correlations[correlation];
        let order_init = OrderInitializedSpec::builder()
            .trader_id(benchmark_trader_id())
            .strategy_id(benchmark_strategy_id())
            .instrument_id(benchmark_instrument_id())
            .client_order_id(spec.client_order_id)
            .order_side(OrderSide::Buy)
            .order_type(OrderType::Market)
            .quantity(benchmark_quantity())
            .build();
        SubmitOrder::new(
            benchmark_trader_id(),
            Some(benchmark_client_id()),
            benchmark_strategy_id(),
            benchmark_instrument_id(),
            spec.client_order_id,
            order_init,
            None,
            None,
            None,
            UUID4::new(),
            UnixNanos::default(),
            None,
        )
    }

    fn seed_offline_state(expected: usize) -> BenchmarkState {
        let state = BenchmarkState::new(expected, false);
        state
            .prepared_event_count
            .store(expected, Ordering::Release);
        state.phase_start_ns.store(100, Ordering::Release);
        for correlation in 0..expected {
            let start_ns = 200 + correlation as u64 * 10;
            let end_ns = start_ns + 5;
            state.starts_ns[correlation].store(start_ns, Ordering::Release);
            state.sent_correlations[correlation].store(true, Ordering::Release);
            state.callback_correlations[correlation].store(true, Ordering::Release);
            state.sent_count.fetch_add(1, Ordering::Relaxed);
            state
                .strategy_callback_count
                .fetch_add(1, Ordering::Relaxed);
            state.strategy_records.lock().unwrap().push((
                correlation,
                sample_trade(state.correlations[correlation].trade_id),
            ));
            state.execution_observations[correlation]
                .set(ObservedExecution {
                    end_ns,
                    command: valid_command(&state, correlation),
                })
                .unwrap();
            state.raw_execution_count.fetch_add(1, Ordering::Relaxed);
        }
        state
    }

    #[test]
    fn producer_events_are_fully_built_before_phase_start() {
        let config = ScenarioConfig {
            producers: 2,
            messages_per_producer: 2,
            one_in_flight: false,
            timeout: Duration::from_secs(1),
        };
        let state = BenchmarkState::new(4, false);
        let producers = prebuild_producer_events(config, &state).unwrap();

        assert_eq!(state.phase_start_ns.load(Ordering::Acquire), 0);
        assert_eq!(state.prepared_event_count.load(Ordering::Acquire), 4);
        assert_eq!(producers.iter().map(Vec::len).sum::<usize>(), 4);
        for events in producers {
            for (correlation, event) in events {
                let DataEvent::Data(Data::Trade(tick)) = event else {
                    panic!("unexpected prepared event");
                };
                assert!(tick_matches_expectation(
                    &tick,
                    state.correlations[correlation]
                ));
            }
        }
    }

    #[test]
    fn offline_validator_rejects_duplicate_execution_correlation() {
        let mut state = seed_offline_state(2);
        let duplicate = valid_command(&state, 0);
        state.execution_observations[1].get_mut().unwrap().command = duplicate;

        let error = state.validate_offline().unwrap_err();
        assert!(
            error
                .to_string()
                .contains("duplicate execution correlation")
        );
    }

    #[test]
    fn offline_validator_rejects_wrong_order_route() {
        let mut state = seed_offline_state(1);
        state.execution_observations[0]
            .get_mut()
            .unwrap()
            .command
            .order_init
            .quantity = Quantity::from(2);

        let error = state.validate_offline().unwrap_err();
        assert!(
            error
                .to_string()
                .contains("execution route or order content mismatch")
        );
    }

    #[test]
    fn execution_observation_slots_are_fixed_and_overflow_is_fatal() {
        let state = BenchmarkState::new(1, false);
        assert_eq!(state.execution_observations.len(), 1);
        assert!(state.execution_observations[0].get().is_none());

        state.record_execution_entry(valid_command(&state, 0));
        assert!(state.execution_observations[0].get().is_some());
        state.record_execution_entry(valid_command(&state, 0));

        assert_eq!(state.execution_observations.len(), 1);
        assert_eq!(state.raw_execution_count.load(Ordering::Acquire), 2);
        assert!(
            state
                .check_fatal()
                .unwrap_err()
                .to_string()
                .contains("execution calls exceeded expected count")
        );
    }

    #[tokio::test]
    async fn fatal_state_wakes_ack_waiter() {
        let state = BenchmarkState::new(1, true);
        let result = tokio::time::timeout(Duration::from_secs(1), async {
            tokio::join!(state.wait_for_ack_or_fatal(0), async {
                tokio::task::yield_now().await;
                state.set_fatal("test fatal");
            })
            .0
        })
        .await
        .expect("fatal waiter timed out");

        assert!(result.unwrap_err().to_string().contains("test fatal"));
    }
}
