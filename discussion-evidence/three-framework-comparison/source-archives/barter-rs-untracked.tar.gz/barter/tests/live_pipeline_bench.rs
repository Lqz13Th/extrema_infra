#[allow(dead_code)]
#[path = "../benches/live_pipeline.rs"]
mod live_pipeline;

use std::time::Duration;

use live_pipeline::{
    FailureInjection, LiveMode, LiveScenario, LiveTopology, RunConfig, parse_mode,
    parse_non_negative_u64, parse_scenario, parse_topology, run_once, run_once_with_failure,
};

#[test]
fn configuration_parsers_are_strict() {
    assert_eq!(parse_mode("stress"), Ok(LiveMode::Stress));
    assert_eq!(parse_mode("mixed_live"), Ok(LiveMode::MixedLive));
    assert!(parse_mode("other").is_err());
    assert_eq!(parse_scenario("success"), Ok(LiveScenario::Success));
    assert_eq!(
        parse_scenario("business_error"),
        Ok(LiveScenario::BusinessError)
    );
    assert!(parse_scenario("other").is_err());
    assert_eq!(
        parse_topology("shared_handler"),
        Ok(LiveTopology::SharedHandler)
    );
    assert_eq!(
        parse_topology("batch_sharded"),
        Ok(LiveTopology::BatchSharded)
    );
    assert_eq!(
        parse_topology("ws5_strategy20"),
        Ok(LiveTopology::Ws5Strategy20)
    );
    assert!(parse_topology("other").is_err());
    assert_eq!(parse_non_negative_u64("LIVE_SIGNAL_COMPUTE_NS", "0"), Ok(0));
    assert_eq!(
        parse_non_negative_u64("LIVE_SIGNAL_COMPUTE_NS", &u64::MAX.to_string()),
        Ok(u64::MAX)
    );
    assert!(parse_non_negative_u64("LIVE_SIGNAL_COMPUTE_NS", "-1").is_err());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn two_tasks_three_instruments_conserve_and_route_full_pipeline() {
    let config = RunConfig {
        tasks: 2,
        instruments_per_task: 3,
        messages_per_instrument: 4,
        mode: LiveMode::Stress,
        order_every: 20,
        signal_compute_ns: 0,
        reject_every: 10,
        scenario: LiveScenario::Success,
        topology: LiveTopology::SharedHandler,
    };
    let result = run_once(config).await.expect("run 2x3 live pipeline");

    assert_eq!(result.total_ticks, 24);
    assert_eq!(result.expected_orders, 24);
    assert_eq!(result.public_parsed, 24);
    assert_eq!(result.public_cooperative_yields, 24);
    assert_eq!(result.trade_callbacks, 24);
    assert_eq!(result.order_endpoint_calls, 24);
    assert_eq!(result.orders_submitted, 24);
    assert_eq!(result.private_frames_parsed, 48);
    assert_eq!(result.acks, 24);
    assert_eq!(result.fills, 24);
    assert_eq!(result.ending_in_flight, 0);
    assert_eq!(result.drops, 0);
    assert_eq!(result.duplicates, 0);
    assert_eq!(result.route_errors, 0);
    assert_eq!(result.cross_batch_errors, 0);
    assert_eq!(result.missing, 0);
    assert_eq!(result.task_sent, vec![12, 12]);
    assert_eq!(result.task_completed, vec![12, 12]);
    assert_eq!(result.task_completed_no_order, vec![0, 0]);
    assert_eq!(result.task_completed_terminal, vec![12, 12]);
    assert_eq!(result.last_no_order_completion_from_phase_ns, 0);
    assert_eq!(result.wall_time_ns, result.last_terminal_from_phase_ns);
    assert!(result.last_terminal_from_phase_ns > result.last_fill_from_phase_ns);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn mixed_live_and_business_rejects_have_separate_conservation() {
    let config = RunConfig {
        tasks: 2,
        instruments_per_task: 3,
        messages_per_instrument: 10,
        mode: LiveMode::MixedLive,
        order_every: 3,
        signal_compute_ns: 0,
        reject_every: 10,
        scenario: LiveScenario::BusinessError,
        topology: LiveTopology::SharedHandler,
    };
    let result = run_once(config)
        .await
        .expect("run business-error live pipeline");

    assert_eq!(result.total_ticks, 60);
    assert_eq!(result.expected_orders, 18);
    assert_eq!(result.expected_rejects, 2);
    assert_eq!(result.order_endpoint_calls, 18);
    assert_eq!(result.acks, 16);
    assert_eq!(result.fills, 16);
    assert_eq!(result.business_errors, 2);
    assert_eq!(result.ending_in_flight, 0);
    assert_eq!(result.missing, 0);
    assert_eq!(result.public_cooperative_yields, 60);
    assert_eq!(result.cross_batch_errors, 0);
    assert_eq!(result.task_completed, vec![30, 30]);
    assert_eq!(result.task_completed_no_order, vec![21, 21]);
    assert_eq!(result.task_completed_terminal, vec![9, 9]);
    assert_eq!(
        result.wall_time_ns,
        result
            .last_trade_strategy_from_phase_ns
            .max(result.last_terminal_from_phase_ns)
            .max(result.last_private_fanout_from_phase_ns)
    );
}

fn failure_config() -> RunConfig {
    RunConfig {
        tasks: 1,
        instruments_per_task: 1,
        messages_per_instrument: 2,
        mode: LiveMode::Stress,
        order_every: 1,
        signal_compute_ns: 0,
        reject_every: 10,
        scenario: LiveScenario::Success,
        topology: LiveTopology::SharedHandler,
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 8)]
async fn batch_sharded_two_batches_use_twenty_lanes_and_five_logical_handlers_each() {
    let config = RunConfig {
        tasks: 2,
        instruments_per_task: 20,
        messages_per_instrument: 3,
        mode: LiveMode::Stress,
        order_every: 20,
        signal_compute_ns: 0,
        reject_every: 10,
        scenario: LiveScenario::Success,
        topology: LiveTopology::BatchSharded,
    };
    let result = run_once(config)
        .await
        .expect("run 2x20 batch-sharded pipeline");

    assert_eq!(result.trade_producers, 40);
    assert_eq!(result.engine_count, 2);
    assert_eq!(result.signal_handlers, 10);
    assert_eq!(result.trade_lanes_per_signal_handler, 4);
    assert_eq!(result.account_broadcast_rings, 0);
    assert_eq!(result.account_fanout_domains, 2);
    assert_eq!(result.account_receivers_per_ring, 0);
    assert_eq!(result.account_handlers_per_fanout_domain, 5);
    assert_eq!(result.account_ingress_tasks, 2);
    assert_eq!(result.account_owner_handlers, 2);
    assert_eq!(result.venue_handlers, 2);
    assert_eq!(result.runtime_tasks, 46);
    assert_eq!(result.total_ticks, 120);
    assert_eq!(result.expected_orders, 120);
    assert_eq!(result.public_parsed, 120);
    assert_eq!(result.public_cooperative_yields, 120);
    assert_eq!(result.trade_callbacks, 120);
    assert_eq!(result.private_frames_parsed, 240);
    assert_eq!(result.private_fanout_callbacks, 1_200);
    assert_eq!(result.expected_private_fanout_callbacks, 1_200);
    assert_eq!(result.account_callbacks, 360);
    assert_eq!(result.acks, 120);
    assert_eq!(result.fills, 120);
    assert_eq!(result.trade_lane_sent, vec![3; 40]);
    assert_eq!(result.task_sent, vec![60, 60]);
    assert_eq!(result.signal_trade_by_handler, vec![12; 10]);
    assert_eq!(result.signal_private_by_handler, vec![120; 10]);
    assert_eq!(result.audited_events, 482);
    assert_eq!(result.ending_in_flight, 0);
    assert_eq!(result.account_delivery_lost, 0);
    assert_eq!(result.broadcast_lagged, 0);
    assert_eq!(result.drops, 0);
    assert_eq!(result.duplicates, 0);
    assert_eq!(result.route_errors, 0);
    assert_eq!(result.cross_batch_errors, 0);
    assert_eq!(result.missing, 0);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 8)]
async fn batch_sharded_mixed_business_errors_conserve_raw_and_native_account_paths() {
    let config = RunConfig {
        tasks: 2,
        instruments_per_task: 20,
        messages_per_instrument: 6,
        mode: LiveMode::MixedLive,
        order_every: 3,
        signal_compute_ns: 0,
        reject_every: 1,
        scenario: LiveScenario::BusinessError,
        topology: LiveTopology::BatchSharded,
    };
    let result = run_once(config)
        .await
        .expect("run batch-sharded mixed business-error pipeline");

    assert_eq!(result.total_ticks, 240);
    assert_eq!(result.expected_orders, 80);
    assert_eq!(result.expected_rejects, 80);
    assert_eq!(result.private_frames_parsed, 80);
    assert_eq!(result.private_fanout_callbacks, 400);
    assert_eq!(result.account_callbacks, 80);
    assert_eq!(result.acks, 0);
    assert_eq!(result.fills, 0);
    assert_eq!(result.business_errors, 80);
    assert_eq!(result.task_completed_no_order, vec![80, 80]);
    assert_eq!(result.task_completed_terminal, vec![40, 40]);
    assert_eq!(result.signal_trade_by_handler, vec![24; 10]);
    assert_eq!(result.signal_private_by_handler, vec![40; 10]);
    assert_eq!(result.account_delivery_lost, 0);
    assert_eq!(result.drops, 0);
    assert_eq!(result.duplicates, 0);
    assert_eq!(result.route_errors, 0);
    assert_eq!(result.cross_batch_errors, 0);
    assert_eq!(result.missing, 0);
    assert_eq!(result.public_cooperative_yields, 240);
    assert_eq!(
        result.wall_time_ns,
        result
            .last_trade_strategy_from_phase_ns
            .max(result.last_terminal_from_phase_ns)
            .max(result.last_private_fanout_from_phase_ns)
    );
    assert!(
        result.last_private_fanout_from_phase_ns > result.last_terminal_from_phase_ns,
        "the final reject observation must complete after the native terminal callback"
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 8)]
async fn ws5_strategy20_uses_twenty_five_symbol_ws_groups_and_one_engine() {
    let config = RunConfig {
        tasks: 20,
        instruments_per_task: 5,
        messages_per_instrument: 1,
        mode: LiveMode::Stress,
        order_every: 1,
        signal_compute_ns: 0,
        reject_every: 10,
        scenario: LiveScenario::Success,
        topology: LiveTopology::Ws5Strategy20,
    };
    let result = run_once(config)
        .await
        .expect("run ws5_strategy20 full-chain pipeline");

    assert_eq!(result.trade_producers, 20);
    assert_eq!(result.engine_count, 1);
    assert_eq!(result.signal_handlers, 20);
    assert_eq!(result.trade_lanes_per_signal_handler, 1);
    assert_eq!(result.account_ingress_tasks, 1);
    assert_eq!(result.account_fanout_domains, 1);
    assert_eq!(result.account_handlers_per_fanout_domain, 20);
    assert_eq!(result.account_owner_handlers, 1);
    assert_eq!(result.venue_handlers, 1);
    assert_eq!(result.runtime_tasks, 23);
    assert_eq!(result.total_ticks, 100);
    assert_eq!(result.expected_orders, 100);
    assert_eq!(result.public_parsed, 100);
    assert_eq!(result.public_cooperative_yields, 100);
    assert_eq!(result.trade_callbacks, 100);
    assert_eq!(result.signal_compute_calls, 100);
    assert_eq!(result.private_frames_parsed, 200);
    assert_eq!(result.private_fanout_callbacks, 4_000);
    assert_eq!(result.expected_private_fanout_callbacks, 4_000);
    assert_eq!(result.account_callbacks, 300);
    assert_eq!(result.acks, 100);
    assert_eq!(result.fills, 100);
    assert_eq!(result.trade_lane_sent, vec![5; 20]);
    assert_eq!(result.task_sent, vec![5; 20]);
    assert_eq!(result.signal_trade_by_handler, vec![5; 20]);
    assert_eq!(result.signal_private_by_handler, vec![200; 20]);
    assert_eq!(result.audited_events, 401);
    assert_eq!(result.ending_in_flight, 0);
    assert_eq!(result.account_delivery_lost, 0);
    assert_eq!(result.broadcast_lagged, 0);
    assert_eq!(result.drops, 0);
    assert_eq!(result.duplicates, 0);
    assert_eq!(result.route_errors, 0);
    assert_eq!(result.cross_batch_errors, 0);
    assert_eq!(result.missing, 0);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 8)]
async fn ws5_strategy20_signal_compute_runs_for_order_and_no_order_ticks() {
    let signal_compute_ns = 50_000;
    let result = run_once(RunConfig {
        tasks: 20,
        instruments_per_task: 5,
        messages_per_instrument: 2,
        mode: LiveMode::MixedLive,
        order_every: 2,
        signal_compute_ns,
        reject_every: 10,
        scenario: LiveScenario::Success,
        topology: LiveTopology::Ws5Strategy20,
    })
    .await
    .expect("run ws5_strategy20 with configured signal compute");

    assert_eq!(result.total_ticks, 200);
    assert_eq!(result.expected_orders, 100);
    assert_eq!(result.signal_compute_calls, result.total_ticks);
    assert!(result.signal_compute_calls > result.expected_orders);
    assert_eq!(result.signal_trade_by_handler, vec![10; 20]);
    assert_eq!(result.task_completed_no_order, vec![5; 20]);
    assert_eq!(result.tick_to_order_ns.len(), result.expected_orders);
    assert!(
        result
            .tick_to_order_ns
            .iter()
            .all(|latency| *latency >= signal_compute_ns)
    );
}

#[tokio::test]
async fn ws5_strategy20_requires_exactly_twenty_ws_groups_of_five_symbols() {
    for (tasks, instruments_per_task) in [(19, 5), (20, 4)] {
        let error = run_once(RunConfig {
            tasks,
            instruments_per_task,
            messages_per_instrument: 1,
            mode: LiveMode::Stress,
            order_every: 1,
            signal_compute_ns: 0,
            reject_every: 10,
            scenario: LiveScenario::Success,
            topology: LiveTopology::Ws5Strategy20,
        })
        .await
        .expect_err("invalid ws5_strategy20 shape must fail");
        assert!(
            error.contains("requires LIVE_TASKS=20 and LIVE_INSTRUMENTS_PER_TASK=5"),
            "{error}"
        );
    }
}

#[tokio::test]
async fn batch_sharded_requires_exactly_twenty_trade_lanes() {
    let config = RunConfig {
        tasks: 1,
        instruments_per_task: 19,
        messages_per_instrument: 1,
        mode: LiveMode::Stress,
        order_every: 1,
        signal_compute_ns: 0,
        reject_every: 10,
        scenario: LiveScenario::Success,
        topology: LiveTopology::BatchSharded,
    };
    let error = run_once(config)
        .await
        .expect_err("invalid batch-sharded lane count must fail");
    assert!(
        error.contains("requires LIVE_INSTRUMENTS_PER_TASK=20"),
        "{error}"
    );
}

async fn expect_injected_failure(
    injection: FailureInjection,
    internal_timeout: Duration,
) -> String {
    tokio::time::timeout(
        Duration::from_secs(5),
        run_once_with_failure(failure_config(), injection, internal_timeout),
    )
    .await
    .expect("injected failure cleanup must not hang")
    .expect_err("failure injection must fail the run")
}

fn batch_failure_config() -> RunConfig {
    RunConfig {
        tasks: 1,
        instruments_per_task: 20,
        messages_per_instrument: 2,
        mode: LiveMode::Stress,
        order_every: 1,
        signal_compute_ns: 0,
        reject_every: 10,
        scenario: LiveScenario::Success,
        topology: LiveTopology::BatchSharded,
    }
}

async fn expect_batch_injected_failure(injection: FailureInjection) -> String {
    tokio::time::timeout(
        Duration::from_secs(5),
        run_once_with_failure(
            batch_failure_config(),
            injection,
            Duration::from_millis(100),
        ),
    )
    .await
    .expect("batch injected failure cleanup must not hang")
    .expect_err("batch failure injection must fail the run")
}

#[tokio::test(flavor = "multi_thread", worker_threads = 8)]
async fn batch_sharded_decode_failures_and_timeout_cleanup_all_runtime_tasks() {
    let public = expect_batch_injected_failure(FailureInjection::PublicDecode).await;
    assert!(
        public.contains("public Binance trade decode failed"),
        "{public}"
    );

    let private = expect_batch_injected_failure(FailureInjection::PrivateDecode).await;
    assert!(
        private.contains("private executionReport decode failed"),
        "{private}"
    );

    let timeout = expect_batch_injected_failure(FailureInjection::VenueCompletionTimeout).await;
    assert!(timeout.contains("batch processing timed out"), "{timeout}");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn malformed_public_frame_cleans_up_all_tasks() {
    let error =
        expect_injected_failure(FailureInjection::PublicDecode, Duration::from_secs(1)).await;
    assert!(
        error.contains("public Binance trade decode failed"),
        "{error}"
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn malformed_private_frame_cleans_up_all_tasks() {
    let error =
        expect_injected_failure(FailureInjection::PrivateDecode, Duration::from_secs(1)).await;
    assert!(
        error.contains("private executionReport decode failed"),
        "{error}"
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn venue_completion_timeout_cleans_up_all_tasks() {
    let error = expect_injected_failure(
        FailureInjection::VenueCompletionTimeout,
        Duration::from_millis(50),
    )
    .await;
    assert!(error.contains("venue processing timed out"), "{error}");
}
