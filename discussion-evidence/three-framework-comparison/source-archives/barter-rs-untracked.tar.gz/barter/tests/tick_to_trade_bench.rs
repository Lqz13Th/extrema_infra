#[allow(dead_code)]
#[path = "../benches/tick_to_trade.rs"]
mod tick_to_trade;

use tick_to_trade::{
    Scenario, abort_and_drain_with_timeout, load_real_ticks, nearest_rank_percentile,
    parse_positive_usize, parse_scenarios, run_once, run_once_with_producers,
    validate_producer_count,
};
use tokio::task::JoinSet;

use std::{sync::mpsc, time::Duration};

#[test]
fn queue_inclusive_matches_scenario_topology() {
    assert!(!Scenario::Unloaded.queue_inclusive());
    assert!(Scenario::Saturated.queue_inclusive());
}

#[test]
fn runner_count_overrides_must_be_positive() {
    assert_eq!(parse_positive_usize("T2T_WARMUP_RUNS", "1"), Ok(1));
    assert!(parse_positive_usize("T2T_WARMUP_RUNS", "0").is_err());
    assert!(parse_positive_usize("T2T_MEASURED_RUNS", "0").is_err());
    assert!(parse_positive_usize("T2T_MESSAGES_PER_TASK", "0").is_err());
}

#[test]
fn runner_accepts_any_positive_producer_count() {
    for producers in [1, 2, 3, 5, 10, 16, 32, 64, 65] {
        assert_eq!(validate_producer_count(producers), Ok(producers));
    }
    assert!(validate_producer_count(0).is_err());
}

#[test]
fn runner_scenario_override_accepts_unloaded_saturated_or_all() {
    assert_eq!(parse_scenarios("unloaded"), Ok(vec![Scenario::Unloaded]));
    assert_eq!(parse_scenarios("saturated"), Ok(vec![Scenario::Saturated]));
    assert_eq!(
        parse_scenarios("all"),
        Ok(vec![Scenario::Unloaded, Scenario::Saturated])
    );
    assert!(parse_scenarios("other").is_err());
}

#[test]
fn nearest_rank_percentile_selects_expected_observation() {
    let sorted = [10, 20, 30, 40, 50];

    assert_eq!(nearest_rank_percentile(&sorted, 50), 30);
    assert_eq!(nearest_rank_percentile(&sorted, 95), 50);
    assert_eq!(nearest_rank_percentile(&sorted, 99), 50);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn blocking_task_cleanup_is_bounded_and_remains_drainable() {
    let (started_tx, started_rx) = tokio::sync::oneshot::channel();
    let (release_tx, release_rx) = mpsc::channel();
    let mut tasks = JoinSet::new();
    tasks.spawn_blocking(move || {
        let _ = started_tx.send(());
        release_rx.recv().expect("receive blocking task release");
    });
    started_rx.await.expect("blocking task started");

    let error = abort_and_drain_with_timeout(&mut tasks, Duration::from_millis(25))
        .await
        .expect_err("running spawn_blocking task must hit cleanup timeout");
    assert!(error.contains("cleanup timed out"));

    release_tx.send(()).expect("release blocking task");
    abort_and_drain_with_timeout(&mut tasks, Duration::from_secs(1))
        .await
        .expect("released blocking task drains successfully");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn unloaded_run_is_one_in_flight_and_conserves_orders() {
    let ticks = load_real_ticks().expect("load real normalised ticks");
    let result = run_once(Scenario::Unloaded, &ticks, 8)
        .await
        .expect("run unloaded tick-to-trade simulation");

    assert_eq!(result.producers, 1);
    assert_eq!(result.messages_per_task, 8);
    assert_eq!(result.sent, 8);
    assert_eq!(result.engine_callbacks, 8);
    assert_eq!(result.orders, 8);
    assert_eq!(result.in_flight_orders, 8);
    assert_eq!(result.shutdowns, 1);
    assert!(result.strict_one_in_flight);
    assert!(result.earliest_send_ns >= result.phase_start_ns);
    assert!(result.wall_time_ns > 0);
    assert_eq!(result.sequences_sorted(), (0..8).collect::<Vec<_>>());
    assert_eq!(result.latencies_ns.len(), 8);
    assert!(result.latencies_ns.iter().all(|latency| *latency > 0));
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn saturated_run_merges_sixteen_producers_without_loss_or_duplicates() {
    let ticks = load_real_ticks().expect("load real normalised ticks");
    let result = run_once(Scenario::Saturated, &ticks, 4)
        .await
        .expect("run saturated tick-to-trade simulation");

    assert_eq!(result.producers, 16);
    assert_eq!(result.messages_per_task, 4);
    assert_eq!(result.sent, 64);
    assert_eq!(result.engine_callbacks, 64);
    assert_eq!(result.orders, 64);
    assert_eq!(result.in_flight_orders, 64);
    assert_eq!(result.shutdowns, 1);
    assert!(result.earliest_send_ns >= result.phase_start_ns);
    assert!(result.wall_time_ns > 0);
    assert_eq!(result.sequences_sorted(), (0..64).collect::<Vec<_>>());
    assert_eq!(result.latencies_ns.len(), 64);
    assert!(result.latencies_ns.iter().all(|latency| *latency > 0));
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn configured_saturated_run_conserves_varied_producer_counts() {
    let ticks = load_real_ticks().expect("load real normalised ticks");
    for producers in [1, 3, 5, 10, 16, 32, 64] {
        let result = run_once_with_producers(Scenario::Saturated, &ticks, 1, producers)
            .await
            .expect("run configured saturated tick-to-trade simulation");

        assert_eq!(result.producers, producers);
        assert_eq!(result.sent, producers);
        assert_eq!(result.engine_callbacks, producers);
        assert_eq!(result.orders, producers);
        assert_eq!(result.in_flight_orders, producers);
        assert_eq!(
            result.sequences_sorted(),
            (0..producers).collect::<Vec<_>>()
        );
        assert_eq!(result.latencies_ns.len(), producers);
    }
}
