//! Live-shaped, zero-network CPU benchmark for Barter.
//!
//! Public market data uses Barter's production Binance `@trade` decoder and stateless
//! transformer. Barter does not currently ship a Binance private WebSocket decoder, so the
//! private `executionReport` DTO below is an explicitly labelled benchmark bridge: raw frames
//! still use the production generic WebSocket serde parser before being translated into native
//! `AccountEvent`s.

use barter::{
    EngineEvent,
    engine::{
        Engine, Processor,
        clock::LiveClock,
        execution_tx::MultiExchangeTxMap,
        run::sync_run,
        state::{
            EngineState,
            instrument::{data::InstrumentDataState, filter::InstrumentFilter},
            order::in_flight_recorder::InFlightRequestRecorder,
            trading::TradingState,
        },
    },
    execution::request::ExecutionRequest,
    risk::DefaultRiskManager,
    strategy::{
        algo::AlgoStrategy, close_positions::ClosePositionsStrategy,
        on_disconnect::OnDisconnectStrategy, on_trading_disabled::OnTradingDisabled,
    },
};
use barter_data::{
    event::{DataKind, MarketEvent},
    exchange::binance::{spot::BinanceSpot, trade::BinanceTrade},
    streams::consumer::MarketStreamEvent,
    subscription::{
        Map,
        trade::{PublicTrade, PublicTrades},
    },
    transformer::{ExchangeTransformer, stateless::StatelessTransformer},
};
use barter_execution::{
    AccountEvent, AccountEventKind,
    error::{ApiError, OrderError},
    order::{
        Order, OrderKey, OrderKind, TimeInForce,
        id::{ClientOrderId, OrderId, StrategyId},
        request::{OrderRequestCancel, OrderRequestOpen, RequestOpen},
        state::{ActiveOrderState, InactiveOrderState, Open, OrderState},
    },
    trade::{AssetFees, Trade, TradeId},
};
use barter_instrument::{
    Side, Underlying,
    asset::{AssetIndex, QuoteAsset},
    exchange::{ExchangeId, ExchangeIndex},
    index::IndexedInstruments,
    instrument::{Instrument, InstrumentIndex},
};
use barter_integration::{
    Transformer,
    channel::{Tx, UnboundedRx, UnboundedTx, mpsc_unbounded},
    collection::snapshot::Snapshot,
    protocol::{
        StreamParser,
        websocket::{WebSocketSerdeParser, WsMessage},
    },
    subscription::SubscriptionId,
};
use chrono::{TimeZone, Utc};
use futures::StreamExt;
use rust_decimal::{Decimal, prelude::FromPrimitive};
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::{
    collections::HashMap,
    env,
    hint::spin_loop,
    sync::{
        Arc,
        atomic::{AtomicBool, AtomicU8, AtomicU32, AtomicU64, AtomicUsize, Ordering},
    },
    time::{Duration, Instant},
};
use tokio::{
    sync::{Barrier, mpsc, oneshot},
    time::timeout,
};

const DEFAULT_TASKS: usize = 5;
const DEFAULT_INSTRUMENTS_PER_TASK: usize = 20;
const DEFAULT_MESSAGES_PER_INSTRUMENT: usize = 256;
const DEFAULT_ORDER_EVERY: usize = 20;
const DEFAULT_REJECT_EVERY: usize = 10;
const DEFAULT_SIGNAL_COMPUTE_NS: u64 = 0;
const DEFAULT_WARMUP_RUNS: usize = 1;
const DEFAULT_MEASURED_RUNS: usize = 5;
const RUNTIME_WORKER_THREADS: usize = 16;
const RUN_TIMEOUT: Duration = Duration::from_secs(60);
const STRATEGY_ID: &str = "live-pipeline";
const BATCH_TRADE_LANES: usize = 20;
const SIGNAL_HANDLERS_PER_BATCH: usize = 5;
const TRADE_LANES_PER_SIGNAL_HANDLER: usize = BATCH_TRADE_LANES / SIGNAL_HANDLERS_PER_BATCH;
const WS5_PUBLIC_WS_TASKS: usize = 20;
const WS5_SYMBOLS_PER_PUBLIC_WS: usize = 5;
const WS5_SIGNAL_HANDLERS: usize = 20;
const PRIVATE_INGRESS_CAPACITY: usize = 8_192;
const CID_PREFIX: &str = "lp-";
const FILL_PREFIX: &str = "lp-fill-";
const BASE_EPOCH_MS: i64 = 1_750_000_000_000;

type PipelineState = EngineState<PipelineGlobalData, PipelineInstrumentData>;
type PipelineRisk = DefaultRiskManager<PipelineState>;
type PipelineExecutionTxs = MultiExchangeTxMap<UnboundedTx<ExecutionRequest>>;
type PipelineEngine =
    Engine<LiveClock, PipelineState, PipelineExecutionTxs, PipelineStrategy, PipelineRisk>;
type PublicTransformer =
    StatelessTransformer<BinanceSpot, InstrumentIndex, PublicTrades, BinanceTrade>;

#[derive(Debug, Copy, Clone)]
struct RunHooks {
    corrupt_public_frame: bool,
    corrupt_private_frame: bool,
    hold_venue_completion: bool,
    timeout: Duration,
}

impl Default for RunHooks {
    fn default() -> Self {
        Self {
            corrupt_public_frame: false,
            corrupt_private_frame: false,
            hold_venue_completion: false,
            timeout: RUN_TIMEOUT,
        }
    }
}

#[derive(Debug, Copy, Clone, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum LiveMode {
    Stress,
    MixedLive,
}

#[derive(Debug, Copy, Clone, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum LiveScenario {
    Success,
    BusinessError,
}

#[derive(Debug, Copy, Clone, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum LiveTopology {
    SharedHandler,
    BatchSharded,
    Ws5Strategy20,
}

impl LiveTopology {
    fn name(self) -> &'static str {
        match self {
            Self::SharedHandler => "shared_handler",
            Self::BatchSharded => "batch_sharded",
            Self::Ws5Strategy20 => "ws5_strategy20",
        }
    }

    fn signal_handlers(self, batches: usize) -> Result<usize, String> {
        match self {
            Self::SharedHandler => Ok(1),
            Self::BatchSharded => batches
                .checked_mul(SIGNAL_HANDLERS_PER_BATCH)
                .ok_or_else(|| "signal handler count overflow".to_owned()),
            Self::Ws5Strategy20 => Ok(WS5_SIGNAL_HANDLERS),
        }
    }

    fn account_receivers_per_batch(self) -> usize {
        match self {
            Self::SharedHandler => 1,
            Self::BatchSharded => SIGNAL_HANDLERS_PER_BATCH,
            Self::Ws5Strategy20 => WS5_SIGNAL_HANDLERS,
        }
    }
}

#[derive(Debug, Copy, Clone)]
pub struct RunConfig {
    pub tasks: usize,
    pub instruments_per_task: usize,
    pub messages_per_instrument: usize,
    pub mode: LiveMode,
    pub order_every: usize,
    pub signal_compute_ns: u64,
    pub reject_every: usize,
    pub scenario: LiveScenario,
    pub topology: LiveTopology,
}

impl RunConfig {
    fn total_instruments(self) -> Result<usize, String> {
        self.tasks
            .checked_mul(self.instruments_per_task)
            .ok_or_else(|| "instrument count overflow".to_owned())
    }

    fn ticks_per_task(self) -> Result<usize, String> {
        self.instruments_per_task
            .checked_mul(self.messages_per_instrument)
            .ok_or_else(|| "per-task tick count overflow".to_owned())
    }

    fn total_ticks(self) -> Result<usize, String> {
        self.tasks
            .checked_mul(self.ticks_per_task()?)
            .ok_or_else(|| "total tick count overflow".to_owned())
    }

    fn validate(self) -> Result<Self, String> {
        if self.tasks == 0
            || self.instruments_per_task == 0
            || self.messages_per_instrument == 0
            || self.order_every == 0
            || self.reject_every == 0
        {
            return Err("LIVE_* counts must all be greater than zero".to_owned());
        }
        self.total_ticks()?;
        if self.topology == LiveTopology::BatchSharded
            && self.instruments_per_task != BATCH_TRADE_LANES
        {
            return Err(format!(
                "batch_sharded topology requires LIVE_INSTRUMENTS_PER_TASK={BATCH_TRADE_LANES}"
            ));
        }
        if self.topology == LiveTopology::Ws5Strategy20
            && (self.tasks != WS5_PUBLIC_WS_TASKS
                || self.instruments_per_task != WS5_SYMBOLS_PER_PUBLIC_WS)
        {
            return Err(format!(
                "ws5_strategy20 topology requires LIVE_TASKS={WS5_PUBLIC_WS_TASKS} and LIVE_INSTRUMENTS_PER_TASK={WS5_SYMBOLS_PER_PUBLIC_WS}"
            ));
        }
        self.topology.signal_handlers(self.tasks)?;
        if !(0..self.messages_per_instrument)
            .any(|message_index| should_order(self.mode, self.order_every, message_index))
        {
            return Err("configuration produces no orders".to_owned());
        }
        Ok(self)
    }
}

fn should_order(mode: LiveMode, order_every: usize, message_index: usize) -> bool {
    mode == LiveMode::Stress || (message_index + 1).is_multiple_of(order_every)
}

fn run_signal_compute(duration_ns: u64) {
    if duration_ns == 0 {
        return;
    }
    let started = Instant::now();
    let duration = Duration::from_nanos(duration_ns);
    while started.elapsed() < duration {
        spin_loop();
    }
}

#[derive(Debug)]
struct PipelineMetrics {
    origin: Instant,
    expected_instrument: Vec<usize>,
    task_by_sequence: Vec<usize>,
    handler_by_sequence: Vec<usize>,
    expects_order: Vec<bool>,
    expects_reject: Vec<bool>,
    t0: Vec<AtomicU64>,
    t_public: Vec<AtomicU64>,
    t_order: Vec<AtomicU64>,
    t_ack: Vec<AtomicU64>,
    t_fill: Vec<AtomicU64>,
    public_seen: Vec<AtomicU8>,
    trade_seen: Vec<AtomicU8>,
    signal_trade_seen: Vec<AtomicU8>,
    order_seen: Vec<AtomicU8>,
    ack_seen: Vec<AtomicU8>,
    fill_seen: Vec<AtomicU8>,
    terminal_seen: Vec<AtomicU8>,
    completion_seen: Vec<AtomicU8>,
    private_primary_seen: Vec<AtomicU32>,
    private_secondary_seen: Vec<AtomicU32>,
    public_parsed: AtomicUsize,
    public_cooperative_yields: AtomicUsize,
    trade_callbacks: AtomicUsize,
    signal_trade_callbacks: AtomicUsize,
    signal_compute_calls: AtomicUsize,
    order_endpoint_calls: AtomicUsize,
    private_frames_parsed: AtomicUsize,
    acks: AtomicUsize,
    fills: AtomicUsize,
    business_errors: AtomicUsize,
    account_callbacks: AtomicUsize,
    private_fanout_callbacks: AtomicUsize,
    drops: AtomicUsize,
    duplicates: AtomicUsize,
    route_errors: AtomicUsize,
    cross_batch_errors: AtomicUsize,
    current_in_flight: AtomicUsize,
    max_in_flight: AtomicUsize,
    last_fill_ns: AtomicU64,
    last_terminal_ns: AtomicU64,
    last_trade_strategy_ns: AtomicU64,
    last_no_order_completion_ns: AtomicU64,
    last_private_fanout_ns: AtomicU64,
    last_completion_ns: AtomicU64,
    task_completed: Vec<AtomicUsize>,
    task_completed_no_order: Vec<AtomicUsize>,
    task_completed_terminal: Vec<AtomicUsize>,
    signal_trade_by_handler: Vec<AtomicUsize>,
    signal_private_by_handler: Vec<AtomicUsize>,
}

impl PipelineMetrics {
    fn new(
        expected_instrument: Vec<usize>,
        task_by_sequence: Vec<usize>,
        handler_by_sequence: Vec<usize>,
        expects_order: Vec<bool>,
        expects_reject: Vec<bool>,
        tasks: usize,
        signal_handlers: usize,
    ) -> Self {
        let total = expected_instrument.len();
        let times = || (0..total).map(|_| AtomicU64::new(0)).collect();
        let seen = || (0..total).map(|_| AtomicU8::new(0)).collect();
        let private_seen = || (0..total).map(|_| AtomicU32::new(0)).collect();
        Self {
            origin: Instant::now(),
            expected_instrument,
            task_by_sequence,
            handler_by_sequence,
            expects_order,
            expects_reject,
            t0: times(),
            t_public: times(),
            t_order: times(),
            t_ack: times(),
            t_fill: times(),
            public_seen: seen(),
            trade_seen: seen(),
            signal_trade_seen: seen(),
            order_seen: seen(),
            ack_seen: seen(),
            fill_seen: seen(),
            terminal_seen: seen(),
            completion_seen: seen(),
            private_primary_seen: private_seen(),
            private_secondary_seen: private_seen(),
            public_parsed: AtomicUsize::new(0),
            public_cooperative_yields: AtomicUsize::new(0),
            trade_callbacks: AtomicUsize::new(0),
            signal_trade_callbacks: AtomicUsize::new(0),
            signal_compute_calls: AtomicUsize::new(0),
            order_endpoint_calls: AtomicUsize::new(0),
            private_frames_parsed: AtomicUsize::new(0),
            acks: AtomicUsize::new(0),
            fills: AtomicUsize::new(0),
            business_errors: AtomicUsize::new(0),
            account_callbacks: AtomicUsize::new(0),
            private_fanout_callbacks: AtomicUsize::new(0),
            drops: AtomicUsize::new(0),
            duplicates: AtomicUsize::new(0),
            route_errors: AtomicUsize::new(0),
            cross_batch_errors: AtomicUsize::new(0),
            current_in_flight: AtomicUsize::new(0),
            max_in_flight: AtomicUsize::new(0),
            last_fill_ns: AtomicU64::new(0),
            last_terminal_ns: AtomicU64::new(0),
            last_trade_strategy_ns: AtomicU64::new(0),
            last_no_order_completion_ns: AtomicU64::new(0),
            last_private_fanout_ns: AtomicU64::new(0),
            last_completion_ns: AtomicU64::new(0),
            task_completed: (0..tasks).map(|_| AtomicUsize::new(0)).collect(),
            task_completed_no_order: (0..tasks).map(|_| AtomicUsize::new(0)).collect(),
            task_completed_terminal: (0..tasks).map(|_| AtomicUsize::new(0)).collect(),
            signal_trade_by_handler: (0..signal_handlers).map(|_| AtomicUsize::new(0)).collect(),
            signal_private_by_handler: (0..signal_handlers).map(|_| AtomicUsize::new(0)).collect(),
        }
    }

    fn now_ns(&self) -> u64 {
        u64::try_from(self.origin.elapsed().as_nanos())
            .unwrap_or(u64::MAX - 1)
            .saturating_add(1)
    }

    fn mark_once(&self, seen: &[AtomicU8], sequence: usize) -> bool {
        let Some(seen) = seen.get(sequence) else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            return false;
        };
        if seen.swap(1, Ordering::AcqRel) != 0 {
            self.duplicates.fetch_add(1, Ordering::Relaxed);
            return false;
        }
        true
    }

    fn mark_public(&self, sequence: usize, timestamp: u64) {
        if self.mark_once(&self.public_seen, sequence) {
            self.t_public[sequence].store(timestamp, Ordering::Release);
            self.public_parsed.fetch_add(1, Ordering::Relaxed);
        }
    }

    fn mark_cross_batch_error(&self) {
        self.cross_batch_errors.fetch_add(1, Ordering::Relaxed);
        self.route_errors.fetch_add(1, Ordering::Relaxed);
    }

    fn mark_trade_callback(
        &self,
        sequence: usize,
        instrument: InstrumentIndex,
        batch: usize,
        handler: usize,
    ) {
        if self.expected_instrument.get(sequence).copied() != Some(instrument.0) {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
        }
        if self.task_by_sequence.get(sequence).copied() != Some(batch) {
            self.mark_cross_batch_error();
        }
        if self.handler_by_sequence.get(sequence).copied() != Some(handler) {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
        }
        if self.mark_once(&self.trade_seen, sequence) {
            self.trade_callbacks.fetch_add(1, Ordering::Relaxed);
        }
    }

    fn mark_signal_trade(
        &self,
        sequence: usize,
        instrument: InstrumentIndex,
        batch: usize,
        handler: usize,
        handler_slot: usize,
    ) -> bool {
        let mut route_valid = true;
        if self.expected_instrument.get(sequence).copied() != Some(instrument.0) {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            route_valid = false;
        }
        if self.task_by_sequence.get(sequence).copied() != Some(batch) {
            self.mark_cross_batch_error();
            route_valid = false;
        }
        if self.handler_by_sequence.get(sequence).copied() != Some(handler) {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            route_valid = false;
        }
        if self.mark_once(&self.signal_trade_seen, sequence) {
            self.signal_trade_callbacks.fetch_add(1, Ordering::Relaxed);
            if let Some(count) = self.signal_trade_by_handler.get(handler_slot) {
                count.fetch_add(1, Ordering::Relaxed);
            } else {
                self.route_errors.fetch_add(1, Ordering::Relaxed);
                route_valid = false;
            }
        } else {
            route_valid = false;
        }
        route_valid
    }

    fn mark_strategy_trade_complete(&self, sequence: usize) {
        let completed_ns = self.now_ns();
        self.last_trade_strategy_ns
            .fetch_max(completed_ns, Ordering::Relaxed);
        self.last_completion_ns
            .fetch_max(completed_ns, Ordering::Relaxed);
        match self.expects_order.get(sequence).copied() {
            Some(false) => {
                self.mark_task_completed(sequence, false);
                self.last_no_order_completion_ns
                    .fetch_max(completed_ns, Ordering::Relaxed);
                self.last_completion_ns
                    .fetch_max(completed_ns, Ordering::Relaxed);
            }
            Some(true) => {}
            None => {
                self.route_errors.fetch_add(1, Ordering::Relaxed);
            }
        }
    }

    fn mark_private_handler(
        &self,
        sequence: usize,
        batch: usize,
        instrument: InstrumentIndex,
        handler: usize,
        handler_slot: usize,
        secondary: bool,
    ) {
        if self.task_by_sequence.get(sequence).copied() != Some(batch) {
            self.mark_cross_batch_error();
        }
        if self.expected_instrument.get(sequence).copied() != Some(instrument.0) {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
        }
        let Some(mask) = 1_u32.checked_shl(u32::try_from(handler).unwrap_or(u32::MAX)) else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            return;
        };
        let seen = if secondary {
            &self.private_secondary_seen
        } else {
            &self.private_primary_seen
        };
        let Some(seen) = seen.get(sequence) else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            return;
        };
        if seen.fetch_or(mask, Ordering::AcqRel) & mask != 0 {
            self.duplicates.fetch_add(1, Ordering::Relaxed);
            return;
        }
        self.private_fanout_callbacks
            .fetch_add(1, Ordering::Relaxed);
        if let Some(count) = self.signal_private_by_handler.get(handler_slot) {
            count.fetch_add(1, Ordering::Relaxed);
        } else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
        }
        let completed_ns = self.now_ns();
        self.last_private_fanout_ns
            .fetch_max(completed_ns, Ordering::Relaxed);
        self.last_completion_ns
            .fetch_max(completed_ns, Ordering::Relaxed);
    }

    fn mark_order(&self, sequence: usize, timestamp: u64) {
        if self.expects_order.get(sequence).copied() != Some(true) {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
        }
        if self.mark_once(&self.order_seen, sequence) {
            self.t_order[sequence].store(timestamp, Ordering::Release);
            self.order_endpoint_calls.fetch_add(1, Ordering::Relaxed);
        }
    }

    fn mark_ack(&self, sequence: usize, instrument: InstrumentIndex, timestamp: u64) {
        if self.expected_instrument.get(sequence).copied() != Some(instrument.0)
            || self.expects_reject.get(sequence).copied() == Some(true)
        {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
        }
        if self.mark_once(&self.ack_seen, sequence) {
            self.t_ack[sequence].store(timestamp, Ordering::Release);
            self.acks.fetch_add(1, Ordering::Relaxed);
        }
    }

    fn mark_fill(&self, sequence: usize, instrument: InstrumentIndex, timestamp: u64) {
        if self.expected_instrument.get(sequence).copied() != Some(instrument.0)
            || self.expects_reject.get(sequence).copied() == Some(true)
        {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
        }
        if self.mark_once(&self.fill_seen, sequence) {
            self.t_fill[sequence].store(timestamp, Ordering::Release);
            self.fills.fetch_add(1, Ordering::Relaxed);
            self.last_fill_ns.fetch_max(timestamp, Ordering::Relaxed);
        }
    }

    fn mark_terminal(&self, sequence: usize, rejected: bool, timestamp: u64) {
        if self.expects_order.get(sequence).copied() != Some(true)
            || self.expects_reject.get(sequence).copied() != Some(rejected)
        {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
        }
        if !self.mark_once(&self.terminal_seen, sequence) {
            return;
        }
        if rejected {
            self.business_errors.fetch_add(1, Ordering::Relaxed);
        }
        self.mark_task_completed(sequence, true);
        self.last_terminal_ns
            .fetch_max(timestamp, Ordering::Relaxed);
        self.last_completion_ns
            .fetch_max(timestamp, Ordering::Relaxed);
        let previous = self.current_in_flight.fetch_sub(1, Ordering::AcqRel);
        if previous == 0 {
            self.current_in_flight.fetch_add(1, Ordering::Relaxed);
            self.route_errors.fetch_add(1, Ordering::Relaxed);
        }
    }

    fn record_in_flight(&self) {
        let current = self.current_in_flight.fetch_add(1, Ordering::AcqRel) + 1;
        self.max_in_flight.fetch_max(current, Ordering::Relaxed);
    }

    fn mark_task_completed(&self, sequence: usize, terminal: bool) {
        if !self.mark_once(&self.completion_seen, sequence) {
            return;
        }
        let Some(task) = self.task_by_sequence.get(sequence).copied() else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            return;
        };
        let Some(completed) = self.task_completed.get(task) else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
            return;
        };
        completed.fetch_add(1, Ordering::Relaxed);
        let by_source = if terminal {
            &self.task_completed_terminal
        } else {
            &self.task_completed_no_order
        };
        if let Some(completed) = by_source.get(task) {
            completed.fetch_add(1, Ordering::Relaxed);
        } else {
            self.route_errors.fetch_add(1, Ordering::Relaxed);
        }
    }
}

#[derive(Debug, Copy, Clone)]
enum PrivateObservationKind {
    Ack,
    Fill,
    Reject,
}

#[derive(Debug, Copy, Clone)]
struct PrivateObservation {
    sequence: usize,
    instrument: InstrumentIndex,
    kind: PrivateObservationKind,
}

#[derive(Debug, Clone, Default)]
struct PipelineGlobalData {
    latest_market: Option<(InstrumentIndex, PublicTrade)>,
    current_market: Option<(InstrumentIndex, usize)>,
    current_private: Option<PrivateObservation>,
}

impl Processor<&MarketEvent<InstrumentIndex, DataKind>> for PipelineGlobalData {
    type Audit = ();

    fn process(&mut self, event: &MarketEvent<InstrumentIndex, DataKind>) -> Self::Audit {
        self.current_private = None;
        self.current_market = None;
        if let DataKind::Trade(trade) = &event.kind {
            self.latest_market = Some((event.instrument, trade.clone()));
            self.current_market = parse_public_sequence(&trade.id)
                .ok()
                .map(|sequence| (event.instrument, sequence));
        }
    }
}

impl Processor<&AccountEvent> for PipelineGlobalData {
    type Audit = ();
    fn process(&mut self, event: &AccountEvent) -> Self::Audit {
        self.current_market = None;
        self.current_private = match &event.kind {
            AccountEventKind::OrderSnapshot(Snapshot(order)) => {
                let kind = match &order.state {
                    OrderState::Active(ActiveOrderState::Open(_)) => {
                        Some(PrivateObservationKind::Ack)
                    }
                    OrderState::Inactive(InactiveOrderState::OpenFailed(_)) => {
                        Some(PrivateObservationKind::Reject)
                    }
                    _ => None,
                };
                kind.and_then(|kind| {
                    parse_cid(order.key.cid.0.as_str())
                        .ok()
                        .map(|sequence| PrivateObservation {
                            sequence,
                            instrument: order.key.instrument,
                            kind,
                        })
                })
            }
            AccountEventKind::Trade(trade) => trade
                .id
                .0
                .as_str()
                .strip_prefix(FILL_PREFIX)
                .and_then(|sequence| sequence.parse().ok())
                .map(|sequence| PrivateObservation {
                    sequence,
                    instrument: trade.instrument,
                    kind: PrivateObservationKind::Fill,
                }),
            _ => None,
        };
    }
}

#[derive(Debug, Clone)]
struct PipelineInstrumentData {
    instrument: InstrumentIndex,
    batch: usize,
    signal_handler: usize,
    last_trade: Option<PublicTrade>,
    last_ordered_sequence: Option<usize>,
    metrics: Arc<PipelineMetrics>,
}

impl InstrumentDataState for PipelineInstrumentData {
    type MarketEventKind = DataKind;

    fn price(&self) -> Option<Decimal> {
        self.last_trade
            .as_ref()
            .and_then(|trade| Decimal::from_f64(trade.price))
    }
}

impl Processor<&MarketEvent<InstrumentIndex, DataKind>> for PipelineInstrumentData {
    type Audit = ();

    fn process(&mut self, event: &MarketEvent<InstrumentIndex, DataKind>) -> Self::Audit {
        if event.exchange != ExchangeId::BinanceSpot || event.instrument != self.instrument {
            self.metrics.route_errors.fetch_add(1, Ordering::Relaxed);
        }
        let DataKind::Trade(trade) = &event.kind else {
            return;
        };
        match parse_public_sequence(&trade.id) {
            Ok(sequence) => self.metrics.mark_trade_callback(
                sequence,
                event.instrument,
                self.batch,
                self.signal_handler,
            ),
            Err(_) => {
                self.metrics.route_errors.fetch_add(1, Ordering::Relaxed);
            }
        }
        self.last_trade = Some(trade.clone());
    }
}

impl Processor<&AccountEvent> for PipelineInstrumentData {
    type Audit = ();

    fn process(&mut self, event: &AccountEvent) -> Self::Audit {
        let callback_ns = self.metrics.now_ns();
        self.metrics
            .account_callbacks
            .fetch_add(1, Ordering::Relaxed);
        if event.exchange != ExchangeIndex(0) {
            self.metrics.route_errors.fetch_add(1, Ordering::Relaxed);
        }

        match &event.kind {
            AccountEventKind::OrderSnapshot(Snapshot(order)) => {
                let Ok(sequence) = parse_cid(order.key.cid.0.as_str()) else {
                    self.metrics.route_errors.fetch_add(1, Ordering::Relaxed);
                    return;
                };
                if self.metrics.task_by_sequence.get(sequence).copied() != Some(self.batch) {
                    self.metrics.mark_cross_batch_error();
                }
                if order.key.instrument != self.instrument {
                    self.metrics.route_errors.fetch_add(1, Ordering::Relaxed);
                }
                match &order.state {
                    OrderState::Active(ActiveOrderState::Open(_)) => {
                        self.metrics
                            .mark_ack(sequence, self.instrument, callback_ns);
                    }
                    OrderState::Inactive(InactiveOrderState::FullyFilled) => {
                        self.metrics.mark_terminal(sequence, false, callback_ns);
                    }
                    OrderState::Inactive(InactiveOrderState::OpenFailed(_)) => {
                        self.metrics.mark_terminal(sequence, true, callback_ns);
                    }
                    _ => {}
                }
            }
            AccountEventKind::Trade(trade) => {
                let Some(raw_sequence) = trade.id.0.as_str().strip_prefix(FILL_PREFIX) else {
                    self.metrics.route_errors.fetch_add(1, Ordering::Relaxed);
                    return;
                };
                match raw_sequence.parse::<usize>() {
                    Ok(sequence) => {
                        if self.metrics.task_by_sequence.get(sequence).copied() != Some(self.batch)
                        {
                            self.metrics.mark_cross_batch_error();
                        }
                        self.metrics
                            .mark_fill(sequence, self.instrument, callback_ns)
                    }
                    Err(_) => {
                        self.metrics.route_errors.fetch_add(1, Ordering::Relaxed);
                    }
                }
            }
            _ => {}
        }
    }
}

impl InFlightRequestRecorder for PipelineInstrumentData {
    fn record_in_flight_cancel(&mut self, _: &OrderRequestCancel) {}

    fn record_in_flight_open(&mut self, request: &OrderRequestOpen) {
        match parse_cid(request.key.cid.0.as_str()) {
            Ok(sequence) => {
                if request.key.instrument != self.instrument {
                    self.metrics.route_errors.fetch_add(1, Ordering::Relaxed);
                }
                self.last_ordered_sequence = Some(sequence);
            }
            Err(_) => {
                self.metrics.route_errors.fetch_add(1, Ordering::Relaxed);
            }
        }
    }
}

#[derive(Debug, Clone)]
struct PipelineSignalHandler {
    index: usize,
}

impl PipelineSignalHandler {
    fn slot(&self, topology: LiveTopology, batch: usize) -> usize {
        match topology {
            LiveTopology::SharedHandler => 0,
            LiveTopology::BatchSharded => batch * SIGNAL_HANDLERS_PER_BATCH + self.index,
            LiveTopology::Ws5Strategy20 => self.index,
        }
    }

    fn observe_private(
        &self,
        topology: LiveTopology,
        data: &PipelineInstrumentData,
        observation: PrivateObservation,
    ) {
        data.metrics.mark_private_handler(
            observation.sequence,
            data.batch,
            observation.instrument,
            self.index,
            self.slot(topology, data.batch),
            matches!(observation.kind, PrivateObservationKind::Fill),
        );
    }

    #[allow(clippy::too_many_arguments)]
    fn on_trade(
        &self,
        topology: LiveTopology,
        owner_batch: Option<usize>,
        mode: LiveMode,
        order_every: usize,
        signal_compute_ns: u64,
        instruments_per_task: usize,
        ticks_per_task: usize,
        instrument: InstrumentIndex,
        trade: &PublicTrade,
        data: &PipelineInstrumentData,
        sequence: usize,
    ) -> Option<OrderRequestOpen> {
        if data.signal_handler != self.index {
            data.metrics.route_errors.fetch_add(1, Ordering::Relaxed);
            return None;
        }
        if !data.metrics.mark_signal_trade(
            sequence,
            instrument,
            data.batch,
            self.index,
            self.slot(topology, data.batch),
        ) {
            return None;
        }
        let sequence_batch = sequence / ticks_per_task;
        if owner_batch.is_some_and(|batch| batch != sequence_batch) {
            data.metrics.mark_cross_batch_error();
            return None;
        }
        data.metrics
            .signal_compute_calls
            .fetch_add(1, Ordering::Relaxed);
        run_signal_compute(signal_compute_ns);
        let message_index = (sequence % ticks_per_task) / instruments_per_task;
        if !should_order(mode, order_every, message_index)
            || data.last_ordered_sequence == Some(sequence)
        {
            return None;
        }

        Some(OrderRequestOpen {
            key: OrderKey {
                exchange: ExchangeIndex(0),
                instrument,
                strategy: strategy_id(topology, self.index),
                cid: ClientOrderId::new(format!("{CID_PREFIX}{sequence}")),
            },
            state: RequestOpen {
                side: trade.side,
                price: Decimal::from_f64(trade.price)?,
                quantity: Decimal::from_f64(trade.amount)?,
                kind: OrderKind::Market,
                time_in_force: TimeInForce::ImmediateOrCancel,
            },
        })
    }
}

#[derive(Debug, Clone)]
struct PipelineStrategy {
    topology: LiveTopology,
    batch: Option<usize>,
    mode: LiveMode,
    order_every: usize,
    signal_compute_ns: u64,
    instruments_per_task: usize,
    ticks_per_task: usize,
    signal_handlers: Vec<PipelineSignalHandler>,
}

impl AlgoStrategy for PipelineStrategy {
    type State = PipelineState;

    fn generate_algo_orders(
        &self,
        state: &Self::State,
    ) -> (
        impl IntoIterator<Item = OrderRequestCancel>,
        impl IntoIterator<Item = OrderRequestOpen>,
    ) {
        if let Some(observation) = state.global.current_private {
            let data = &state
                .instruments
                .instrument_index(&observation.instrument)
                .data;
            for handler in &self.signal_handlers {
                handler.observe_private(self.topology, data, observation);
            }
        }
        let open = state
            .global
            .current_market
            .and_then(|(instrument, sequence)| {
                let (latest_instrument, trade) = state.global.latest_market.as_ref()?;
                let data = &state.instruments.instrument_index(&instrument).data;
                if *latest_instrument != instrument
                    || parse_public_sequence(&trade.id).ok() != Some(sequence)
                {
                    data.metrics.route_errors.fetch_add(1, Ordering::Relaxed);
                    return None;
                }
                let handler = self.signal_handlers.get(data.signal_handler).or_else(|| {
                    data.metrics.route_errors.fetch_add(1, Ordering::Relaxed);
                    None
                })?;
                handler.on_trade(
                    self.topology,
                    self.batch,
                    self.mode,
                    self.order_every,
                    self.signal_compute_ns,
                    self.instruments_per_task,
                    self.ticks_per_task,
                    instrument,
                    trade,
                    data,
                    sequence,
                )
            });

        if let Some((instrument, sequence)) = state.global.current_market {
            state
                .instruments
                .instrument_index(&instrument)
                .data
                .metrics
                .mark_strategy_trade_complete(sequence);
        }

        (std::iter::empty(), open)
    }
}

fn strategy_id(topology: LiveTopology, handler: usize) -> StrategyId {
    match topology {
        LiveTopology::SharedHandler => StrategyId::new(STRATEGY_ID),
        LiveTopology::BatchSharded | LiveTopology::Ws5Strategy20 => {
            StrategyId::new(format!("{STRATEGY_ID}-h{handler}"))
        }
    }
}

impl ClosePositionsStrategy for PipelineStrategy {
    type State = PipelineState;

    fn close_positions_requests<'a>(
        &'a self,
        _: &'a Self::State,
        _: &'a InstrumentFilter,
    ) -> (
        impl IntoIterator<Item = OrderRequestCancel> + 'a,
        impl IntoIterator<Item = OrderRequestOpen> + 'a,
    )
    where
        ExchangeIndex: 'a,
        AssetIndex: 'a,
        InstrumentIndex: 'a,
    {
        (std::iter::empty(), std::iter::empty())
    }
}

impl OnDisconnectStrategy<LiveClock, PipelineState, PipelineExecutionTxs, PipelineRisk>
    for PipelineStrategy
{
    type OnDisconnect = ();
    fn on_disconnect(_: &mut PipelineEngine, _: ExchangeId) -> Self::OnDisconnect {}
}

impl OnTradingDisabled<LiveClock, PipelineState, PipelineExecutionTxs, PipelineRisk>
    for PipelineStrategy
{
    type OnTradingDisabled = ();
    fn on_trading_disabled(_: &mut PipelineEngine) -> Self::OnTradingDisabled {}
}

fn parse_public_sequence(id: &str) -> Result<usize, String> {
    id.parse()
        .map_err(|error| format!("invalid public trade id {id}: {error}"))
}

fn parse_cid(cid: &str) -> Result<usize, String> {
    cid.strip_prefix(CID_PREFIX)
        .ok_or_else(|| format!("unexpected client order id: {cid}"))?
        .parse()
        .map_err(|error| format!("invalid client order id {cid}: {error}"))
}

#[derive(Debug)]
struct PublicFixture {
    sequence: usize,
    frame: WsMessage,
}

#[derive(Debug)]
enum PrivateFixture {
    Success { ack: WsMessage, fill: WsMessage },
    Reject { reject: WsMessage },
}

#[derive(Debug, Clone)]
struct ExpectedOrder {
    instrument: InstrumentIndex,
    strategy: StrategyId,
    symbol: String,
    side: Side,
    price: Decimal,
    quantity: Decimal,
}

#[derive(Debug)]
struct PreparedRun {
    instruments: IndexedInstruments,
    producer_frames: Vec<Vec<PublicFixture>>,
    transformers: Vec<PublicTransformer>,
    private_fixtures: Vec<Option<PrivateFixture>>,
    expected_orders: Vec<Option<ExpectedOrder>>,
    symbol_to_instrument: HashMap<String, InstrumentIndex>,
    metrics: Arc<PipelineMetrics>,
    expected_order_count: usize,
    expected_rejects: usize,
}

#[derive(Debug)]
struct BatchPublicLane {
    batch: usize,
    lane: usize,
    frames: Vec<PublicFixture>,
    transformer: PublicTransformer,
}

#[derive(Debug)]
struct PreparedBatch {
    batch: usize,
    instruments: IndexedInstruments,
    public_lanes: Vec<BatchPublicLane>,
    private_fixtures: HashMap<usize, PrivateFixture>,
    expected_orders: HashMap<usize, ExpectedOrder>,
    symbol_to_instrument: HashMap<String, InstrumentIndex>,
    expected_order_count: usize,
    expected_rejects: usize,
    expected_private_frames: usize,
}

#[derive(Debug)]
struct PreparedBatchRun {
    batches: Vec<PreparedBatch>,
    metrics: Arc<PipelineMetrics>,
    expected_order_count: usize,
    expected_rejects: usize,
    expected_private_frames: usize,
}

/// Benchmark-only Binance Spot private `executionReport` wire DTO.
///
/// This is intentionally local because `barter-execution/src/client/binance/mod.rs` is empty.
/// Deserialization still runs through Barter's production `WebSocketSerdeParser`.
#[derive(Debug, Deserialize)]
struct BenchmarkBinanceExecutionReport {
    #[serde(rename = "e")]
    event: String,
    #[serde(rename = "E")]
    event_time_ms: i64,
    #[serde(rename = "s")]
    symbol: String,
    #[serde(rename = "c")]
    cid: String,
    #[serde(rename = "S")]
    side: String,
    #[serde(rename = "o")]
    order_kind: String,
    #[serde(rename = "f")]
    time_in_force: String,
    #[serde(rename = "q")]
    quantity: String,
    #[serde(rename = "p")]
    price: String,
    #[serde(rename = "x")]
    execution_type: String,
    #[serde(rename = "X")]
    order_status: String,
    #[serde(rename = "r")]
    reject_reason: String,
    #[serde(rename = "i")]
    order_id: u64,
    #[serde(rename = "t")]
    trade_id: i64,
    #[serde(rename = "l")]
    last_quantity: String,
    #[serde(rename = "L")]
    last_price: String,
}

async fn prepare_run(config: RunConfig) -> Result<PreparedRun, String> {
    let config = config.validate()?;
    if !matches!(
        config.topology,
        LiveTopology::SharedHandler | LiveTopology::Ws5Strategy20
    ) {
        return Err(
            "single-Engine preparation requires shared_handler or ws5_strategy20".to_owned(),
        );
    }
    let total_instruments = config.total_instruments()?;
    let total_ticks = config.total_ticks()?;
    let ticks_per_task = config.ticks_per_task()?;

    let symbols = (0..total_instruments)
        .map(|index| format!("A{index:05}USDT"))
        .collect::<Vec<_>>();
    let instruments = IndexedInstruments::new(symbols.iter().enumerate().map(|(index, symbol)| {
        Instrument::spot(
            ExchangeId::BinanceSpot,
            format!("binance_spot_a{index:05}_usdt"),
            symbol.clone(),
            Underlying::new(format!("a{index:05}"), "usdt".to_owned()),
            None,
        )
    }));
    let symbol_to_instrument = instruments
        .instruments()
        .iter()
        .map(|instrument| {
            (
                instrument.value.name_exchange.name().to_string(),
                instrument.key,
            )
        })
        .collect::<HashMap<_, _>>();

    let mut expected_instrument = vec![usize::MAX; total_ticks];
    let mut task_by_sequence = vec![usize::MAX; total_ticks];
    let mut handler_by_sequence = vec![0; total_ticks];
    let mut expects_order = vec![false; total_ticks];
    let mut expects_reject = vec![false; total_ticks];
    let mut expected_orders = vec![None; total_ticks];
    let mut private_fixtures = (0..total_ticks).map(|_| None).collect::<Vec<_>>();
    let mut producer_frames = Vec::with_capacity(config.tasks);
    let mut order_ordinal = 0;
    let mut expected_rejects = 0;

    for task in 0..config.tasks {
        let handler = match config.topology {
            LiveTopology::SharedHandler => 0,
            LiveTopology::Ws5Strategy20 => task,
            LiveTopology::BatchSharded => unreachable!("validated single-Engine topology"),
        };
        let mut frames = Vec::with_capacity(ticks_per_task);
        for message_index in 0..config.messages_per_instrument {
            for local_instrument in 0..config.instruments_per_task {
                let instrument_ordinal = task * config.instruments_per_task + local_instrument;
                let sequence = task * ticks_per_task
                    + message_index * config.instruments_per_task
                    + local_instrument;
                let symbol = &symbols[instrument_ordinal];
                let instrument = *symbol_to_instrument
                    .get(symbol)
                    .ok_or_else(|| format!("missing indexed instrument for {symbol}"))?;
                let price_text = format!(
                    "{:.2}",
                    30_000.0 + instrument_ordinal as f64 + message_index as f64 * 0.01
                );
                let quantity_text = format!("{:.6}", 0.001 + local_instrument as f64 * 0.000001);
                let price = price_text
                    .parse::<f64>()
                    .map_err(|error| error.to_string())?;
                let amount = quantity_text
                    .parse::<f64>()
                    .map_err(|error| error.to_string())?;
                let buyer_is_maker = sequence % 2 == 1;
                let side = if buyer_is_maker {
                    Side::Sell
                } else {
                    Side::Buy
                };
                let timestamp =
                    BASE_EPOCH_MS + i64::try_from(sequence).map_err(|error| error.to_string())?;

                expected_instrument[sequence] = instrument.0;
                task_by_sequence[sequence] = task;
                handler_by_sequence[sequence] = handler;
                frames.push(PublicFixture {
                    sequence,
                    frame: WsMessage::text(
                        json!({
                            "e": "trade", "E": timestamp, "s": symbol,
                            "t": sequence as u64, "p": price_text, "q": quantity_text,
                            "T": timestamp, "m": buyer_is_maker, "M": true
                        })
                        .to_string(),
                    ),
                });

                if should_order(config.mode, config.order_every, message_index) {
                    let reject = config.scenario == LiveScenario::BusinessError
                        && order_ordinal % config.reject_every == 0;
                    expects_order[sequence] = true;
                    expects_reject[sequence] = reject;
                    if reject {
                        expected_rejects += 1;
                    }
                    let expected = ExpectedOrder {
                        instrument,
                        strategy: strategy_id(config.topology, handler),
                        symbol: symbol.clone(),
                        side,
                        price: Decimal::from_f64(price)
                            .ok_or_else(|| "fixture price is non-finite".to_owned())?,
                        quantity: Decimal::from_f64(amount)
                            .ok_or_else(|| "fixture quantity is non-finite".to_owned())?,
                    };
                    private_fixtures[sequence] = Some(build_private_fixture(
                        sequence, &expected, timestamp, reject,
                    ));
                    expected_orders[sequence] = Some(expected);
                    order_ordinal += 1;
                }
            }
        }
        producer_frames.push(frames);
    }

    let mut transformers = Vec::with_capacity(config.tasks);
    for task in 0..config.tasks {
        let instrument_map = (0..config.instruments_per_task)
            .map(|local| {
                let symbol = &symbols[task * config.instruments_per_task + local];
                let instrument = symbol_to_instrument[symbol];
                (SubscriptionId::from(format!("@trade|{symbol}")), instrument)
            })
            .collect::<Map<_>>();
        let (sink_tx, _sink_rx) = mpsc::unbounded_channel();
        let transformer = <PublicTransformer as ExchangeTransformer<
            BinanceSpot,
            InstrumentIndex,
            PublicTrades,
        >>::init(instrument_map, &[], sink_tx)
        .await
        .map_err(|error| format!("failed to initialise public transformer: {error}"))?;
        transformers.push(transformer);
    }

    let metrics = Arc::new(PipelineMetrics::new(
        expected_instrument,
        task_by_sequence,
        handler_by_sequence,
        expects_order,
        expects_reject,
        config.tasks,
        config.topology.signal_handlers(config.tasks)?,
    ));
    Ok(PreparedRun {
        instruments,
        producer_frames,
        transformers,
        private_fixtures,
        expected_orders,
        symbol_to_instrument,
        metrics,
        expected_order_count: order_ordinal,
        expected_rejects,
    })
}

async fn prepare_batch_sharded_run(config: RunConfig) -> Result<PreparedBatchRun, String> {
    let config = config.validate()?;
    if config.topology != LiveTopology::BatchSharded {
        return Err("batch preparation requires batch_sharded topology".to_owned());
    }
    let total_ticks = config.total_ticks()?;
    let ticks_per_batch = config.ticks_per_task()?;
    let mut expected_instrument = vec![usize::MAX; total_ticks];
    let mut task_by_sequence = vec![usize::MAX; total_ticks];
    let mut handler_by_sequence = vec![usize::MAX; total_ticks];
    let mut expects_order = vec![false; total_ticks];
    let mut expects_reject = vec![false; total_ticks];
    let mut batches = Vec::with_capacity(config.tasks);
    let mut expected_order_count = 0;
    let mut expected_rejects = 0;
    let mut expected_private_frames = 0;

    for batch in 0..config.tasks {
        let symbols = (0..BATCH_TRADE_LANES)
            .map(|lane| format!("B{batch:04}A{lane:02}USDT"))
            .collect::<Vec<_>>();
        let instruments =
            IndexedInstruments::new(symbols.iter().enumerate().map(|(lane, symbol)| {
                Instrument::spot(
                    ExchangeId::BinanceSpot,
                    format!("binance_spot_b{batch:04}_a{lane:02}_usdt"),
                    symbol.clone(),
                    Underlying::new(format!("b{batch:04}a{lane:02}"), "usdt".to_owned()),
                    None,
                )
            }));
        let symbol_to_instrument = instruments
            .instruments()
            .iter()
            .map(|instrument| {
                (
                    instrument.value.name_exchange.name().to_string(),
                    instrument.key,
                )
            })
            .collect::<HashMap<_, _>>();
        let mut lane_frames = (0..BATCH_TRADE_LANES)
            .map(|_| Vec::with_capacity(config.messages_per_instrument))
            .collect::<Vec<_>>();
        let mut private_fixtures = HashMap::new();
        let mut expected_orders = HashMap::new();
        let mut batch_expected_orders = 0;
        let mut batch_expected_rejects = 0;
        let mut batch_expected_private_frames = 0;

        for message_index in 0..config.messages_per_instrument {
            for lane in 0..BATCH_TRADE_LANES {
                let sequence = batch * ticks_per_batch + message_index * BATCH_TRADE_LANES + lane;
                let symbol = &symbols[lane];
                let instrument = symbol_to_instrument[symbol];
                let handler = lane / TRADE_LANES_PER_SIGNAL_HANDLER;
                let price_text = format!(
                    "{:.2}",
                    30_000.0
                        + (batch * BATCH_TRADE_LANES + lane) as f64
                        + message_index as f64 * 0.01
                );
                let quantity_text = format!("{:.6}", 0.001 + lane as f64 * 0.000001);
                let price = price_text
                    .parse::<f64>()
                    .map_err(|error| error.to_string())?;
                let amount = quantity_text
                    .parse::<f64>()
                    .map_err(|error| error.to_string())?;
                let buyer_is_maker = sequence % 2 == 1;
                let side = if buyer_is_maker {
                    Side::Sell
                } else {
                    Side::Buy
                };
                let timestamp =
                    BASE_EPOCH_MS + i64::try_from(sequence).map_err(|error| error.to_string())?;

                expected_instrument[sequence] = instrument.0;
                task_by_sequence[sequence] = batch;
                handler_by_sequence[sequence] = handler;
                lane_frames[lane].push(PublicFixture {
                    sequence,
                    frame: WsMessage::text(
                        json!({
                            "e": "trade", "E": timestamp, "s": symbol,
                            "t": sequence as u64, "p": price_text, "q": quantity_text,
                            "T": timestamp, "m": buyer_is_maker, "M": true
                        })
                        .to_string(),
                    ),
                });

                if should_order(config.mode, config.order_every, message_index) {
                    let reject = config.scenario == LiveScenario::BusinessError
                        && expected_order_count % config.reject_every == 0;
                    expects_order[sequence] = true;
                    expects_reject[sequence] = reject;
                    let expected = ExpectedOrder {
                        instrument,
                        strategy: strategy_id(config.topology, handler),
                        symbol: symbol.clone(),
                        side,
                        price: Decimal::from_f64(price)
                            .ok_or_else(|| "fixture price is non-finite".to_owned())?,
                        quantity: Decimal::from_f64(amount)
                            .ok_or_else(|| "fixture quantity is non-finite".to_owned())?,
                    };
                    let fixture = build_private_fixture(sequence, &expected, timestamp, reject);
                    expected_orders.insert(sequence, expected);
                    private_fixtures.insert(sequence, fixture);
                    expected_order_count += 1;
                    batch_expected_orders += 1;
                    if reject {
                        expected_rejects += 1;
                        batch_expected_rejects += 1;
                        expected_private_frames += 1;
                        batch_expected_private_frames += 1;
                    } else {
                        expected_private_frames += 2;
                        batch_expected_private_frames += 2;
                    }
                }
            }
        }

        let mut public_lanes = Vec::with_capacity(BATCH_TRADE_LANES);
        for (lane, frames) in lane_frames.into_iter().enumerate() {
            let symbol = &symbols[lane];
            let instrument = symbol_to_instrument[symbol];
            let instrument_map =
                std::iter::once((SubscriptionId::from(format!("@trade|{symbol}")), instrument))
                    .collect::<Map<_>>();
            let (sink_tx, _sink_rx) = mpsc::unbounded_channel();
            let transformer = <PublicTransformer as ExchangeTransformer<
                BinanceSpot,
                InstrumentIndex,
                PublicTrades,
            >>::init(instrument_map, &[], sink_tx)
            .await
            .map_err(|error| {
                format!("failed to initialise batch {batch} public lane {lane}: {error}")
            })?;
            public_lanes.push(BatchPublicLane {
                batch,
                lane,
                frames,
                transformer,
            });
        }
        batches.push(PreparedBatch {
            batch,
            instruments,
            public_lanes,
            private_fixtures,
            expected_orders,
            symbol_to_instrument,
            expected_order_count: batch_expected_orders,
            expected_rejects: batch_expected_rejects,
            expected_private_frames: batch_expected_private_frames,
        });
    }

    let metrics = Arc::new(PipelineMetrics::new(
        expected_instrument,
        task_by_sequence,
        handler_by_sequence,
        expects_order,
        expects_reject,
        config.tasks,
        config.topology.signal_handlers(config.tasks)?,
    ));
    Ok(PreparedBatchRun {
        batches,
        metrics,
        expected_order_count,
        expected_rejects,
        expected_private_frames,
    })
}

fn build_private_fixture(
    sequence: usize,
    expected: &ExpectedOrder,
    timestamp: i64,
    reject: bool,
) -> PrivateFixture {
    let side = match expected.side {
        Side::Buy => "BUY",
        Side::Sell => "SELL",
    };
    let cid = format!("{CID_PREFIX}{sequence}");
    let order_id = 10_000_000_u64 + sequence as u64;
    let common = |execution_type: &str,
                  status: &str,
                  reason: &str,
                  trade_id: i64,
                  last_quantity: String,
                  last_price: String| {
        WsMessage::text(
            json!({
                "e": "executionReport", "E": timestamp, "s": expected.symbol,
                "c": cid, "S": side, "o": "MARKET", "f": "IOC",
                "q": expected.quantity.to_string(), "p": expected.price.to_string(),
                "x": execution_type, "X": status, "r": reason,
                "i": order_id, "t": trade_id, "l": last_quantity, "L": last_price
            })
            .to_string(),
        )
    };
    if reject {
        PrivateFixture::Reject {
            reject: common(
                "REJECTED",
                "REJECTED",
                "INSUFFICIENT_BALANCE",
                -1,
                "0".to_owned(),
                "0".to_owned(),
            ),
        }
    } else {
        PrivateFixture::Success {
            ack: common("NEW", "NEW", "NONE", -1, "0".to_owned(), "0".to_owned()),
            fill: common(
                "TRADE",
                "FILLED",
                "NONE",
                order_id as i64,
                expected.quantity.to_string(),
                expected.price.to_string(),
            ),
        }
    }
}

fn build_engine(
    instruments: &IndexedInstruments,
    execution_tx: UnboundedTx<ExecutionRequest>,
    metrics: Arc<PipelineMetrics>,
    config: RunConfig,
    batch: Option<usize>,
) -> PipelineEngine {
    let mut state =
        EngineState::builder(instruments, PipelineGlobalData::default(), |instrument| {
            let instrument_batch =
                batch.unwrap_or_else(|| instrument.key.0 / config.instruments_per_task);
            let signal_handler = match config.topology {
                LiveTopology::SharedHandler => 0,
                LiveTopology::BatchSharded => instrument.key.0 / TRADE_LANES_PER_SIGNAL_HANDLER,
                LiveTopology::Ws5Strategy20 => instrument.key.0 / WS5_SYMBOLS_PER_PUBLIC_WS,
            };
            PipelineInstrumentData {
                instrument: instrument.key,
                batch: instrument_batch,
                signal_handler,
                last_trade: None,
                last_ordered_sequence: None,
                metrics: Arc::clone(&metrics),
            }
        })
        .trading_state(TradingState::Enabled)
        .build();
    for instrument in state.instruments.instruments_mut(&InstrumentFilter::None) {
        instrument.orders.0.reserve(config.messages_per_instrument);
    }
    let execution_txs =
        MultiExchangeTxMap::from_iter([(ExchangeId::BinanceSpot, Some(execution_tx))]);
    Engine::new(
        LiveClock,
        state,
        execution_txs,
        PipelineStrategy {
            topology: config.topology,
            batch,
            mode: config.mode,
            order_every: config.order_every,
            signal_compute_ns: config.signal_compute_ns,
            instruments_per_task: config.instruments_per_task,
            ticks_per_task: config
                .ticks_per_task()
                .expect("validated live pipeline ticks per task"),
            signal_handlers: (0..config.topology.account_receivers_per_batch())
                .map(|index| PipelineSignalHandler { index })
                .collect(),
        },
        DefaultRiskManager::default(),
    )
}

fn parse_private_frame(frame: WsMessage) -> Result<BenchmarkBinanceExecutionReport, String> {
    <WebSocketSerdeParser as StreamParser<BenchmarkBinanceExecutionReport>>::parse(Ok(frame))
        .ok_or_else(|| "private parser ignored execution report frame".to_owned())?
        .map_err(|error| format!("private executionReport decode failed: {error}"))
}

#[derive(Debug)]
enum DecodedPrivateEvents {
    One(EngineEvent<DataKind>),
    Two(EngineEvent<DataKind>, EngineEvent<DataKind>),
}

fn decode_private_events(
    report: BenchmarkBinanceExecutionReport,
    symbol_to_instrument: &HashMap<String, InstrumentIndex>,
    topology: LiveTopology,
) -> Result<DecodedPrivateEvents, String> {
    if report.event != "executionReport" {
        return Err(format!("unexpected private event type: {}", report.event));
    }
    let instrument = *symbol_to_instrument
        .get(&report.symbol)
        .ok_or_else(|| format!("private report symbol not indexed: {}", report.symbol))?;
    let sequence = parse_cid(&report.cid)?;
    let side = match report.side.as_str() {
        "BUY" => Side::Buy,
        "SELL" => Side::Sell,
        other => return Err(format!("unsupported private order side: {other}")),
    };
    if report.order_kind != "MARKET" || report.time_in_force != "IOC" {
        return Err("private bridge expected MARKET IOC order".to_owned());
    }
    let price = report
        .price
        .parse::<Decimal>()
        .map_err(|error| error.to_string())?;
    let quantity = report
        .quantity
        .parse::<Decimal>()
        .map_err(|error| error.to_string())?;
    let time_exchange = Utc
        .timestamp_millis_opt(report.event_time_ms)
        .single()
        .ok_or_else(|| format!("invalid private event timestamp: {}", report.event_time_ms))?;
    let key = OrderKey {
        exchange: ExchangeIndex(0),
        instrument,
        strategy: strategy_id(
            topology,
            match topology {
                LiveTopology::SharedHandler => 0,
                LiveTopology::BatchSharded => instrument.0 / TRADE_LANES_PER_SIGNAL_HANDLER,
                LiveTopology::Ws5Strategy20 => instrument.0 / WS5_SYMBOLS_PER_PUBLIC_WS,
            },
        ),
        cid: ClientOrderId::new(&report.cid),
    };
    let order = |state| Order {
        key: key.clone(),
        side,
        price,
        quantity,
        kind: OrderKind::Market,
        time_in_force: TimeInForce::ImmediateOrCancel,
        state,
    };

    match (report.execution_type.as_str(), report.order_status.as_str()) {
        ("NEW", "NEW") => {
            if report.reject_reason != "NONE" {
                return Err("NEW executionReport contains reject reason".to_owned());
            }
            Ok(DecodedPrivateEvents::One(
                AccountEvent::new(
                    ExchangeIndex(0),
                    AccountEventKind::OrderSnapshot(Snapshot(order(OrderState::active(Open {
                        id: OrderId::new(report.order_id.to_string()),
                        time_exchange,
                        filled_quantity: Decimal::ZERO,
                    })))),
                )
                .into(),
            ))
        }
        ("TRADE", "FILLED") => {
            let last_price = report
                .last_price
                .parse::<Decimal>()
                .map_err(|error| error.to_string())?;
            let last_quantity = report
                .last_quantity
                .parse::<Decimal>()
                .map_err(|error| error.to_string())?;
            if report.trade_id < 0 {
                return Err("FILLED executionReport has no trade id".to_owned());
            }
            let fill = AccountEvent::new(
                ExchangeIndex(0),
                AccountEventKind::Trade(Trade {
                    id: TradeId::new(format!("{FILL_PREFIX}{sequence}")),
                    order_id: OrderId::new(report.order_id.to_string()),
                    instrument,
                    strategy: key.strategy.clone(),
                    time_exchange,
                    side,
                    price: last_price,
                    quantity: last_quantity,
                    fees: AssetFees::<QuoteAsset>::default(),
                }),
            );
            let terminal = AccountEvent::new(
                ExchangeIndex(0),
                AccountEventKind::OrderSnapshot(Snapshot(order(OrderState::<
                    AssetIndex,
                    InstrumentIndex,
                >::fully_filled()))),
            );
            Ok(DecodedPrivateEvents::Two(fill.into(), terminal.into()))
        }
        ("REJECTED", "REJECTED") => {
            if report.reject_reason == "NONE" {
                return Err("REJECTED executionReport has no business reason".to_owned());
            }
            Ok(DecodedPrivateEvents::One(
                AccountEvent::new(
                    ExchangeIndex(0),
                    AccountEventKind::OrderSnapshot(Snapshot(order(OrderState::inactive(
                        OrderError::Rejected(ApiError::OrderRejected(report.reject_reason)),
                    )))),
                )
                .into(),
            ))
        }
        pair => Err(format!("unsupported executionReport transition: {pair:?}")),
    }
}

fn process_private_frame(
    frame: WsMessage,
    feed_tx: &UnboundedTx<EngineEvent<DataKind>>,
    symbol_to_instrument: &HashMap<String, InstrumentIndex>,
    metrics: &PipelineMetrics,
    topology: LiveTopology,
) -> Result<(), String> {
    let report = parse_private_frame(frame)?;
    metrics
        .private_frames_parsed
        .fetch_add(1, Ordering::Relaxed);
    let send = |event| {
        feed_tx
            .send(event)
            .map_err(|error| format!("failed to route private event to Engine: {error:?}"))
    };
    match decode_private_events(report, symbol_to_instrument, topology)? {
        DecodedPrivateEvents::One(event) => send(event),
        DecodedPrivateEvents::Two(first, second) => {
            send(first)?;
            send(second)
        }
    }
}

fn validate_open(
    request: &OrderRequestOpen,
    sequence: usize,
    expected: &ExpectedOrder,
) -> Result<(), String> {
    if request.key.exchange != ExchangeIndex(0)
        || request.key.instrument != expected.instrument
        || request.key.strategy != expected.strategy
    {
        return Err(format!("incorrect order route for sequence {sequence}"));
    }
    if request.state.side != expected.side
        || request.state.price != expected.price
        || request.state.quantity != expected.quantity
        || request.state.kind != OrderKind::Market
        || request.state.time_in_force != TimeInForce::ImmediateOrCancel
    {
        return Err(format!("order payload mismatch for sequence {sequence}"));
    }
    Ok(())
}

#[derive(Debug)]
struct EngineSummary {
    ending_in_flight: usize,
    audited_events: usize,
}

#[derive(Debug)]
struct VenueSummary {
    orders: usize,
    shutdowns: usize,
}

async fn route_private_frame(
    frame: WsMessage,
    raw_private_tx: Option<&mpsc::Sender<WsMessage>>,
    feed_tx: &UnboundedTx<EngineEvent<DataKind>>,
    symbol_to_instrument: &HashMap<String, InstrumentIndex>,
    metrics: &PipelineMetrics,
    topology: LiveTopology,
) -> Result<(), String> {
    match raw_private_tx {
        Some(raw_private_tx) => raw_private_tx
            .send(frame)
            .await
            .map_err(|_| "bounded raw AccountOrder ingress closed".to_owned()),
        None => process_private_frame(frame, feed_tx, symbol_to_instrument, metrics, topology),
    }
}

#[allow(clippy::too_many_arguments)]
async fn run_public_producer(
    task: usize,
    frames: Vec<PublicFixture>,
    mut transformer: PublicTransformer,
    feed_tx: UnboundedTx<EngineEvent<DataKind>>,
    metrics: Arc<PipelineMetrics>,
    barrier: Arc<Barrier>,
    go: Arc<AtomicBool>,
    cancel: Arc<AtomicBool>,
    ready_tx: mpsc::UnboundedSender<()>,
) -> Result<(usize, usize), String> {
    ready_tx
        .send(())
        .map_err(|_| "producer readiness receiver closed".to_owned())?;
    barrier.wait().await;
    while !go.load(Ordering::Acquire) {
        tokio::task::yield_now().await;
    }

    let mut sent = 0;
    for fixture in frames {
        if sent % 64 == 0 && cancel.load(Ordering::Acquire) {
            return Err(format!(
                "public producer {task} cancelled after {sent} frames"
            ));
        }
        let start_ns = metrics.now_ns();
        metrics.t0[fixture.sequence].store(start_ns, Ordering::Release);
        let decoded =
            <WebSocketSerdeParser as StreamParser<BinanceTrade>>::parse(Ok(fixture.frame))
                .ok_or_else(|| "public parser ignored trade frame".to_owned())?
                .map_err(|error| format!("public Binance trade decode failed: {error}"))?;
        let mut transformed = transformer.transform(decoded).into_iter();
        let normalised = transformed
            .next()
            .ok_or_else(|| "public transformer emitted no market event".to_owned())?
            .map_err(|error| format!("public Binance trade transform failed: {error}"))?;
        metrics.mark_public(fixture.sequence, metrics.now_ns());
        if transformed.next().is_some() {
            metrics.route_errors.fetch_add(1, Ordering::Relaxed);
            return Err("public transformer emitted multiple events for one trade".to_owned());
        }
        let event: MarketEvent<InstrumentIndex, DataKind> = normalised.into();
        feed_tx
            .send(EngineEvent::Market(MarketStreamEvent::Item(event)))
            .map_err(|error| format!("failed to route public event to Engine: {error:?}"))?;
        sent += 1;
        tokio::task::yield_now().await;
        metrics
            .public_cooperative_yields
            .fetch_add(1, Ordering::Relaxed);
    }
    Ok((task, sent))
}

#[allow(clippy::too_many_arguments)]
async fn run_venue(
    mut execution_rx: UnboundedRx<ExecutionRequest>,
    feed_tx: UnboundedTx<EngineEvent<DataKind>>,
    raw_private_tx: Option<mpsc::Sender<WsMessage>>,
    mut private_fixtures: Vec<Option<PrivateFixture>>,
    expected_orders: Vec<Option<ExpectedOrder>>,
    symbol_to_instrument: HashMap<String, InstrumentIndex>,
    metrics: Arc<PipelineMetrics>,
    expected_order_count: usize,
    topology: LiveTopology,
    cancel: Arc<AtomicBool>,
    hold_completion: bool,
    ready_tx: mpsc::UnboundedSender<()>,
    done_tx: oneshot::Sender<Result<(), String>>,
) -> Result<VenueSummary, String> {
    ready_tx
        .send(())
        .map_err(|_| "venue readiness receiver closed".to_owned())?;
    let mut done_tx = Some(done_tx);
    let mut orders = 0;
    let mut shutdowns = 0;

    while let Some(request) = StreamExt::next(&mut execution_rx).await {
        if orders % 64 == 0 && cancel.load(Ordering::Acquire) {
            return Err(format!("venue cancelled after {orders} orders"));
        }
        match request {
            ExecutionRequest::Open(open) => {
                let order_ns = metrics.now_ns();
                metrics.record_in_flight();
                let sequence = parse_cid(open.key.cid.0.as_str())?;
                metrics.mark_order(sequence, order_ns);
                let expected = expected_orders
                    .get(sequence)
                    .and_then(Option::as_ref)
                    .ok_or_else(|| format!("unexpected order for sequence {sequence}"))?;
                if let Err(error) = validate_open(&open, sequence, expected) {
                    metrics.route_errors.fetch_add(1, Ordering::Relaxed);
                    return Err(error);
                }
                let fixture = private_fixtures
                    .get_mut(sequence)
                    .and_then(Option::take)
                    .ok_or_else(|| format!("missing private fixture for sequence {sequence}"))?;
                match fixture {
                    PrivateFixture::Success { ack, fill } => {
                        route_private_frame(
                            ack,
                            raw_private_tx.as_ref(),
                            &feed_tx,
                            &symbol_to_instrument,
                            &metrics,
                            topology,
                        )
                        .await?;
                        route_private_frame(
                            fill,
                            raw_private_tx.as_ref(),
                            &feed_tx,
                            &symbol_to_instrument,
                            &metrics,
                            topology,
                        )
                        .await?;
                    }
                    PrivateFixture::Reject { reject } => {
                        route_private_frame(
                            reject,
                            raw_private_tx.as_ref(),
                            &feed_tx,
                            &symbol_to_instrument,
                            &metrics,
                            topology,
                        )
                        .await?;
                    }
                }
                orders += 1;
                if orders == expected_order_count
                    && !hold_completion
                    && let Some(done_tx) = done_tx.take()
                {
                    let _ = done_tx.send(Ok(()));
                }
            }
            ExecutionRequest::Cancel(_) => {
                return Err("strategy emitted an unexpected cancel request".to_owned());
            }
            ExecutionRequest::Shutdown => {
                shutdowns += 1;
                break;
            }
        }
    }
    if orders != expected_order_count {
        return Err(format!(
            "venue received {orders} of {expected_order_count} expected orders"
        ));
    }
    if shutdowns != 1 {
        return Err(format!("venue received {shutdowns} shutdown requests"));
    }
    Ok(VenueSummary { orders, shutdowns })
}

#[derive(Debug)]
struct RawPrivateFrame {
    batch: usize,
    frame: WsMessage,
}

#[derive(Debug)]
struct AccountIngressSummary {
    frames: usize,
}

#[allow(clippy::too_many_arguments)]
async fn run_single_account_ingress(
    mut raw_rx: mpsc::Receiver<WsMessage>,
    feed_tx: UnboundedTx<EngineEvent<DataKind>>,
    symbol_to_instrument: HashMap<String, InstrumentIndex>,
    metrics: Arc<PipelineMetrics>,
    expected_frames: usize,
    topology: LiveTopology,
    cancel: Arc<AtomicBool>,
    ready_tx: mpsc::UnboundedSender<()>,
) -> Result<AccountIngressSummary, String> {
    ready_tx
        .send(())
        .map_err(|_| "AccountOrder ingress readiness receiver closed".to_owned())?;
    let mut frames = 0;
    while frames < expected_frames {
        if cancel.load(Ordering::Acquire) {
            return Err(format!(
                "AccountOrder ingress cancelled after {frames}/{expected_frames} frames"
            ));
        }
        let frame = raw_rx.recv().await.ok_or_else(|| {
            format!("raw AccountOrder ingress closed after {frames}/{expected_frames} frames")
        })?;
        let report = parse_private_frame(frame)?;
        metrics
            .private_frames_parsed
            .fetch_add(1, Ordering::Relaxed);
        let send = |event| {
            feed_tx
                .send(event)
                .map_err(|error| format!("failed routing private event to Engine: {error:?}"))
        };
        match decode_private_events(report, &symbol_to_instrument, topology)? {
            DecodedPrivateEvents::One(event) => send(event)?,
            DecodedPrivateEvents::Two(first, second) => {
                send(first)?;
                send(second)?;
            }
        }
        frames += 1;
        tokio::task::yield_now().await;
    }
    if raw_rx.try_recv().is_ok() {
        metrics.duplicates.fetch_add(1, Ordering::Relaxed);
        return Err(format!(
            "AccountOrder ingress received more than {expected_frames} frames"
        ));
    }
    Ok(AccountIngressSummary { frames })
}

#[derive(Debug)]
enum BatchProgress {
    VenueOrders(usize),
    AccountIngress(usize),
    Failed {
        role: &'static str,
        batch: usize,
        error: String,
    },
}

async fn run_batch_public_lane(
    lane: BatchPublicLane,
    feed_tx: UnboundedTx<EngineEvent<DataKind>>,
    metrics: Arc<PipelineMetrics>,
    barrier: Arc<Barrier>,
    go: Arc<AtomicBool>,
    cancel: Arc<AtomicBool>,
    ready_tx: mpsc::UnboundedSender<()>,
) -> Result<(usize, usize, usize), String> {
    ready_tx
        .send(())
        .map_err(|_| "batch public lane readiness receiver closed".to_owned())?;
    barrier.wait().await;
    while !go.load(Ordering::Acquire) {
        tokio::task::yield_now().await;
    }

    let mut sent = 0;
    let mut transformer = lane.transformer;
    for fixture in lane.frames {
        if cancel.load(Ordering::Acquire) {
            return Err(format!(
                "batch {} public lane {} cancelled after {sent} frames",
                lane.batch, lane.lane
            ));
        }
        if metrics.task_by_sequence.get(fixture.sequence).copied() != Some(lane.batch) {
            metrics.mark_cross_batch_error();
            return Err(format!(
                "batch {} public lane {} owns cross-batch sequence {}",
                lane.batch, lane.lane, fixture.sequence
            ));
        }
        if metrics.expected_instrument.get(fixture.sequence).copied() != Some(lane.lane) {
            metrics.route_errors.fetch_add(1, Ordering::Relaxed);
            return Err(format!(
                "batch {} public lane {} owns incorrect sequence {}",
                lane.batch, lane.lane, fixture.sequence
            ));
        }
        let start_ns = metrics.now_ns();
        metrics.t0[fixture.sequence].store(start_ns, Ordering::Release);
        let decoded =
            <WebSocketSerdeParser as StreamParser<BinanceTrade>>::parse(Ok(fixture.frame))
                .ok_or_else(|| "public parser ignored trade frame".to_owned())?
                .map_err(|error| format!("public Binance trade decode failed: {error}"))?;
        let mut transformed = transformer.transform(decoded).into_iter();
        let normalised = transformed
            .next()
            .ok_or_else(|| "public transformer emitted no market event".to_owned())?
            .map_err(|error| format!("public Binance trade transform failed: {error}"))?;
        metrics.mark_public(fixture.sequence, metrics.now_ns());
        if transformed.next().is_some() {
            metrics.route_errors.fetch_add(1, Ordering::Relaxed);
            return Err("public transformer emitted multiple events for one trade".to_owned());
        }
        let event: MarketEvent<InstrumentIndex, DataKind> = normalised.into();
        feed_tx
            .send(EngineEvent::Market(MarketStreamEvent::Item(event)))
            .map_err(|error| {
                format!(
                    "failed routing batch {} public lane {} to Engine: {error:?}",
                    lane.batch, lane.lane
                )
            })?;
        sent += 1;
        tokio::task::yield_now().await;
        metrics
            .public_cooperative_yields
            .fetch_add(1, Ordering::Relaxed);
    }
    Ok((lane.batch, lane.lane, sent))
}

#[allow(clippy::too_many_arguments)]
async fn run_batch_account_ingress(
    batch: usize,
    mut raw_rx: mpsc::Receiver<RawPrivateFrame>,
    feed_tx: UnboundedTx<EngineEvent<DataKind>>,
    symbol_to_instrument: HashMap<String, InstrumentIndex>,
    metrics: Arc<PipelineMetrics>,
    expected_frames: usize,
    cancel: Arc<AtomicBool>,
    ready_tx: mpsc::UnboundedSender<()>,
    progress_tx: mpsc::UnboundedSender<BatchProgress>,
) -> Result<AccountIngressSummary, String> {
    ready_tx
        .send(())
        .map_err(|_| format!("batch {batch} account ingress readiness receiver closed"))?;
    let mut frames = 0;
    while frames < expected_frames {
        if cancel.load(Ordering::Acquire) {
            return Err(format!(
                "batch {batch} account ingress cancelled after {frames} frames"
            ));
        }
        let raw = raw_rx.recv().await.ok_or_else(|| {
            format!("batch {batch} private raw ingress closed after {frames}/{expected_frames}")
        })?;
        if raw.batch != batch {
            metrics.mark_cross_batch_error();
            return Err(format!(
                "private raw frame crossed batches: expected {batch}, got {}",
                raw.batch
            ));
        }
        let report = parse_private_frame(raw.frame)?;
        let sequence = parse_cid(&report.cid)?;
        if metrics.task_by_sequence.get(sequence).copied() != Some(batch) {
            metrics.mark_cross_batch_error();
            return Err(format!(
                "batch {batch} account ingress received sequence {sequence} from another batch"
            ));
        }
        metrics
            .private_frames_parsed
            .fetch_add(1, Ordering::Relaxed);
        let send = |event| {
            feed_tx.send(event).map_err(|error| {
                format!("failed routing batch {batch} private event to Engine: {error:?}")
            })
        };
        match decode_private_events(report, &symbol_to_instrument, LiveTopology::BatchSharded)? {
            DecodedPrivateEvents::One(event) => send(event)?,
            DecodedPrivateEvents::Two(first, second) => {
                send(first)?;
                send(second)?;
            }
        }
        frames += 1;
        tokio::task::yield_now().await;
    }
    if raw_rx.try_recv().is_ok() {
        metrics.duplicates.fetch_add(1, Ordering::Relaxed);
        return Err(format!(
            "batch {batch} account ingress received more than {expected_frames} frames"
        ));
    }
    progress_tx
        .send(BatchProgress::AccountIngress(batch))
        .map_err(|_| format!("batch {batch} progress receiver closed"))?;
    Ok(AccountIngressSummary { frames })
}

#[allow(clippy::too_many_arguments)]
async fn run_batch_venue(
    batch: usize,
    mut execution_rx: UnboundedRx<ExecutionRequest>,
    raw_tx: mpsc::Sender<RawPrivateFrame>,
    mut private_fixtures: HashMap<usize, PrivateFixture>,
    mut expected_orders: HashMap<usize, ExpectedOrder>,
    metrics: Arc<PipelineMetrics>,
    expected_order_count: usize,
    cancel: Arc<AtomicBool>,
    hold_completion: bool,
    ready_tx: mpsc::UnboundedSender<()>,
    progress_tx: mpsc::UnboundedSender<BatchProgress>,
) -> Result<VenueSummary, String> {
    ready_tx
        .send(())
        .map_err(|_| format!("batch {batch} venue readiness receiver closed"))?;
    let mut orders = 0;
    let mut shutdowns = 0;
    while let Some(request) = StreamExt::next(&mut execution_rx).await {
        if cancel.load(Ordering::Acquire) {
            return Err(format!(
                "batch {batch} venue cancelled after {orders} orders"
            ));
        }
        match request {
            ExecutionRequest::Open(open) => {
                let order_ns = metrics.now_ns();
                metrics.record_in_flight();
                let sequence = parse_cid(open.key.cid.0.as_str())?;
                if metrics.task_by_sequence.get(sequence).copied() != Some(batch) {
                    metrics.mark_cross_batch_error();
                    return Err(format!(
                        "batch {batch} venue received cross-batch sequence {sequence}"
                    ));
                }
                metrics.mark_order(sequence, order_ns);
                let expected = expected_orders
                    .remove(&sequence)
                    .ok_or_else(|| format!("batch {batch} unexpected order {sequence}"))?;
                if let Err(error) = validate_open(&open, sequence, &expected) {
                    metrics.route_errors.fetch_add(1, Ordering::Relaxed);
                    return Err(error);
                }
                let fixture = private_fixtures.remove(&sequence).ok_or_else(|| {
                    format!("batch {batch} missing private fixture for sequence {sequence}")
                })?;
                match fixture {
                    PrivateFixture::Success { ack, fill } => {
                        raw_tx
                            .send(RawPrivateFrame { batch, frame: ack })
                            .await
                            .map_err(|_| {
                                format!("batch {batch} AccountOrder ingress closed before ACK")
                            })?;
                        raw_tx
                            .send(RawPrivateFrame { batch, frame: fill })
                            .await
                            .map_err(|_| {
                                format!("batch {batch} AccountOrder ingress closed before FILL")
                            })?;
                    }
                    PrivateFixture::Reject { reject } => {
                        raw_tx
                            .send(RawPrivateFrame {
                                batch,
                                frame: reject,
                            })
                            .await
                            .map_err(|_| {
                                format!("batch {batch} AccountOrder ingress closed before reject")
                            })?;
                    }
                }
                orders += 1;
                if orders == expected_order_count && !hold_completion {
                    progress_tx
                        .send(BatchProgress::VenueOrders(batch))
                        .map_err(|_| format!("batch {batch} progress receiver closed"))?;
                }
            }
            ExecutionRequest::Cancel(_) => {
                return Err(format!(
                    "batch {batch} strategy emitted an unexpected cancel request"
                ));
            }
            ExecutionRequest::Shutdown => {
                shutdowns += 1;
                break;
            }
        }
    }
    if orders != expected_order_count || !expected_orders.is_empty() || !private_fixtures.is_empty()
    {
        return Err(format!(
            "batch {batch} venue received {orders}/{expected_order_count} orders; remaining expected={} fixtures={}",
            expected_orders.len(),
            private_fixtures.len()
        ));
    }
    if shutdowns != 1 {
        return Err(format!(
            "batch {batch} venue received {shutdowns} shutdown requests"
        ));
    }
    Ok(VenueSummary { orders, shutdowns })
}

#[derive(Debug)]
pub struct RunResult {
    pub config: RunConfig,
    pub trade_producers: usize,
    pub engine_count: usize,
    pub signal_handlers: usize,
    pub trade_lanes_per_signal_handler: usize,
    pub account_broadcast_rings: usize,
    pub account_fanout_domains: usize,
    pub account_receivers_per_ring: usize,
    pub account_handlers_per_fanout_domain: usize,
    pub venue_handlers: usize,
    pub account_ingress_tasks: usize,
    pub account_owner_handlers: usize,
    pub runtime_tasks: usize,
    pub total_ticks: usize,
    pub expected_orders: usize,
    pub expected_rejects: usize,
    pub public_parsed: usize,
    pub public_cooperative_yields: usize,
    pub trade_callbacks: usize,
    pub signal_compute_calls: usize,
    pub order_endpoint_calls: usize,
    /// Compatibility alias for older result consumers; measured at order endpoint entry.
    pub orders_submitted: usize,
    pub private_frames_parsed: usize,
    pub acks: usize,
    pub fills: usize,
    pub account_callbacks: usize,
    pub private_fanout_callbacks: usize,
    pub expected_private_fanout_callbacks: usize,
    pub account_delivery_lost: usize,
    pub broadcast_lagged: usize,
    pub business_errors: usize,
    pub ending_in_flight: usize,
    pub max_in_flight: usize,
    pub drops: usize,
    pub duplicates: usize,
    pub route_errors: usize,
    pub cross_batch_errors: usize,
    pub missing: usize,
    pub wall_time_ns: u64,
    pub public_decode_ns: Vec<u64>,
    pub tick_to_order_ns: Vec<u64>,
    pub tick_to_ack_ns: Vec<u64>,
    pub tick_to_fill_ns: Vec<u64>,
    pub trade_lane_sent: Vec<usize>,
    pub task_sent: Vec<usize>,
    pub task_completed: Vec<usize>,
    pub task_completed_no_order: Vec<usize>,
    pub task_completed_terminal: Vec<usize>,
    pub signal_trade_by_handler: Vec<usize>,
    pub signal_private_by_handler: Vec<usize>,
    pub last_fill_from_phase_ns: u64,
    pub last_terminal_from_phase_ns: u64,
    pub last_trade_strategy_from_phase_ns: u64,
    pub last_no_order_completion_from_phase_ns: u64,
    pub last_private_fanout_from_phase_ns: u64,
    pub audited_events: usize,
}

pub async fn run_once(config: RunConfig) -> Result<RunResult, String> {
    run_once_inner(config, RunHooks::default()).await
}

#[cfg(test)]
#[derive(Debug, Copy, Clone)]
pub enum FailureInjection {
    PublicDecode,
    PrivateDecode,
    VenueCompletionTimeout,
}

#[cfg(test)]
pub async fn run_once_with_failure(
    config: RunConfig,
    injection: FailureInjection,
    failure_timeout: Duration,
) -> Result<RunResult, String> {
    let mut hooks = RunHooks {
        timeout: failure_timeout,
        ..RunHooks::default()
    };
    match injection {
        FailureInjection::PublicDecode => hooks.corrupt_public_frame = true,
        FailureInjection::PrivateDecode => hooks.corrupt_private_frame = true,
        FailureInjection::VenueCompletionTimeout => hooks.hold_venue_completion = true,
    }
    run_once_inner(config, hooks).await
}

async fn cleanup_failed_run(
    original_error: String,
    feed_tx: &UnboundedTx<EngineEvent<DataKind>>,
    go: &AtomicBool,
    cancel: &AtomicBool,
    producers: &mut tokio::task::JoinSet<Result<(usize, usize), String>>,
    engine_handle: &mut Option<tokio::task::JoinHandle<Result<EngineSummary, String>>>,
    venue_handle: &mut Option<tokio::task::JoinHandle<Result<VenueSummary, String>>>,
    ingress_handle: &mut Option<tokio::task::JoinHandle<Result<AccountIngressSummary, String>>>,
) -> String {
    cancel.store(true, Ordering::Release);
    go.store(true, Ordering::Release);
    producers.abort_all();
    if let Some(handle) = venue_handle.as_ref() {
        handle.abort();
    }
    if let Some(handle) = ingress_handle.as_ref() {
        handle.abort();
    }

    while producers.join_next().await.is_some() {}
    if let Some(handle) = venue_handle.take() {
        let _ = handle.await;
    }
    if let Some(handle) = ingress_handle.take() {
        let _ = handle.await;
    }

    let _ = feed_tx.send(EngineEvent::shutdown());
    let mut cleanup_errors = Vec::new();
    if let Some(handle) = engine_handle.take() {
        match handle.await {
            Ok(Ok(_)) => {}
            Ok(Err(error)) => cleanup_errors.push(format!("Engine cleanup failed: {error}")),
            Err(error) => cleanup_errors.push(format!("Engine cleanup task failed: {error}")),
        }
    }

    if cleanup_errors.is_empty() {
        original_error
    } else {
        format!("{original_error}; {}", cleanup_errors.join("; "))
    }
}

async fn run_once_inner(config: RunConfig, hooks: RunHooks) -> Result<RunResult, String> {
    match config.topology {
        LiveTopology::SharedHandler | LiveTopology::Ws5Strategy20 => {
            run_once_shared(config, hooks).await
        }
        LiveTopology::BatchSharded => run_once_batch_sharded(config, hooks).await,
    }
}

async fn run_once_shared(config: RunConfig, hooks: RunHooks) -> Result<RunResult, String> {
    let config = config.validate()?;
    let PreparedRun {
        instruments,
        mut producer_frames,
        transformers,
        mut private_fixtures,
        expected_orders,
        symbol_to_instrument,
        metrics,
        expected_order_count,
        expected_rejects,
    } = prepare_run(config).await?;
    if hooks.corrupt_public_frame {
        let fixture = producer_frames
            .first_mut()
            .and_then(|frames| frames.first_mut())
            .ok_or_else(|| "no public fixture available to corrupt".to_owned())?;
        fixture.frame = WsMessage::text("{");
    }
    if hooks.corrupt_private_frame {
        let fixture = private_fixtures
            .iter_mut()
            .flatten()
            .next()
            .ok_or_else(|| "no private fixture available to corrupt".to_owned())?;
        match fixture {
            PrivateFixture::Success { ack, .. } => *ack = WsMessage::text("{"),
            PrivateFixture::Reject { reject } => *reject = WsMessage::text("{"),
        }
    }
    let total_ticks = config.total_ticks()?;
    let expected_successes = expected_order_count - expected_rejects;
    let expected_private_frames = expected_successes * 2 + expected_rejects;
    let expected_account_callbacks = expected_successes * 3 + expected_rejects;
    let has_account_ingress = config.topology == LiveTopology::Ws5Strategy20;

    let (feed_tx, mut feed_rx) = mpsc_unbounded::<EngineEvent<DataKind>>();
    let (execution_tx, execution_rx) = mpsc_unbounded::<ExecutionRequest>();
    let engine = build_engine(
        &instruments,
        execution_tx,
        Arc::clone(&metrics),
        config,
        None,
    );
    let (ready_tx, mut ready_rx) = mpsc::unbounded_channel::<()>();
    let barrier = Arc::new(Barrier::new(config.tasks + 1));
    let go = Arc::new(AtomicBool::new(false));
    let cancel = Arc::new(AtomicBool::new(false));
    let (venue_done_tx, venue_done_rx) = oneshot::channel();
    let (raw_private_tx, raw_private_rx) = mpsc::channel(PRIVATE_INGRESS_CAPACITY);
    let venue_raw_private_tx = has_account_ingress.then_some(raw_private_tx);

    let engine_ready = ready_tx.clone();
    let mut engine_handle = Some(tokio::task::spawn_blocking(
        move || -> Result<EngineSummary, String> {
            engine_ready
                .send(())
                .map_err(|_| "engine readiness receiver closed".to_owned())?;
            let mut engine = engine;
            let _shutdown = sync_run(&mut feed_rx, &mut engine);
            let ending_in_flight = engine
                .state
                .instruments
                .orders(&InstrumentFilter::None)
                .map(|orders| orders.0.len())
                .sum();
            let audited_events = usize::try_from(engine.meta.sequence.value())
                .map_err(|_| "engine event sequence does not fit usize".to_owned())?;
            Ok(EngineSummary {
                ending_in_flight,
                audited_events,
            })
        },
    ));

    let mut ingress_handle = if has_account_ingress {
        Some(tokio::spawn(run_single_account_ingress(
            raw_private_rx,
            feed_tx.clone(),
            symbol_to_instrument.clone(),
            Arc::clone(&metrics),
            expected_private_frames,
            config.topology,
            Arc::clone(&cancel),
            ready_tx.clone(),
        )))
    } else {
        drop(raw_private_rx);
        None
    };

    let mut venue_handle = Some(tokio::spawn(run_venue(
        execution_rx,
        feed_tx.clone(),
        venue_raw_private_tx,
        private_fixtures,
        expected_orders,
        symbol_to_instrument,
        Arc::clone(&metrics),
        expected_order_count,
        config.topology,
        Arc::clone(&cancel),
        hooks.hold_venue_completion,
        ready_tx.clone(),
        venue_done_tx,
    )));
    let mut producers = tokio::task::JoinSet::new();
    for (task, (frames, transformer)) in producer_frames.into_iter().zip(transformers).enumerate() {
        producers.spawn(run_public_producer(
            task,
            frames,
            transformer,
            feed_tx.clone(),
            Arc::clone(&metrics),
            Arc::clone(&barrier),
            Arc::clone(&go),
            Arc::clone(&cancel),
            ready_tx.clone(),
        ));
    }
    drop(ready_tx);

    let supervised = async {
        timeout(hooks.timeout, async {
            for _ in 0..(config.tasks + 2 + usize::from(has_account_ingress)) {
                ready_rx
                    .recv()
                    .await
                    .ok_or_else(|| "readiness channel closed early".to_owned())?;
            }
            Ok::<(), String>(())
        })
        .await
        .map_err(|_| {
            format!(
                "live pipeline readiness timed out after {:?}",
                hooks.timeout
            )
        })??;

        timeout(hooks.timeout, barrier.wait())
            .await
            .map_err(|_| format!("producer barrier timed out after {:?}", hooks.timeout))?;
        let phase_start_ns = metrics.now_ns();
        go.store(true, Ordering::Release);

        let task_sent = timeout(hooks.timeout, async {
            let mut sent = vec![0; config.tasks];
            while let Some(joined) = producers.join_next().await {
                let (task, count) =
                    joined.map_err(|error| format!("producer task failed: {error}"))??;
                sent[task] = count;
            }
            Ok::<Vec<usize>, String>(sent)
        })
        .await
        .map_err(|_| format!("public producers timed out after {:?}", hooks.timeout))??;

        let venue_completion = timeout(hooks.timeout, venue_done_rx)
            .await
            .map_err(|_| format!("venue processing timed out after {:?}", hooks.timeout))?;
        match venue_completion {
            Ok(completion) => completion?,
            Err(_) => {
                let joined = {
                    let handle = venue_handle
                        .as_mut()
                        .ok_or_else(|| "venue completion sender dropped".to_owned())?;
                    timeout(hooks.timeout, handle).await.map_err(|_| {
                        format!("venue failed without a result after {:?}", hooks.timeout)
                    })?
                };
                let _ = venue_handle.take();
                return match joined {
                    Ok(Err(error)) => Err(format!("venue failed: {error}")),
                    Err(error) => Err(format!("venue task failed: {error}")),
                    Ok(Ok(_)) => Err("venue completion sender dropped".to_owned()),
                };
            }
        }

        let ingress_frames = if let Some(handle) = ingress_handle.as_mut() {
            let joined = timeout(hooks.timeout, handle)
                .await
                .map_err(|_| format!("AccountOrder ingress timed out after {:?}", hooks.timeout))?;
            let _ = ingress_handle.take();
            joined
                .map_err(|error| format!("AccountOrder ingress task failed: {error}"))??
                .frames
        } else {
            0
        };

        feed_tx
            .send(EngineEvent::shutdown())
            .map_err(|error| format!("failed to send Engine shutdown: {error:?}"))?;
        let engine_joined = {
            let handle = engine_handle
                .as_mut()
                .ok_or_else(|| "Engine task handle missing".to_owned())?;
            timeout(hooks.timeout, handle)
                .await
                .map_err(|_| format!("Engine shutdown timed out after {:?}", hooks.timeout))?
        };
        let _ = engine_handle.take();
        let engine = engine_joined.map_err(|error| format!("Engine task failed: {error}"))??;

        let venue_joined = {
            let handle = venue_handle
                .as_mut()
                .ok_or_else(|| "venue task handle missing".to_owned())?;
            timeout(hooks.timeout, handle)
                .await
                .map_err(|_| format!("venue shutdown timed out after {:?}", hooks.timeout))?
        };
        let _ = venue_handle.take();
        let venue = venue_joined.map_err(|error| format!("venue task failed: {error}"))??;

        Ok::<_, String>((phase_start_ns, task_sent, engine, venue, ingress_frames))
    }
    .await;

    let (phase_start_ns, task_sent, engine, venue, ingress_frames) = match supervised {
        Ok(output) => output,
        Err(error) => {
            return Err(cleanup_failed_run(
                error,
                &feed_tx,
                &go,
                &cancel,
                &mut producers,
                &mut engine_handle,
                &mut venue_handle,
                &mut ingress_handle,
            )
            .await);
        }
    };

    let public_parsed = metrics.public_parsed.load(Ordering::Acquire);
    let public_cooperative_yields = metrics.public_cooperative_yields.load(Ordering::Acquire);
    let trade_callbacks = metrics.trade_callbacks.load(Ordering::Acquire);
    let signal_trade_callbacks = metrics.signal_trade_callbacks.load(Ordering::Acquire);
    let signal_compute_calls = metrics.signal_compute_calls.load(Ordering::Acquire);
    let order_endpoint_calls = metrics.order_endpoint_calls.load(Ordering::Acquire);
    let private_frames_parsed = metrics.private_frames_parsed.load(Ordering::Acquire);
    let acks = metrics.acks.load(Ordering::Acquire);
    let fills = metrics.fills.load(Ordering::Acquire);
    let account_callbacks = metrics.account_callbacks.load(Ordering::Acquire);
    let private_fanout_callbacks = metrics.private_fanout_callbacks.load(Ordering::Acquire);
    let fanout_handlers = config.topology.account_receivers_per_batch();
    let expected_private_fanout_callbacks = expected_private_frames
        .checked_mul(fanout_handlers)
        .ok_or_else(|| "private fan-out callback count overflow".to_owned())?;
    let account_delivery_lost =
        expected_private_fanout_callbacks.saturating_sub(private_fanout_callbacks);
    let business_errors = metrics.business_errors.load(Ordering::Acquire);
    let drops = metrics.drops.load(Ordering::Acquire);
    let duplicates = metrics.duplicates.load(Ordering::Acquire);
    let route_errors = metrics.route_errors.load(Ordering::Acquire);
    let cross_batch_errors = metrics.cross_batch_errors.load(Ordering::Acquire);
    let current_in_flight = metrics.current_in_flight.load(Ordering::Acquire);
    let max_in_flight = metrics.max_in_flight.load(Ordering::Acquire);
    let task_completed = metrics
        .task_completed
        .iter()
        .map(|value| value.load(Ordering::Acquire))
        .collect::<Vec<_>>();
    let task_completed_no_order = metrics
        .task_completed_no_order
        .iter()
        .map(|value| value.load(Ordering::Acquire))
        .collect::<Vec<_>>();
    let task_completed_terminal = metrics
        .task_completed_terminal
        .iter()
        .map(|value| value.load(Ordering::Acquire))
        .collect::<Vec<_>>();
    let signal_trade_by_handler = metrics
        .signal_trade_by_handler
        .iter()
        .map(|value| value.load(Ordering::Acquire))
        .collect::<Vec<_>>();
    let signal_private_by_handler = metrics
        .signal_private_by_handler
        .iter()
        .map(|value| value.load(Ordering::Acquire))
        .collect::<Vec<_>>();

    let expected_private_mask = (1_u32 << u32::try_from(fanout_handlers).unwrap_or(0)) - 1;
    let mut missing = 0;
    let mut public_decode_ns = Vec::with_capacity(total_ticks);
    let mut tick_to_order_ns = Vec::with_capacity(expected_order_count);
    let mut tick_to_ack_ns = Vec::with_capacity(expected_successes);
    let mut tick_to_fill_ns = Vec::with_capacity(expected_successes);
    for sequence in 0..total_ticks {
        let t0 = metrics.t0[sequence].load(Ordering::Acquire);
        let t_public = metrics.t_public[sequence].load(Ordering::Acquire);
        if t0 == 0 || t_public < t0 || metrics.trade_seen[sequence].load(Ordering::Acquire) != 1 {
            missing += 1;
        } else {
            public_decode_ns.push(t_public - t0);
        }
        if metrics.completion_seen[sequence].load(Ordering::Acquire) != 1 {
            missing += 1;
        }
        if metrics.signal_trade_seen[sequence].load(Ordering::Acquire) != 1 {
            missing += 1;
        }
        if metrics.expects_order[sequence] {
            if metrics.private_primary_seen[sequence].load(Ordering::Acquire)
                != expected_private_mask
            {
                missing += 1;
            }
            let t_order = metrics.t_order[sequence].load(Ordering::Acquire);
            if t_order < t0
                || t_order == 0
                || metrics.terminal_seen[sequence].load(Ordering::Acquire) != 1
            {
                missing += 1;
            } else {
                tick_to_order_ns.push(t_order - t0);
            }
            if metrics.expects_reject[sequence] {
                if metrics.ack_seen[sequence].load(Ordering::Acquire) != 0
                    || metrics.fill_seen[sequence].load(Ordering::Acquire) != 0
                {
                    missing += 1;
                }
            } else {
                if metrics.private_secondary_seen[sequence].load(Ordering::Acquire)
                    != expected_private_mask
                {
                    missing += 1;
                }
                let t_ack = metrics.t_ack[sequence].load(Ordering::Acquire);
                let t_fill = metrics.t_fill[sequence].load(Ordering::Acquire);
                if t_ack < t0 || t_fill < t0 || t_ack == 0 || t_fill == 0 {
                    missing += 1;
                } else {
                    tick_to_ack_ns.push(t_ack - t0);
                    tick_to_fill_ns.push(t_fill - t0);
                }
            }
        }
    }
    let phase_offset = |name: &str, timestamp: u64| -> Result<u64, String> {
        if timestamp == 0 {
            return Ok(0);
        }
        timestamp
            .checked_sub(phase_start_ns)
            .ok_or_else(|| format!("invalid {name} timestamp"))
    };
    let last_fill_from_phase_ns =
        phase_offset("last fill", metrics.last_fill_ns.load(Ordering::Acquire))?;
    let last_terminal_from_phase_ns = phase_offset(
        "last terminal",
        metrics.last_terminal_ns.load(Ordering::Acquire),
    )?;
    let last_trade_strategy_from_phase_ns = phase_offset(
        "last trade strategy completion",
        metrics.last_trade_strategy_ns.load(Ordering::Acquire),
    )?;
    let last_no_order_completion_from_phase_ns = phase_offset(
        "last no-order completion",
        metrics.last_no_order_completion_ns.load(Ordering::Acquire),
    )?;
    let last_private_fanout_from_phase_ns = phase_offset(
        "last private fan-out",
        metrics.last_private_fanout_ns.load(Ordering::Acquire),
    )?;
    let wall_time_ns = phase_offset(
        "wall completion",
        metrics.last_completion_ns.load(Ordering::Acquire),
    )?;
    let expected_wall_time_ns = last_trade_strategy_from_phase_ns
        .max(last_terminal_from_phase_ns)
        .max(last_private_fanout_from_phase_ns);
    if wall_time_ns != expected_wall_time_ns {
        return Err(format!(
            "wall completion mismatch: wall={wall_time_ns} trade_strategy={last_trade_strategy_from_phase_ns} terminal={last_terminal_from_phase_ns} no_order={last_no_order_completion_from_phase_ns} private_fanout={last_private_fanout_from_phase_ns}"
        ));
    }
    let max_observed_latency_ns = public_decode_ns
        .iter()
        .chain(&tick_to_order_ns)
        .chain(&tick_to_ack_ns)
        .chain(&tick_to_fill_ns)
        .copied()
        .max()
        .unwrap_or(0);
    if wall_time_ns < max_observed_latency_ns {
        return Err(format!(
            "wall completion {wall_time_ns}ns precedes observed latency {max_observed_latency_ns}ns"
        ));
    }
    let ticks_per_task = config.ticks_per_task()?;
    let orders_per_task = (0..config.messages_per_instrument)
        .filter(|message_index| should_order(config.mode, config.order_every, *message_index))
        .count()
        * config.instruments_per_task;
    let no_order_ticks_per_task = ticks_per_task - orders_per_task;
    let handler_trade_expected = match config.topology {
        LiveTopology::SharedHandler => total_ticks,
        LiveTopology::Ws5Strategy20 => ticks_per_task,
        LiveTopology::BatchSharded => unreachable!("validated single-Engine topology"),
    };
    let handlers_conserve = signal_trade_by_handler.len() == fanout_handlers
        && signal_trade_by_handler
            .iter()
            .all(|count| *count == handler_trade_expected)
        && signal_private_by_handler.len() == fanout_handlers
        && signal_private_by_handler
            .iter()
            .all(|count| *count == expected_private_frames);
    let expected_ingress_frames = has_account_ingress
        .then_some(expected_private_frames)
        .unwrap_or(0);
    let conservation_ok = public_parsed == total_ticks
        && public_cooperative_yields == total_ticks
        && trade_callbacks == total_ticks
        && signal_trade_callbacks == total_ticks
        && signal_compute_calls == total_ticks
        && order_endpoint_calls == expected_order_count
        && venue.orders == expected_order_count
        && venue.shutdowns == 1
        && ingress_frames == expected_ingress_frames
        && private_frames_parsed == expected_private_frames
        && acks == expected_successes
        && fills == expected_successes
        && account_callbacks == expected_account_callbacks
        && private_fanout_callbacks == expected_private_fanout_callbacks
        && account_delivery_lost == 0
        && business_errors == expected_rejects
        && current_in_flight == 0
        && engine.ending_in_flight == 0
        && engine.audited_events == total_ticks + expected_account_callbacks + 1
        && task_sent.iter().all(|count| *count == ticks_per_task)
        && task_completed.iter().all(|count| *count == ticks_per_task)
        && task_completed_no_order
            .iter()
            .all(|count| *count == no_order_ticks_per_task)
        && task_completed_terminal
            .iter()
            .all(|count| *count == orders_per_task)
        && handlers_conserve
        && drops == 0
        && duplicates == 0
        && route_errors == 0
        && cross_batch_errors == 0
        && missing == 0;
    if !conservation_ok {
        return Err(format!(
            "conservation failure: ticks={total_ticks} public={public_parsed} yields={public_cooperative_yields} callbacks={trade_callbacks} signal_callbacks={signal_trade_callbacks} signal_compute_calls={signal_compute_calls} expected_orders={expected_order_count} endpoint_calls={order_endpoint_calls} private={private_frames_parsed}/{expected_private_frames} ingress={ingress_frames}/{expected_ingress_frames} private_fanout={private_fanout_callbacks}/{expected_private_fanout_callbacks} handlers={handlers_conserve} acks={acks}/{expected_successes} fills={fills}/{expected_successes} account_callbacks={account_callbacks}/{expected_account_callbacks} rejects={business_errors}/{expected_rejects} in_flight={current_in_flight}/{} audited={} drops={drops} duplicates={duplicates} route_errors={route_errors} cross_batch_errors={cross_batch_errors} missing={missing}",
            engine.ending_in_flight, engine.audited_events,
        ));
    }

    Ok(RunResult {
        config,
        trade_producers: config.tasks,
        engine_count: 1,
        signal_handlers: fanout_handlers,
        trade_lanes_per_signal_handler: match config.topology {
            LiveTopology::SharedHandler => config.tasks * config.instruments_per_task,
            LiveTopology::Ws5Strategy20 => 1,
            LiveTopology::BatchSharded => unreachable!("validated single-Engine topology"),
        },
        account_broadcast_rings: 0,
        account_fanout_domains: 1,
        account_receivers_per_ring: 0,
        account_handlers_per_fanout_domain: fanout_handlers,
        venue_handlers: 1,
        account_ingress_tasks: usize::from(has_account_ingress),
        account_owner_handlers: 1,
        runtime_tasks: config.tasks + 2 + usize::from(has_account_ingress),
        total_ticks,
        expected_orders: expected_order_count,
        expected_rejects,
        public_parsed,
        public_cooperative_yields,
        trade_callbacks,
        signal_compute_calls,
        order_endpoint_calls,
        orders_submitted: order_endpoint_calls,
        private_frames_parsed,
        acks,
        fills,
        account_callbacks,
        private_fanout_callbacks,
        expected_private_fanout_callbacks,
        account_delivery_lost,
        broadcast_lagged: 0,
        business_errors,
        ending_in_flight: engine.ending_in_flight,
        max_in_flight,
        drops,
        duplicates,
        route_errors,
        cross_batch_errors,
        missing,
        wall_time_ns,
        public_decode_ns,
        tick_to_order_ns,
        tick_to_ack_ns,
        tick_to_fill_ns,
        trade_lane_sent: task_sent.clone(),
        task_sent,
        task_completed,
        task_completed_no_order,
        task_completed_terminal,
        signal_trade_by_handler,
        signal_private_by_handler,
        last_fill_from_phase_ns,
        last_terminal_from_phase_ns,
        last_trade_strategy_from_phase_ns,
        last_no_order_completion_from_phase_ns,
        last_private_fanout_from_phase_ns,
        audited_events: engine.audited_events,
    })
}

#[allow(clippy::too_many_arguments)]
async fn cleanup_failed_batch_run(
    original_error: String,
    feed_txs: &[UnboundedTx<EngineEvent<DataKind>>],
    go: &AtomicBool,
    cancel: &AtomicBool,
    producers: &mut tokio::task::JoinSet<Result<(usize, usize, usize), String>>,
    engines: &mut tokio::task::JoinSet<Result<(usize, EngineSummary), String>>,
    venues: &mut tokio::task::JoinSet<Result<(usize, VenueSummary), String>>,
    ingresses: &mut tokio::task::JoinSet<Result<(usize, AccountIngressSummary), String>>,
) -> String {
    cancel.store(true, Ordering::Release);
    go.store(true, Ordering::Release);
    producers.abort_all();
    venues.abort_all();
    ingresses.abort_all();
    for feed_tx in feed_txs {
        let _ = feed_tx.send(EngineEvent::shutdown());
    }
    while producers.join_next().await.is_some() {}
    while venues.join_next().await.is_some() {}
    while ingresses.join_next().await.is_some() {}
    let mut cleanup_errors = Vec::new();
    while let Some(joined) = engines.join_next().await {
        match joined {
            Ok(Ok(_)) => {}
            Ok(Err(error)) => cleanup_errors.push(format!("Engine cleanup failed: {error}")),
            Err(error) => cleanup_errors.push(format!("Engine cleanup task failed: {error}")),
        }
    }
    if cleanup_errors.is_empty() {
        original_error
    } else {
        format!("{original_error}; {}", cleanup_errors.join("; "))
    }
}

async fn run_once_batch_sharded(config: RunConfig, hooks: RunHooks) -> Result<RunResult, String> {
    let config = config.validate()?;
    let PreparedBatchRun {
        mut batches,
        metrics,
        expected_order_count,
        expected_rejects,
        expected_private_frames,
    } = prepare_batch_sharded_run(config).await?;
    if hooks.corrupt_public_frame {
        let fixture = batches
            .first_mut()
            .and_then(|batch| batch.public_lanes.first_mut())
            .and_then(|lane| lane.frames.first_mut())
            .ok_or_else(|| "no batch public fixture available to corrupt".to_owned())?;
        fixture.frame = WsMessage::text("{");
    }
    if hooks.corrupt_private_frame {
        let fixture = batches
            .first_mut()
            .and_then(|batch| batch.private_fixtures.values_mut().next())
            .ok_or_else(|| "no batch private fixture available to corrupt".to_owned())?;
        match fixture {
            PrivateFixture::Success { ack, .. } => *ack = WsMessage::text("{"),
            PrivateFixture::Reject { reject } => *reject = WsMessage::text("{"),
        }
    }

    let total_ticks = config.total_ticks()?;
    let ticks_per_batch = config.ticks_per_task()?;
    let expected_successes = expected_order_count - expected_rejects;
    let expected_native_account_callbacks = expected_successes * 3 + expected_rejects;
    let expected_private_fanout_callbacks = expected_private_frames
        .checked_mul(SIGNAL_HANDLERS_PER_BATCH)
        .ok_or_else(|| "private fan-out callback count overflow".to_owned())?;
    let expected_private_by_batch = batches
        .iter()
        .map(|batch| batch.expected_private_frames)
        .collect::<Vec<_>>();
    let expected_account_by_batch = batches
        .iter()
        .map(|batch| {
            (batch.expected_order_count - batch.expected_rejects) * 3 + batch.expected_rejects
        })
        .collect::<Vec<_>>();

    let producer_count = config
        .tasks
        .checked_mul(BATCH_TRADE_LANES)
        .ok_or_else(|| "producer count overflow".to_owned())?;
    let ready_count = producer_count
        .checked_add(config.tasks * 3)
        .ok_or_else(|| "runtime readiness count overflow".to_owned())?;
    let (ready_tx, mut ready_rx) = mpsc::unbounded_channel::<()>();
    let (progress_tx, mut progress_rx) = mpsc::unbounded_channel::<BatchProgress>();
    let barrier = Arc::new(Barrier::new(producer_count + 1));
    let go = Arc::new(AtomicBool::new(false));
    let cancel = Arc::new(AtomicBool::new(false));
    let mut feed_txs = Vec::with_capacity(config.tasks);
    let mut producers = tokio::task::JoinSet::new();
    let mut engines = tokio::task::JoinSet::new();
    let mut venues = tokio::task::JoinSet::new();
    let mut ingresses = tokio::task::JoinSet::new();

    for prepared in batches {
        let PreparedBatch {
            batch,
            instruments,
            public_lanes,
            private_fixtures,
            expected_orders,
            symbol_to_instrument,
            expected_order_count: batch_expected_orders,
            expected_rejects: _,
            expected_private_frames: batch_expected_private_frames,
        } = prepared;
        let (feed_tx, mut feed_rx) = mpsc_unbounded::<EngineEvent<DataKind>>();
        let (execution_tx, execution_rx) = mpsc_unbounded::<ExecutionRequest>();
        let (raw_tx, raw_rx) = mpsc::channel(PRIVATE_INGRESS_CAPACITY);
        let engine = build_engine(
            &instruments,
            execution_tx,
            Arc::clone(&metrics),
            config,
            Some(batch),
        );
        feed_txs.push(feed_tx.clone());

        let engine_ready = ready_tx.clone();
        engines.spawn_blocking(move || -> Result<(usize, EngineSummary), String> {
            engine_ready
                .send(())
                .map_err(|_| format!("batch {batch} Engine readiness receiver closed"))?;
            let mut engine = engine;
            let _shutdown = sync_run(&mut feed_rx, &mut engine);
            let ending_in_flight = engine
                .state
                .instruments
                .orders(&InstrumentFilter::None)
                .map(|orders| orders.0.len())
                .sum();
            let audited_events = usize::try_from(engine.meta.sequence.value())
                .map_err(|_| "engine event sequence does not fit usize".to_owned())?;
            Ok((
                batch,
                EngineSummary {
                    ending_in_flight,
                    audited_events,
                },
            ))
        });

        let venue_progress = progress_tx.clone();
        let venue_error_progress = progress_tx.clone();
        let venue_ready = ready_tx.clone();
        let venue_metrics = Arc::clone(&metrics);
        let venue_cancel = Arc::clone(&cancel);
        venues.spawn(async move {
            let result = run_batch_venue(
                batch,
                execution_rx,
                raw_tx,
                private_fixtures,
                expected_orders,
                venue_metrics,
                batch_expected_orders,
                venue_cancel,
                hooks.hold_venue_completion,
                venue_ready,
                venue_progress,
            )
            .await;
            if let Err(error) = &result {
                let _ = venue_error_progress.send(BatchProgress::Failed {
                    role: "venue",
                    batch,
                    error: error.clone(),
                });
            }
            result.map(|summary| (batch, summary))
        });

        let ingress_progress = progress_tx.clone();
        let ingress_error_progress = progress_tx.clone();
        let ingress_ready = ready_tx.clone();
        let ingress_metrics = Arc::clone(&metrics);
        let ingress_cancel = Arc::clone(&cancel);
        let ingress_feed = feed_tx.clone();
        ingresses.spawn(async move {
            let result = run_batch_account_ingress(
                batch,
                raw_rx,
                ingress_feed,
                symbol_to_instrument,
                ingress_metrics,
                batch_expected_private_frames,
                ingress_cancel,
                ingress_ready,
                ingress_progress,
            )
            .await;
            if let Err(error) = &result {
                let _ = ingress_error_progress.send(BatchProgress::Failed {
                    role: "account_ingress",
                    batch,
                    error: error.clone(),
                });
            }
            result.map(|summary| (batch, summary))
        });

        for lane in public_lanes {
            producers.spawn(run_batch_public_lane(
                lane,
                feed_tx.clone(),
                Arc::clone(&metrics),
                Arc::clone(&barrier),
                Arc::clone(&go),
                Arc::clone(&cancel),
                ready_tx.clone(),
            ));
        }
    }
    drop(ready_tx);
    drop(progress_tx);

    let supervised = async {
        timeout(hooks.timeout, async {
            for _ in 0..ready_count {
                ready_rx
                    .recv()
                    .await
                    .ok_or_else(|| "batch runtime readiness channel closed early".to_owned())?;
            }
            Ok::<(), String>(())
        })
        .await
        .map_err(|_| {
            format!(
                "batch runtime readiness timed out after {:?}",
                hooks.timeout
            )
        })??;

        timeout(hooks.timeout, barrier.wait())
            .await
            .map_err(|_| format!("batch producer barrier timed out after {:?}", hooks.timeout))?;
        let phase_start_ns = metrics.now_ns();
        go.store(true, Ordering::Release);

        let (task_sent, trade_lane_sent) = timeout(hooks.timeout, async {
            let mut task_sent = vec![0; config.tasks];
            let mut lane_sent = vec![usize::MAX; producer_count];
            while let Some(joined) = producers.join_next().await {
                let (batch, lane, count) =
                    joined.map_err(|error| format!("public lane task failed: {error}"))??;
                let slot = batch * BATCH_TRADE_LANES + lane;
                let sent = lane_sent
                    .get_mut(slot)
                    .ok_or_else(|| format!("public lane result out of range: {batch}/{lane}"))?;
                if *sent != usize::MAX {
                    metrics.duplicates.fetch_add(1, Ordering::Relaxed);
                    return Err(format!("duplicate public lane result: {batch}/{lane}"));
                }
                *sent = count;
                task_sent[batch] += count;
            }
            if lane_sent.contains(&usize::MAX) {
                return Err("one or more public lane tasks returned no result".to_owned());
            }
            Ok::<_, String>((task_sent, lane_sent))
        })
        .await
        .map_err(|_| format!("batch public lanes timed out after {:?}", hooks.timeout))??;

        timeout(hooks.timeout, async {
            let mut venue_complete = vec![false; config.tasks];
            let mut ingress_complete = vec![false; config.tasks];
            let mut venues_done = 0;
            let mut ingresses_done = 0;
            while venues_done < config.tasks || ingresses_done < config.tasks {
                match progress_rx.recv().await {
                    Some(BatchProgress::VenueOrders(batch)) => {
                        let complete = venue_complete
                            .get_mut(batch)
                            .ok_or_else(|| format!("venue progress batch out of range: {batch}"))?;
                        if std::mem::replace(complete, true) {
                            metrics.duplicates.fetch_add(1, Ordering::Relaxed);
                            return Err(format!("duplicate venue completion for batch {batch}"));
                        }
                        venues_done += 1;
                    }
                    Some(BatchProgress::AccountIngress(batch)) => {
                        let complete = ingress_complete.get_mut(batch).ok_or_else(|| {
                            format!("account ingress progress batch out of range: {batch}")
                        })?;
                        if std::mem::replace(complete, true) {
                            metrics.duplicates.fetch_add(1, Ordering::Relaxed);
                            return Err(format!(
                                "duplicate account ingress completion for batch {batch}"
                            ));
                        }
                        ingresses_done += 1;
                    }
                    Some(BatchProgress::Failed { role, batch, error }) => {
                        return Err(format!("batch {batch} {role} failed: {error}"));
                    }
                    None => return Err("batch progress channel closed early".to_owned()),
                }
            }
            Ok::<(), String>(())
        })
        .await
        .map_err(|_| format!("batch processing timed out after {:?}", hooks.timeout))??;

        for (batch, feed_tx) in feed_txs.iter().enumerate() {
            feed_tx.send(EngineEvent::shutdown()).map_err(|error| {
                format!("failed sending batch {batch} Engine shutdown: {error:?}")
            })?;
        }

        let engine_summaries = timeout(hooks.timeout, async {
            let mut summaries = (0..config.tasks).map(|_| None).collect::<Vec<_>>();
            while let Some(joined) = engines.join_next().await {
                let (batch, summary) =
                    joined.map_err(|error| format!("Engine task failed: {error}"))??;
                let target = summaries
                    .get_mut(batch)
                    .ok_or_else(|| format!("Engine summary batch out of range: {batch}"))?;
                if target.replace(summary).is_some() {
                    return Err(format!("duplicate Engine summary for batch {batch}"));
                }
            }
            summaries
                .into_iter()
                .enumerate()
                .map(|(batch, summary)| {
                    summary.ok_or_else(|| format!("missing Engine summary for batch {batch}"))
                })
                .collect::<Result<Vec<_>, _>>()
        })
        .await
        .map_err(|_| format!("batch Engines timed out after {:?}", hooks.timeout))??;

        let venue_summaries = timeout(hooks.timeout, async {
            let mut summaries = (0..config.tasks).map(|_| None).collect::<Vec<_>>();
            while let Some(joined) = venues.join_next().await {
                let (batch, summary) =
                    joined.map_err(|error| format!("venue task failed: {error}"))??;
                let target = summaries
                    .get_mut(batch)
                    .ok_or_else(|| format!("venue summary batch out of range: {batch}"))?;
                if target.replace(summary).is_some() {
                    return Err(format!("duplicate venue summary for batch {batch}"));
                }
            }
            summaries
                .into_iter()
                .enumerate()
                .map(|(batch, summary)| {
                    summary.ok_or_else(|| format!("missing venue summary for batch {batch}"))
                })
                .collect::<Result<Vec<_>, _>>()
        })
        .await
        .map_err(|_| format!("batch venues timed out after {:?}", hooks.timeout))??;

        let ingress_summaries = timeout(hooks.timeout, async {
            let mut summaries = (0..config.tasks).map(|_| None).collect::<Vec<_>>();
            while let Some(joined) = ingresses.join_next().await {
                let (batch, summary) =
                    joined.map_err(|error| format!("account ingress task failed: {error}"))??;
                let target = summaries.get_mut(batch).ok_or_else(|| {
                    format!("account ingress summary batch out of range: {batch}")
                })?;
                if target.replace(summary).is_some() {
                    return Err(format!(
                        "duplicate account ingress summary for batch {batch}"
                    ));
                }
            }
            summaries
                .into_iter()
                .enumerate()
                .map(|(batch, summary)| {
                    summary
                        .ok_or_else(|| format!("missing account ingress summary for batch {batch}"))
                })
                .collect::<Result<Vec<_>, _>>()
        })
        .await
        .map_err(|_| {
            format!(
                "batch account ingresses timed out after {:?}",
                hooks.timeout
            )
        })??;

        Ok::<_, String>((
            phase_start_ns,
            task_sent,
            trade_lane_sent,
            engine_summaries,
            venue_summaries,
            ingress_summaries,
        ))
    }
    .await;

    let (
        phase_start_ns,
        task_sent,
        trade_lane_sent,
        engine_summaries,
        venue_summaries,
        ingress_summaries,
    ) = match supervised {
        Ok(output) => output,
        Err(error) => {
            return Err(cleanup_failed_batch_run(
                error,
                &feed_txs,
                &go,
                &cancel,
                &mut producers,
                &mut engines,
                &mut venues,
                &mut ingresses,
            )
            .await);
        }
    };

    let public_parsed = metrics.public_parsed.load(Ordering::Acquire);
    let public_cooperative_yields = metrics.public_cooperative_yields.load(Ordering::Acquire);
    let trade_callbacks = metrics.trade_callbacks.load(Ordering::Acquire);
    let signal_trade_callbacks = metrics.signal_trade_callbacks.load(Ordering::Acquire);
    let signal_compute_calls = metrics.signal_compute_calls.load(Ordering::Acquire);
    let order_endpoint_calls = metrics.order_endpoint_calls.load(Ordering::Acquire);
    let private_frames_parsed = metrics.private_frames_parsed.load(Ordering::Acquire);
    let private_fanout_callbacks = metrics.private_fanout_callbacks.load(Ordering::Acquire);
    let account_delivery_lost =
        expected_private_fanout_callbacks.saturating_sub(private_fanout_callbacks);
    let acks = metrics.acks.load(Ordering::Acquire);
    let fills = metrics.fills.load(Ordering::Acquire);
    let account_callbacks = metrics.account_callbacks.load(Ordering::Acquire);
    let business_errors = metrics.business_errors.load(Ordering::Acquire);
    let drops = metrics.drops.load(Ordering::Acquire);
    let duplicates = metrics.duplicates.load(Ordering::Acquire);
    let route_errors = metrics.route_errors.load(Ordering::Acquire);
    let cross_batch_errors = metrics.cross_batch_errors.load(Ordering::Acquire);
    let current_in_flight = metrics.current_in_flight.load(Ordering::Acquire);
    let max_in_flight = metrics.max_in_flight.load(Ordering::Acquire);
    let task_completed = metrics
        .task_completed
        .iter()
        .map(|value| value.load(Ordering::Acquire))
        .collect::<Vec<_>>();
    let task_completed_no_order = metrics
        .task_completed_no_order
        .iter()
        .map(|value| value.load(Ordering::Acquire))
        .collect::<Vec<_>>();
    let task_completed_terminal = metrics
        .task_completed_terminal
        .iter()
        .map(|value| value.load(Ordering::Acquire))
        .collect::<Vec<_>>();
    let signal_trade_by_handler = metrics
        .signal_trade_by_handler
        .iter()
        .map(|value| value.load(Ordering::Acquire))
        .collect::<Vec<_>>();
    let signal_private_by_handler = metrics
        .signal_private_by_handler
        .iter()
        .map(|value| value.load(Ordering::Acquire))
        .collect::<Vec<_>>();

    let expected_private_mask =
        (1_u32 << u32::try_from(SIGNAL_HANDLERS_PER_BATCH).unwrap_or(0)) - 1;
    let mut missing = 0;
    let mut public_decode_ns = Vec::with_capacity(total_ticks);
    let mut tick_to_order_ns = Vec::with_capacity(expected_order_count);
    let mut tick_to_ack_ns = Vec::with_capacity(expected_successes);
    let mut tick_to_fill_ns = Vec::with_capacity(expected_successes);
    for sequence in 0..total_ticks {
        let t0 = metrics.t0[sequence].load(Ordering::Acquire);
        let t_public = metrics.t_public[sequence].load(Ordering::Acquire);
        if t0 == 0 || t_public < t0 || metrics.trade_seen[sequence].load(Ordering::Acquire) != 1 {
            missing += 1;
        } else {
            public_decode_ns.push(t_public - t0);
        }
        if metrics.signal_trade_seen[sequence].load(Ordering::Acquire) != 1
            || metrics.completion_seen[sequence].load(Ordering::Acquire) != 1
        {
            missing += 1;
        }
        if metrics.expects_order[sequence] {
            if metrics.private_primary_seen[sequence].load(Ordering::Acquire)
                != expected_private_mask
            {
                missing += 1;
            }
            let t_order = metrics.t_order[sequence].load(Ordering::Acquire);
            if t_order < t0
                || t_order == 0
                || metrics.terminal_seen[sequence].load(Ordering::Acquire) != 1
            {
                missing += 1;
            } else {
                tick_to_order_ns.push(t_order - t0);
            }
            if metrics.expects_reject[sequence] {
                if metrics.private_secondary_seen[sequence].load(Ordering::Acquire) != 0
                    || metrics.ack_seen[sequence].load(Ordering::Acquire) != 0
                    || metrics.fill_seen[sequence].load(Ordering::Acquire) != 0
                {
                    missing += 1;
                }
            } else {
                if metrics.private_secondary_seen[sequence].load(Ordering::Acquire)
                    != expected_private_mask
                {
                    missing += 1;
                }
                let t_ack = metrics.t_ack[sequence].load(Ordering::Acquire);
                let t_fill = metrics.t_fill[sequence].load(Ordering::Acquire);
                if t_ack < t0 || t_fill < t0 || t_ack == 0 || t_fill == 0 {
                    missing += 1;
                } else {
                    tick_to_ack_ns.push(t_ack - t0);
                    tick_to_fill_ns.push(t_fill - t0);
                }
            }
        } else if metrics.private_primary_seen[sequence].load(Ordering::Acquire) != 0
            || metrics.private_secondary_seen[sequence].load(Ordering::Acquire) != 0
        {
            missing += 1;
        }
    }

    let phase_offset = |name: &str, timestamp: u64| -> Result<u64, String> {
        if timestamp == 0 {
            return Ok(0);
        }
        timestamp
            .checked_sub(phase_start_ns)
            .ok_or_else(|| format!("invalid {name} timestamp"))
    };
    let last_fill_from_phase_ns =
        phase_offset("last fill", metrics.last_fill_ns.load(Ordering::Acquire))?;
    let last_terminal_from_phase_ns = phase_offset(
        "last terminal",
        metrics.last_terminal_ns.load(Ordering::Acquire),
    )?;
    let last_trade_strategy_from_phase_ns = phase_offset(
        "last trade strategy completion",
        metrics.last_trade_strategy_ns.load(Ordering::Acquire),
    )?;
    let last_no_order_completion_from_phase_ns = phase_offset(
        "last no-order completion",
        metrics.last_no_order_completion_ns.load(Ordering::Acquire),
    )?;
    let last_private_fanout_from_phase_ns = phase_offset(
        "last private fan-out",
        metrics.last_private_fanout_ns.load(Ordering::Acquire),
    )?;
    let wall_time_ns = phase_offset(
        "wall completion",
        metrics.last_completion_ns.load(Ordering::Acquire),
    )?;
    let expected_wall_time_ns = last_trade_strategy_from_phase_ns
        .max(last_terminal_from_phase_ns)
        .max(last_private_fanout_from_phase_ns);
    if wall_time_ns != expected_wall_time_ns {
        return Err(format!(
            "wall completion mismatch: wall={wall_time_ns} trade_strategy={last_trade_strategy_from_phase_ns} terminal={last_terminal_from_phase_ns} no_order={last_no_order_completion_from_phase_ns} private_fanout={last_private_fanout_from_phase_ns}"
        ));
    }
    let max_observed_latency_ns = public_decode_ns
        .iter()
        .chain(&tick_to_order_ns)
        .chain(&tick_to_ack_ns)
        .chain(&tick_to_fill_ns)
        .copied()
        .max()
        .unwrap_or(0);
    if wall_time_ns < max_observed_latency_ns {
        return Err(format!(
            "wall completion {wall_time_ns}ns precedes observed latency {max_observed_latency_ns}ns"
        ));
    }

    let orders_per_batch = (0..config.messages_per_instrument)
        .filter(|message_index| should_order(config.mode, config.order_every, *message_index))
        .count()
        * BATCH_TRADE_LANES;
    let no_order_ticks_per_batch = ticks_per_batch - orders_per_batch;
    let ending_in_flight = engine_summaries
        .iter()
        .map(|summary| summary.ending_in_flight)
        .sum();
    let audited_events = engine_summaries
        .iter()
        .map(|summary| summary.audited_events)
        .sum();
    let venue_orders = venue_summaries
        .iter()
        .map(|summary| summary.orders)
        .sum::<usize>();
    let venue_shutdowns = venue_summaries
        .iter()
        .map(|summary| summary.shutdowns)
        .sum::<usize>();
    let ingress_frames = ingress_summaries
        .iter()
        .map(|summary| summary.frames)
        .sum::<usize>();
    let handler_ticks_expected = TRADE_LANES_PER_SIGNAL_HANDLER * config.messages_per_instrument;
    let handlers_conserve = signal_trade_by_handler
        .iter()
        .all(|count| *count == handler_ticks_expected)
        && signal_private_by_handler
            .chunks_exact(SIGNAL_HANDLERS_PER_BATCH)
            .zip(&expected_private_by_batch)
            .all(|(counts, expected)| counts.iter().all(|count| count == expected));
    let engine_batches_conserve = engine_summaries.iter().enumerate().all(|(batch, summary)| {
        summary.audited_events == ticks_per_batch + expected_account_by_batch[batch] + 1
            && summary.ending_in_flight == 0
    });
    let conservation_ok = public_parsed == total_ticks
        && public_cooperative_yields == total_ticks
        && trade_callbacks == total_ticks
        && signal_trade_callbacks == total_ticks
        && signal_compute_calls == total_ticks
        && order_endpoint_calls == expected_order_count
        && venue_orders == expected_order_count
        && venue_shutdowns == config.tasks
        && ingress_frames == expected_private_frames
        && private_frames_parsed == expected_private_frames
        && private_fanout_callbacks == expected_private_fanout_callbacks
        && account_delivery_lost == 0
        && acks == expected_successes
        && fills == expected_successes
        && account_callbacks == expected_native_account_callbacks
        && business_errors == expected_rejects
        && current_in_flight == 0
        && ending_in_flight == 0
        && audited_events == total_ticks + expected_native_account_callbacks + config.tasks
        && engine_batches_conserve
        && trade_lane_sent
            .iter()
            .all(|count| *count == config.messages_per_instrument)
        && task_sent.iter().all(|count| *count == ticks_per_batch)
        && task_completed.iter().all(|count| *count == ticks_per_batch)
        && task_completed_no_order
            .iter()
            .all(|count| *count == no_order_ticks_per_batch)
        && task_completed_terminal
            .iter()
            .all(|count| *count == orders_per_batch)
        && handlers_conserve
        && drops == 0
        && duplicates == 0
        && route_errors == 0
        && cross_batch_errors == 0
        && missing == 0;
    if !conservation_ok {
        return Err(format!(
            "batch conservation failure: ticks={total_ticks} public={public_parsed} yields={public_cooperative_yields} callbacks={trade_callbacks} signal_callbacks={signal_trade_callbacks} signal_compute_calls={signal_compute_calls} orders={order_endpoint_calls}/{expected_order_count} venue={venue_orders} private={private_frames_parsed}/{expected_private_frames} ingress={ingress_frames} private_fanout={private_fanout_callbacks}/{expected_private_fanout_callbacks} acks={acks}/{expected_successes} fills={fills}/{expected_successes} native_account={account_callbacks}/{expected_native_account_callbacks} rejects={business_errors}/{expected_rejects} in_flight={current_in_flight}/{ending_in_flight} audited={audited_events} handler_conservation={handlers_conserve} drops={drops} duplicates={duplicates} route_errors={route_errors} cross_batch_errors={cross_batch_errors} missing={missing}"
        ));
    }

    Ok(RunResult {
        config,
        trade_producers: producer_count,
        engine_count: config.tasks,
        signal_handlers: config.tasks * SIGNAL_HANDLERS_PER_BATCH,
        trade_lanes_per_signal_handler: TRADE_LANES_PER_SIGNAL_HANDLER,
        account_broadcast_rings: 0,
        account_fanout_domains: config.tasks,
        account_receivers_per_ring: 0,
        account_handlers_per_fanout_domain: SIGNAL_HANDLERS_PER_BATCH,
        venue_handlers: config.tasks,
        account_ingress_tasks: config.tasks,
        account_owner_handlers: config.tasks,
        runtime_tasks: config.tasks * (BATCH_TRADE_LANES + 3),
        total_ticks,
        expected_orders: expected_order_count,
        expected_rejects,
        public_parsed,
        public_cooperative_yields,
        trade_callbacks,
        signal_compute_calls,
        order_endpoint_calls,
        orders_submitted: order_endpoint_calls,
        private_frames_parsed,
        acks,
        fills,
        account_callbacks,
        private_fanout_callbacks,
        expected_private_fanout_callbacks,
        account_delivery_lost,
        broadcast_lagged: 0,
        business_errors,
        ending_in_flight,
        max_in_flight,
        drops,
        duplicates,
        route_errors,
        cross_batch_errors,
        missing,
        wall_time_ns,
        public_decode_ns,
        tick_to_order_ns,
        tick_to_ack_ns,
        tick_to_fill_ns,
        trade_lane_sent,
        task_sent,
        task_completed,
        task_completed_no_order,
        task_completed_terminal,
        signal_trade_by_handler,
        signal_private_by_handler,
        last_fill_from_phase_ns,
        last_terminal_from_phase_ns,
        last_trade_strategy_from_phase_ns,
        last_no_order_completion_from_phase_ns,
        last_private_fanout_from_phase_ns,
        audited_events,
    })
}

#[derive(Debug, Serialize)]
struct LatencyReport {
    samples: usize,
    p50_ns: u64,
    p95_ns: u64,
    p99_ns: u64,
    max_ns: u64,
}

impl LatencyReport {
    fn from_samples(samples: &[u64]) -> Self {
        let mut sorted = samples.to_vec();
        sorted.sort_unstable();
        Self {
            samples: sorted.len(),
            p50_ns: percentile(&sorted, 50),
            p95_ns: percentile(&sorted, 95),
            p99_ns: percentile(&sorted, 99),
            max_ns: sorted.last().copied().unwrap_or(0),
        }
    }
}

#[derive(Debug, Serialize)]
struct LivePipelineReport {
    framework: &'static str,
    run: usize,
    topology: &'static str,
    mode: LiveMode,
    scenario: LiveScenario,
    tasks: usize,
    instruments_per_task: usize,
    messages_per_instrument: usize,
    order_every: usize,
    signal_compute_ns: u64,
    reject_every: usize,
    total_instruments: usize,
    producer_tasks: usize,
    public_ws_tasks: usize,
    public_ws_tasks_per_fanout_domain: usize,
    symbols_per_public_ws: usize,
    symbols_per_signal_handler: usize,
    trade_task_keys: usize,
    trade_lanes: usize,
    trade_ingress_lanes: usize,
    trade_subscriptions: usize,
    engine_count: usize,
    signal_handlers: usize,
    trade_lanes_per_signal_handler: usize,
    account_ingress_tasks: usize,
    account_ingress_lanes: usize,
    private_ingress_capacity: usize,
    account_broadcast_rings: usize,
    account_broadcast_topics: usize,
    account_fanout_domains: usize,
    account_receivers_per_ring: usize,
    account_handlers_per_fanout_domain: usize,
    account_owner_handlers: usize,
    venue_handlers: usize,
    order_runners: usize,
    runtime_tasks: usize,
    total_ticks: usize,
    expected_orders: usize,
    expected_successful_orders: usize,
    expected_business_errors: usize,
    public_parsed: usize,
    public_cooperative_yields: usize,
    trade_callbacks: usize,
    signal_compute_calls: usize,
    order_endpoint_calls: usize,
    orders_submitted: usize,
    private_frames_parsed: usize,
    acks: usize,
    fills: usize,
    account_callbacks: usize,
    expected_account_callbacks: usize,
    account_observation_callbacks: usize,
    native_owner_callbacks: usize,
    account_non_owner_callbacks: usize,
    account_delivery_lost: usize,
    broadcast_lagged: usize,
    broadcast_lag_observable: bool,
    drops: usize,
    duplicates: usize,
    route_errors: usize,
    cross_batch_errors: usize,
    business_errors: usize,
    missing: usize,
    ending_in_flight: usize,
    max_in_flight: usize,
    runtime_worker_threads: usize,
    trade_lane_sent_min: usize,
    trade_lane_sent_max: usize,
    signal_trade_callbacks_min: usize,
    signal_trade_callbacks_max: usize,
    signal_private_callbacks_min: usize,
    signal_private_callbacks_max: usize,
    task_sent_min: usize,
    task_sent_max: usize,
    task_completed_min: usize,
    task_completed_max: usize,
    task_completed_no_order_min: usize,
    task_completed_no_order_max: usize,
    task_completed_terminal_min: usize,
    task_completed_terminal_max: usize,
    wall_time_ns: u64,
    last_fill_from_phase_ns: u64,
    last_terminal_from_phase_ns: u64,
    last_trade_strategy_from_phase_ns: u64,
    last_no_order_completion_from_phase_ns: u64,
    last_private_fanout_from_phase_ns: u64,
    wall_throughput_ticks_s: f64,
    public_decode: LatencyReport,
    tick_to_order: LatencyReport,
    tick_to_ack: LatencyReport,
    tick_to_fill: LatencyReport,
    audited_engine_events: usize,
    public_path: &'static str,
    private_path: &'static str,
    private_bridge: bool,
    signal_handler_model: &'static str,
    handler_kind: &'static str,
    batch_isolation_model: &'static str,
    private_fanout_model: &'static str,
    account_owner_selection_model: &'static str,
    public_ingress_model: &'static str,
    private_ingress_model: &'static str,
    overflow_model: &'static str,
    included: &'static str,
    excluded: &'static str,
}

impl LivePipelineReport {
    fn new(run: usize, result: &RunResult) -> Self {
        let min = |values: &[usize]| values.iter().copied().min().unwrap_or(0);
        let max = |values: &[usize]| values.iter().copied().max().unwrap_or(0);
        let native_owner_callbacks = match result.config.topology {
            LiveTopology::SharedHandler | LiveTopology::Ws5Strategy20 => result
                .signal_private_by_handler
                .first()
                .copied()
                .unwrap_or(0),
            LiveTopology::BatchSharded => result
                .signal_private_by_handler
                .chunks_exact(SIGNAL_HANDLERS_PER_BATCH)
                .map(|handlers| handlers[0])
                .sum(),
        };
        let account_non_owner_callbacks = result
            .private_fanout_callbacks
            .saturating_sub(native_owner_callbacks);
        let total_instruments = result.config.tasks * result.config.instruments_per_task;
        let (trade_lanes, symbols_per_public_ws, symbols_per_signal_handler) = match result
            .config
            .topology
        {
            LiveTopology::SharedHandler => (
                total_instruments,
                result.config.instruments_per_task,
                total_instruments,
            ),
            LiveTopology::BatchSharded => (total_instruments, 1, TRADE_LANES_PER_SIGNAL_HANDLER),
            LiveTopology::Ws5Strategy20 => (
                WS5_PUBLIC_WS_TASKS,
                WS5_SYMBOLS_PER_PUBLIC_WS,
                WS5_SYMBOLS_PER_PUBLIC_WS,
            ),
        };
        let public_ws_tasks_per_fanout_domain = result
            .trade_producers
            .checked_div(result.account_fanout_domains)
            .unwrap_or(0);
        Self {
            framework: "barter-rs",
            run,
            topology: result.config.topology.name(),
            mode: result.config.mode,
            scenario: result.config.scenario,
            tasks: result.config.tasks,
            instruments_per_task: result.config.instruments_per_task,
            messages_per_instrument: result.config.messages_per_instrument,
            order_every: result.config.order_every,
            signal_compute_ns: result.config.signal_compute_ns,
            reject_every: result.config.reject_every,
            total_instruments,
            producer_tasks: result.trade_producers,
            public_ws_tasks: result.trade_producers,
            public_ws_tasks_per_fanout_domain,
            symbols_per_public_ws,
            symbols_per_signal_handler,
            trade_task_keys: 0,
            trade_lanes,
            trade_ingress_lanes: trade_lanes,
            trade_subscriptions: total_instruments,
            engine_count: result.engine_count,
            signal_handlers: result.signal_handlers,
            trade_lanes_per_signal_handler: result.trade_lanes_per_signal_handler,
            account_ingress_tasks: result.account_ingress_tasks,
            account_ingress_lanes: result.account_ingress_tasks,
            private_ingress_capacity: match result.config.topology {
                LiveTopology::SharedHandler => 0,
                LiveTopology::BatchSharded | LiveTopology::Ws5Strategy20 => {
                    PRIVATE_INGRESS_CAPACITY
                }
            },
            account_broadcast_rings: result.account_broadcast_rings,
            account_broadcast_topics: 0,
            account_fanout_domains: result.account_fanout_domains,
            account_receivers_per_ring: result.account_receivers_per_ring,
            account_handlers_per_fanout_domain: result.account_handlers_per_fanout_domain,
            account_owner_handlers: result.account_owner_handlers,
            venue_handlers: result.venue_handlers,
            order_runners: 0,
            runtime_tasks: result.runtime_tasks,
            total_ticks: result.total_ticks,
            expected_orders: result.expected_orders,
            expected_successful_orders: result.expected_orders - result.expected_rejects,
            expected_business_errors: result.expected_rejects,
            public_parsed: result.public_parsed,
            public_cooperative_yields: result.public_cooperative_yields,
            trade_callbacks: result.trade_callbacks,
            signal_compute_calls: result.signal_compute_calls,
            order_endpoint_calls: result.order_endpoint_calls,
            orders_submitted: result.orders_submitted,
            private_frames_parsed: result.private_frames_parsed,
            acks: result.acks,
            fills: result.fills,
            account_callbacks: result.account_callbacks,
            expected_account_callbacks: result.expected_private_fanout_callbacks,
            account_observation_callbacks: result.private_fanout_callbacks,
            native_owner_callbacks,
            account_non_owner_callbacks,
            account_delivery_lost: result.account_delivery_lost,
            broadcast_lagged: result.broadcast_lagged,
            broadcast_lag_observable: false,
            drops: result.drops,
            duplicates: result.duplicates,
            route_errors: result.route_errors,
            cross_batch_errors: result.cross_batch_errors,
            business_errors: result.business_errors,
            missing: result.missing,
            ending_in_flight: result.ending_in_flight,
            max_in_flight: result.max_in_flight,
            runtime_worker_threads: RUNTIME_WORKER_THREADS,
            trade_lane_sent_min: min(&result.trade_lane_sent),
            trade_lane_sent_max: max(&result.trade_lane_sent),
            signal_trade_callbacks_min: min(&result.signal_trade_by_handler),
            signal_trade_callbacks_max: max(&result.signal_trade_by_handler),
            signal_private_callbacks_min: min(&result.signal_private_by_handler),
            signal_private_callbacks_max: max(&result.signal_private_by_handler),
            task_sent_min: min(&result.task_sent),
            task_sent_max: max(&result.task_sent),
            task_completed_min: min(&result.task_completed),
            task_completed_max: max(&result.task_completed),
            task_completed_no_order_min: min(&result.task_completed_no_order),
            task_completed_no_order_max: max(&result.task_completed_no_order),
            task_completed_terminal_min: min(&result.task_completed_terminal),
            task_completed_terminal_max: max(&result.task_completed_terminal),
            wall_time_ns: result.wall_time_ns,
            last_fill_from_phase_ns: result.last_fill_from_phase_ns,
            last_terminal_from_phase_ns: result.last_terminal_from_phase_ns,
            last_trade_strategy_from_phase_ns: result.last_trade_strategy_from_phase_ns,
            last_no_order_completion_from_phase_ns: result.last_no_order_completion_from_phase_ns,
            last_private_fanout_from_phase_ns: result.last_private_fanout_from_phase_ns,
            wall_throughput_ticks_s: result.total_ticks as f64
                / (result.wall_time_ns as f64 / 1_000_000_000.0),
            public_decode: LatencyReport::from_samples(&result.public_decode_ns),
            tick_to_order: LatencyReport::from_samples(&result.tick_to_order_ns),
            tick_to_ack: LatencyReport::from_samples(&result.tick_to_ack_ns),
            tick_to_fill: LatencyReport::from_samples(&result.tick_to_fill_ns),
            audited_engine_events: result.audited_events,
            public_path: "production WebSocketSerdeParser<BinanceTrade> + StatelessTransformer<BinanceSpot>",
            private_path: "benchmark Binance executionReport DTO + production generic WebSocketSerdeParser -> native AccountEvent",
            private_bridge: true,
            signal_handler_model: match result.config.topology {
                LiveTopology::SharedHandler => "one native Barter Strategy",
                LiveTopology::BatchSharded => {
                    "one Barter composite Strategy per Engine with five logical handlers"
                }
                LiveTopology::Ws5Strategy20 => {
                    "one native Barter Strategy in one Engine with twenty synchronous logical handlers"
                }
            },
            handler_kind: match result.config.topology {
                LiveTopology::SharedHandler => "native_single_strategy",
                LiveTopology::BatchSharded | LiveTopology::Ws5Strategy20 => {
                    "composite_logical_handlers"
                }
            },
            batch_isolation_model: match result.config.topology {
                LiveTopology::SharedHandler => "all producer groups share one Engine and venue",
                LiveTopology::BatchSharded => {
                    "one independent sync Engine, feed, venue, and private ingress per batch"
                }
                LiveTopology::Ws5Strategy20 => {
                    "twenty public WS groups share one sync Engine, feed, venue, and private ingress"
                }
            },
            private_fanout_model: match result.config.topology {
                LiveTopology::SharedHandler => {
                    "single observation inside one native AlgoStrategy callback"
                }
                LiveTopology::BatchSharded => {
                    "synchronous composite fanout inside one native AlgoStrategy callback"
                }
                LiveTopology::Ws5Strategy20 => {
                    "synchronous twenty-way composite fanout inside one native AlgoStrategy callback"
                }
            },
            account_owner_selection_model: match result.config.topology {
                LiveTopology::SharedHandler => {
                    "single native Strategy owns account state and observation"
                }
                LiveTopology::BatchSharded => {
                    "single composite Strategy is native owner; logical handler 0 is the canonical observation counter"
                }
                LiveTopology::Ws5Strategy20 => {
                    "single composite Strategy owns account state; logical handler 0 is canonical and nineteen handlers observe"
                }
            },
            public_ingress_model: match result.config.topology {
                LiveTopology::SharedHandler => {
                    "one cooperative Tokio task per multiplexed public producer group"
                }
                LiveTopology::BatchSharded => {
                    "one cooperative Tokio task and production transformer per Trade WS lane"
                }
                LiveTopology::Ws5Strategy20 => {
                    "twenty cooperative Tokio tasks; one production transformer per five-symbol public WS"
                }
            },
            private_ingress_model: match result.config.topology {
                LiveTopology::SharedHandler => "venue-inline private frame decode",
                LiveTopology::BatchSharded => {
                    "one bounded raw AccountOrder WS ingress task per batch using send().await backpressure"
                }
                LiveTopology::Ws5Strategy20 => {
                    "one bounded raw AccountOrder WS ingress task using send().await backpressure"
                }
            },
            overflow_model: match result.config.topology {
                LiveTopology::SharedHandler => {
                    "unbounded public/Engine feed; no broadcast ring or broadcast-lag category"
                }
                LiveTopology::BatchSharded => {
                    "unbounded public/Engine feed; bounded raw private mpsc uses send().await backpressure; no broadcast-lag category"
                }
                LiveTopology::Ws5Strategy20 => {
                    "unbounded public/Engine feed; one bounded raw private mpsc uses send().await backpressure; no broadcast-lag category"
                }
            },
            included: "raw public decode/normalize, concurrent routing, configured CPU-bound signal compute, Engine strategy+risk, ExecutionRequest::Open, in-memory venue, raw private decode bridge, native ACK/FILL/terminal callbacks",
            excluded: "TLS, socket IO, kernel networking, real exchange latency, sleeps, reconnect/backoff",
        }
    }
}

pub fn percentile(sorted: &[u64], percentile: usize) -> u64 {
    if sorted.is_empty() {
        return 0;
    }
    let rank = (percentile * sorted.len()).div_ceil(100);
    sorted[rank.saturating_sub(1)]
}

pub fn parse_positive_usize(name: &str, value: &str) -> Result<usize, String> {
    let parsed = value
        .parse::<usize>()
        .map_err(|error| format!("invalid {name}={value}: {error}"))?;
    if parsed == 0 {
        return Err(format!("{name} must be greater than zero"));
    }
    Ok(parsed)
}

pub fn parse_non_negative_u64(name: &str, value: &str) -> Result<u64, String> {
    value
        .parse::<u64>()
        .map_err(|error| format!("invalid {name}={value}: {error}"))
}

pub fn parse_mode(value: &str) -> Result<LiveMode, String> {
    match value {
        "stress" => Ok(LiveMode::Stress),
        "mixed_live" => Ok(LiveMode::MixedLive),
        other => Err(format!(
            "LIVE_MODE must be stress or mixed_live, got {other}"
        )),
    }
}

pub fn parse_scenario(value: &str) -> Result<LiveScenario, String> {
    match value {
        "success" => Ok(LiveScenario::Success),
        "business_error" => Ok(LiveScenario::BusinessError),
        other => Err(format!(
            "LIVE_SCENARIO must be success or business_error, got {other}"
        )),
    }
}

pub fn parse_topology(value: &str) -> Result<LiveTopology, String> {
    match value {
        "shared_handler" => Ok(LiveTopology::SharedHandler),
        "batch_sharded" => Ok(LiveTopology::BatchSharded),
        "ws5_strategy20" => Ok(LiveTopology::Ws5Strategy20),
        other => Err(format!(
            "LIVE_TOPOLOGY must be shared_handler, batch_sharded, or ws5_strategy20, got {other}"
        )),
    }
}

fn env_usize(name: &str, default: usize) -> Result<usize, String> {
    match env::var(name) {
        Ok(value) => parse_positive_usize(name, &value),
        Err(env::VarError::NotPresent) => Ok(default),
        Err(error) => Err(format!("failed reading {name}: {error}")),
    }
}

fn env_u64(name: &str, default: u64) -> Result<u64, String> {
    match env::var(name) {
        Ok(value) => parse_non_negative_u64(name, &value),
        Err(env::VarError::NotPresent) => Ok(default),
        Err(error) => Err(format!("failed reading {name}: {error}")),
    }
}

fn config_from_env() -> Result<(RunConfig, usize, usize), String> {
    let mode = parse_mode(&env::var("LIVE_MODE").unwrap_or_else(|_| "stress".to_owned()))?;
    let scenario =
        parse_scenario(&env::var("LIVE_SCENARIO").unwrap_or_else(|_| "success".to_owned()))?;
    let topology =
        parse_topology(&env::var("LIVE_TOPOLOGY").unwrap_or_else(|_| "shared_handler".to_owned()))?;
    let config = RunConfig {
        tasks: env_usize("LIVE_TASKS", DEFAULT_TASKS)?,
        instruments_per_task: env_usize("LIVE_INSTRUMENTS_PER_TASK", DEFAULT_INSTRUMENTS_PER_TASK)?,
        messages_per_instrument: env_usize(
            "LIVE_MESSAGES_PER_INSTRUMENT",
            DEFAULT_MESSAGES_PER_INSTRUMENT,
        )?,
        mode,
        order_every: env_usize("LIVE_ORDER_EVERY", DEFAULT_ORDER_EVERY)?,
        signal_compute_ns: env_u64("LIVE_SIGNAL_COMPUTE_NS", DEFAULT_SIGNAL_COMPUTE_NS)?,
        reject_every: env_usize("LIVE_REJECT_EVERY", DEFAULT_REJECT_EVERY)?,
        scenario,
        topology,
    }
    .validate()?;
    Ok((
        config,
        env_usize("LIVE_WARMUP_RUNS", DEFAULT_WARMUP_RUNS)?,
        env_usize("LIVE_MEASURED_RUNS", DEFAULT_MEASURED_RUNS)?,
    ))
}

fn main() {
    let (config, warmup_runs, measured_runs) = config_from_env()
        .unwrap_or_else(|error| panic!("invalid live pipeline configuration: {error}"));
    let runtime = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(RUNTIME_WORKER_THREADS)
        .enable_all()
        .build()
        .expect("build live pipeline Tokio runtime");
    runtime.block_on(async {
        for _ in 0..warmup_runs {
            run_once(config)
                .await
                .expect("warmup live pipeline run failed");
        }
        for run in 1..=measured_runs {
            let result = run_once(config)
                .await
                .expect("measured live pipeline run failed");
            let json = serde_json::to_string(&LivePipelineReport::new(run, &result))
                .expect("serialize live pipeline report");
            println!("LIVE_PIPELINE_RESULT {json}");
        }
    });
}

#[cfg(test)]
mod report_tests {
    #[allow(unused_imports)]
    use super::*;

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn batch_report_exposes_physical_and_logical_topology_separately() {
        let result = run_once(RunConfig {
            tasks: 1,
            instruments_per_task: BATCH_TRADE_LANES,
            messages_per_instrument: 1,
            mode: LiveMode::Stress,
            order_every: 1,
            signal_compute_ns: 0,
            reject_every: 10,
            scenario: LiveScenario::Success,
            topology: LiveTopology::BatchSharded,
        })
        .await
        .expect("run batch report fixture");
        let report = serde_json::to_value(LivePipelineReport::new(1, &result))
            .expect("serialize batch report");

        assert_eq!(report["topology"], "batch_sharded");
        assert_eq!(report["producer_tasks"], 20);
        assert_eq!(report["trade_task_keys"], 0);
        assert_eq!(report["trade_ingress_lanes"], 20);
        assert_eq!(report["trade_subscriptions"], 20);
        assert_eq!(report["engine_count"], 1);
        assert_eq!(report["signal_handlers"], 5);
        assert_eq!(report["trade_lanes_per_signal_handler"], 4);
        assert_eq!(report["account_ingress_tasks"], 1);
        assert_eq!(report["account_ingress_lanes"], 1);
        assert_eq!(report["private_ingress_capacity"], 8_192);
        assert_eq!(report["account_broadcast_rings"], 0);
        assert_eq!(report["account_broadcast_topics"], 0);
        assert_eq!(report["account_receivers_per_ring"], 0);
        assert_eq!(report["account_fanout_domains"], 1);
        assert_eq!(report["account_handlers_per_fanout_domain"], 5);
        assert_eq!(report["account_observation_callbacks"], 200);
        assert_eq!(report["native_owner_callbacks"], 40);
        assert_eq!(report["account_non_owner_callbacks"], 160);
        assert_eq!(report["public_cooperative_yields"], 20);
        assert_eq!(report["cross_batch_errors"], 0);
        assert_eq!(report["broadcast_lag_observable"], false);
        assert_eq!(report["handler_kind"], "composite_logical_handlers");
        assert_eq!(
            report["private_fanout_model"],
            "synchronous composite fanout inside one native AlgoStrategy callback"
        );
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 8)]
    async fn ws5_strategy20_report_exposes_single_engine_synchronous_composite() {
        let result = run_once(RunConfig {
            tasks: WS5_PUBLIC_WS_TASKS,
            instruments_per_task: WS5_SYMBOLS_PER_PUBLIC_WS,
            messages_per_instrument: 1,
            mode: LiveMode::Stress,
            order_every: 1,
            signal_compute_ns: 1_000,
            reject_every: 10,
            scenario: LiveScenario::Success,
            topology: LiveTopology::Ws5Strategy20,
        })
        .await
        .expect("run ws5_strategy20 report fixture");
        let report = serde_json::to_value(LivePipelineReport::new(1, &result))
            .expect("serialize ws5_strategy20 report");

        assert_eq!(report["topology"], "ws5_strategy20");
        assert_eq!(report["producer_tasks"], 20);
        assert_eq!(report["public_ws_tasks"], 20);
        assert_eq!(report["public_ws_tasks_per_fanout_domain"], 20);
        assert_eq!(report["symbols_per_public_ws"], 5);
        assert_eq!(report["symbols_per_signal_handler"], 5);
        assert_eq!(report["signal_compute_ns"], 1_000);
        assert_eq!(report["signal_compute_calls"], 100);
        assert_eq!(report["trade_lanes"], 20);
        assert_eq!(report["trade_ingress_lanes"], 20);
        assert_eq!(report["trade_subscriptions"], 100);
        assert_eq!(report["engine_count"], 1);
        assert_eq!(report["signal_handlers"], 20);
        assert_eq!(report["trade_lanes_per_signal_handler"], 1);
        assert_eq!(report["account_ingress_tasks"], 1);
        assert_eq!(report["account_ingress_lanes"], 1);
        assert_eq!(report["private_ingress_capacity"], 8_192);
        assert_eq!(report["account_fanout_domains"], 1);
        assert_eq!(report["account_handlers_per_fanout_domain"], 20);
        assert_eq!(report["account_observation_callbacks"], 4_000);
        assert_eq!(report["native_owner_callbacks"], 200);
        assert_eq!(report["account_non_owner_callbacks"], 3_800);
        assert_eq!(report["runtime_tasks"], 23);
        assert_eq!(report["handler_kind"], "composite_logical_handlers");
        assert_eq!(
            report["signal_handler_model"],
            "one native Barter Strategy in one Engine with twenty synchronous logical handlers"
        );
        assert_eq!(
            report["private_fanout_model"],
            "synchronous twenty-way composite fanout inside one native AlgoStrategy callback"
        );
        assert_eq!(
            report["public_ingress_model"],
            "twenty cooperative Tokio tasks; one production transformer per five-symbol public WS"
        );
        assert_eq!(
            report["private_ingress_model"],
            "one bounded raw AccountOrder WS ingress task using send().await backpressure"
        );
    }
}
