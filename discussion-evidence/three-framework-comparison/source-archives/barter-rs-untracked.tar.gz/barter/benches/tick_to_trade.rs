use barter::{
    EngineEvent,
    engine::{
        Engine, Processor,
        clock::LiveClock,
        execution_tx::MultiExchangeTxMap,
        run::sync_run,
        state::{
            EngineState,
            global::DefaultGlobalData,
            instrument::{data::InstrumentDataState, filter::InstrumentFilter},
            order::in_flight_recorder::InFlightRequestRecorder,
            trading::TradingState,
        },
    },
    execution::request::ExecutionRequest,
    risk::DefaultRiskManager,
    strategy::{
        algo::AlgoStrategy, close_positions::ClosePositionsStrategy,
        on_disconnect::OnDisconnectStrategy, on_trading_disabled::OnTradingDisabled,
    },
};
use barter_data::{
    event::{DataKind, MarketEvent},
    streams::consumer::MarketStreamEvent,
    subscription::trade::PublicTrade,
};
use barter_execution::{
    AccountEvent,
    order::{
        OrderKey, OrderKind, TimeInForce,
        id::{ClientOrderId, StrategyId},
        request::{OrderRequestCancel, OrderRequestOpen, RequestOpen},
    },
};
use barter_instrument::{
    Side, Underlying,
    asset::AssetIndex,
    exchange::{ExchangeId, ExchangeIndex},
    index::IndexedInstruments,
    instrument::{Instrument, InstrumentIndex},
};
use barter_integration::channel::{Tx, UnboundedRx, UnboundedTx, mpsc_unbounded};
use futures::StreamExt;
use rust_decimal::{Decimal, prelude::FromPrimitive};
use serde::Serialize;
use std::{
    env,
    fs::File,
    io::{BufRead, BufReader},
    path::PathBuf,
    sync::{
        Arc,
        atomic::{AtomicBool, AtomicU8, AtomicU64, Ordering},
    },
    time::{Duration, Instant},
};
use tokio::{
    sync::{Barrier, mpsc},
    task::JoinSet,
    time::{Instant as TokioInstant, timeout, timeout_at},
};

const DEFAULT_MESSAGES_PER_TASK: usize = 4096;
const DEFAULT_WARMUP_RUNS: usize = 1;
const DEFAULT_MEASURED_RUNS: usize = 5;
const DEFAULT_SATURATED_PRODUCERS: usize = 16;
const RUNTIME_WORKER_THREADS: usize = 16;
const RUN_TIMEOUT: Duration = Duration::from_secs(30);
const CLEANUP_TIMEOUT: Duration = Duration::from_secs(2);
const CID_PREFIX: &str = "t2t-";
const STRATEGY_ID: &str = "tick-to-trade";
const MARKET_DATA_FILE: &str = "examples/data/binance_spot_trades_l1_btcusdt_ethusdt_solusdt.json";

type TickEvent = EngineEvent<DataKind>;
type TickState = EngineState<DefaultGlobalData, TickInstrumentData>;
type TickRisk = DefaultRiskManager<TickState>;
type TickExecutionTxs = MultiExchangeTxMap<UnboundedTx<ExecutionRequest>>;
type TickEngine = Engine<LiveClock, TickState, TickExecutionTxs, TickStrategy, TickRisk>;
type SequencedTickEvent = (usize, TickEvent);
type EventsByProducer = Vec<Vec<SequencedTickEvent>>;

#[derive(Debug, Copy, Clone, Eq, PartialEq)]
pub enum Scenario {
    Unloaded,
    Saturated,
}

impl Scenario {
    fn producers(self, saturated_producers: usize) -> usize {
        match self {
            Self::Unloaded => 1,
            Self::Saturated => saturated_producers,
        }
    }

    fn name(self, producers: usize, messages_per_task: usize) -> String {
        match self {
            Self::Unloaded => format!("unloaded_1x{messages_per_task}"),
            Self::Saturated => format!("saturated_{producers}x{messages_per_task}"),
        }
    }

    pub fn queue_inclusive(self) -> bool {
        matches!(self, Self::Saturated)
    }
}

#[derive(Debug)]
pub struct RunResult {
    pub producers: usize,
    pub messages_per_task: usize,
    pub sent: usize,
    pub engine_callbacks: usize,
    pub orders: usize,
    pub in_flight_orders: usize,
    pub shutdowns: usize,
    pub phase_start_ns: u64,
    pub earliest_send_ns: u64,
    pub wall_time_ns: u64,
    pub latencies_ns: Vec<u64>,
    pub strict_one_in_flight: bool,
    sequence_order: Vec<usize>,
}

impl RunResult {
    pub fn sequences_sorted(&self) -> Vec<usize> {
        let mut sequences = self.sequence_order.clone();
        sequences.sort_unstable();
        sequences
    }
}

#[derive(Debug, Serialize)]
struct T2tReport {
    repo: &'static str,
    scenario: String,
    run: usize,
    producers: usize,
    messages_per_task: usize,
    events: usize,
    sent: usize,
    engine_callbacks: usize,
    orders: usize,
    in_flight_orders: usize,
    latencies: usize,
    losses: usize,
    duplicates: usize,
    routing_errors: usize,
    runtime_worker_threads: usize,
    runtime_topology_note: &'static str,
    wall_time_ns: u64,
    throughput_events_per_sec: f64,
    orders_per_sec: f64,
    p50_ns: u64,
    p95_ns: u64,
    p99_ns: u64,
    max_ns: u64,
    queue_inclusive: bool,
    source: &'static str,
    endpoint: &'static str,
}

impl T2tReport {
    fn new(scenario: Scenario, run: usize, result: &RunResult) -> Self {
        let mut latencies_ns = result.latencies_ns.clone();
        latencies_ns.sort_unstable();

        let events = result.producers * result.messages_per_task;
        let elapsed_seconds = result.wall_time_ns as f64 / 1_000_000_000.0;

        Self {
            repo: "barter-rs",
            scenario: scenario.name(result.producers, result.messages_per_task),
            run,
            producers: result.producers,
            messages_per_task: result.messages_per_task,
            events,
            sent: result.sent,
            engine_callbacks: result.engine_callbacks,
            orders: result.orders,
            in_flight_orders: result.in_flight_orders,
            latencies: result.latencies_ns.len(),
            losses: 0,
            duplicates: 0,
            routing_errors: 0,
            runtime_worker_threads: RUNTIME_WORKER_THREADS,
            runtime_topology_note: "runtime_worker_threads excludes one blocking engine thread; producers are async tasks",
            wall_time_ns: result.wall_time_ns,
            throughput_events_per_sec: events as f64 / elapsed_seconds,
            orders_per_sec: result.orders as f64 / elapsed_seconds,
            p50_ns: nearest_rank_percentile(&latencies_ns, 50),
            p95_ns: nearest_rank_percentile(&latencies_ns, 95),
            p99_ns: nearest_rank_percentile(&latencies_ns, 99),
            max_ns: *latencies_ns.last().expect("run contains latency samples"),
            queue_inclusive: scenario.queue_inclusive(),
            source: "normalised Binance BTCUSDT public trades",
            endpoint: "ExecutionRequest::Open dequeued",
        }
    }
}

#[derive(Debug, Clone, Default)]
struct TickInstrumentData {
    last_trade: Option<PublicTrade>,
    market_callbacks: usize,
}

impl InstrumentDataState for TickInstrumentData {
    type MarketEventKind = DataKind;

    fn price(&self) -> Option<Decimal> {
        self.last_trade
            .as_ref()
            .and_then(|trade| Decimal::from_f64(trade.price))
    }
}

impl Processor<&MarketEvent<InstrumentIndex>> for TickInstrumentData {
    type Audit = ();

    fn process(&mut self, event: &MarketEvent<InstrumentIndex>) -> Self::Audit {
        self.market_callbacks += 1;
        self.last_trade = match &event.kind {
            DataKind::Trade(trade) => Some(trade.clone()),
            _ => None,
        };
    }
}

impl Processor<&AccountEvent> for TickInstrumentData {
    type Audit = ();

    fn process(&mut self, _: &AccountEvent) -> Self::Audit {}
}

impl InFlightRequestRecorder for TickInstrumentData {
    fn record_in_flight_cancel(&mut self, _: &OrderRequestCancel) {}

    fn record_in_flight_open(&mut self, _: &OrderRequestOpen) {}
}

#[derive(Debug, Clone)]
struct TickStrategy {
    id: StrategyId,
}

impl Default for TickStrategy {
    fn default() -> Self {
        Self {
            id: StrategyId::new(STRATEGY_ID),
        }
    }
}

impl AlgoStrategy for TickStrategy {
    type State = TickState;

    fn generate_algo_orders(
        &self,
        state: &Self::State,
    ) -> (
        impl IntoIterator<Item = OrderRequestCancel>,
        impl IntoIterator<Item = OrderRequestOpen>,
    ) {
        let open = state
            .instruments
            .instrument_index(&InstrumentIndex(0))
            .data
            .last_trade
            .as_ref()
            .map(|trade| OrderRequestOpen {
                key: OrderKey {
                    exchange: ExchangeIndex(0),
                    instrument: InstrumentIndex(0),
                    strategy: self.id.clone(),
                    cid: ClientOrderId::new(trade.id.as_str()),
                },
                state: RequestOpen {
                    side: Side::Buy,
                    price: Decimal::from_f64(trade.price).expect("fixture trade price is finite"),
                    quantity: Decimal::from_f64(trade.amount)
                        .expect("fixture trade amount is finite"),
                    kind: OrderKind::Market,
                    time_in_force: TimeInForce::ImmediateOrCancel,
                },
            });

        (std::iter::empty(), open)
    }
}

impl ClosePositionsStrategy for TickStrategy {
    type State = TickState;

    fn close_positions_requests<'a>(
        &'a self,
        _: &'a Self::State,
        _: &'a InstrumentFilter,
    ) -> (
        impl IntoIterator<Item = OrderRequestCancel> + 'a,
        impl IntoIterator<Item = OrderRequestOpen> + 'a,
    )
    where
        ExchangeIndex: 'a,
        AssetIndex: 'a,
        InstrumentIndex: 'a,
    {
        (std::iter::empty(), std::iter::empty())
    }
}

impl OnDisconnectStrategy<LiveClock, TickState, TickExecutionTxs, TickRisk> for TickStrategy {
    type OnDisconnect = ();

    fn on_disconnect(_: &mut TickEngine, _: ExchangeId) -> Self::OnDisconnect {}
}

impl OnTradingDisabled<LiveClock, TickState, TickExecutionTxs, TickRisk> for TickStrategy {
    type OnTradingDisabled = ();

    fn on_trading_disabled(_: &mut TickEngine) -> Self::OnTradingDisabled {}
}

#[derive(Debug, Clone, Copy)]
struct ExpectedOrder {
    price: Decimal,
    quantity: Decimal,
}

#[derive(Debug)]
struct Timings {
    origin: Instant,
    starts_ns: Vec<AtomicU64>,
    ends_ns: Vec<AtomicU64>,
    seen: Vec<AtomicU8>,
}

impl Timings {
    fn new(events: usize) -> Self {
        Self {
            origin: Instant::now(),
            starts_ns: (0..events).map(|_| AtomicU64::new(0)).collect(),
            ends_ns: (0..events).map(|_| AtomicU64::new(0)).collect(),
            seen: (0..events).map(|_| AtomicU8::new(0)).collect(),
        }
    }

    fn now_ns(&self) -> u64 {
        u64::try_from(self.origin.elapsed().as_nanos())
            .unwrap_or(u64::MAX - 1)
            .saturating_add(1)
    }
}

#[derive(Debug)]
struct ReceiverSummary {
    orders: usize,
    shutdowns: usize,
    last_open_ns: u64,
    sequence_order: Vec<usize>,
}

#[derive(Debug)]
struct EngineSummary {
    callbacks: usize,
    in_flight_orders: usize,
    audited_events: usize,
}

#[derive(Debug)]
enum TaskOutcome {
    Producer { sent: usize },
    Engine(EngineSummary),
    Receiver(ReceiverSummary),
}

pub async fn abort_and_drain_with_timeout<T: Send + 'static>(
    tasks: &mut JoinSet<T>,
    cleanup_timeout: Duration,
) -> Result<(), String> {
    tasks.abort_all();
    timeout(cleanup_timeout, async {
        while let Some(joined) = tasks.join_next().await {
            if let Err(error) = joined
                && !error.is_cancelled()
            {
                return Err(format!("cleanup task failed: {error}"));
            }
        }
        Ok(())
    })
    .await
    .map_err(|_| format!("cleanup timed out after {cleanup_timeout:?}"))?
}

async fn cleanup_after_error(
    tasks: &mut JoinSet<Result<TaskOutcome, String>>,
    cancel: &AtomicBool,
    go: &AtomicBool,
    feed_tx: &UnboundedTx<TickEvent>,
    shutdown_sent: bool,
    original_error: String,
) -> String {
    cancel.store(true, Ordering::Release);
    go.store(true, Ordering::Release);

    let shutdown_error = if shutdown_sent {
        None
    } else {
        feed_tx
            .send(EngineEvent::shutdown())
            .err()
            .map(|error| format!("feed shutdown failed: {error:?}"))
    };
    let cleanup_error = abort_and_drain_with_timeout(tasks, CLEANUP_TIMEOUT)
        .await
        .err();

    [Some(original_error), shutdown_error, cleanup_error]
        .into_iter()
        .flatten()
        .collect::<Vec<_>>()
        .join("; ")
}

pub fn load_real_ticks() -> Result<Vec<MarketStreamEvent<InstrumentIndex, DataKind>>, String> {
    let path = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(MARKET_DATA_FILE);
    let file =
        File::open(&path).map_err(|error| format!("failed to open {}: {error}", path.display()))?;
    let mut ticks = Vec::new();

    for (line_index, line) in BufReader::new(file).lines().enumerate() {
        let line = line.map_err(|error| {
            format!(
                "failed reading {} line {}: {error}",
                path.display(),
                line_index + 1
            )
        })?;
        let event: MarketStreamEvent<InstrumentIndex, DataKind> = serde_json::from_str(&line)
            .map_err(|error| {
                format!(
                    "failed parsing {} line {}: {error}",
                    path.display(),
                    line_index + 1
                )
            })?;

        if matches!(
            &event,
            MarketStreamEvent::Item(MarketEvent {
                instrument: InstrumentIndex(0),
                kind: DataKind::Trade(_),
                ..
            })
        ) {
            ticks.push(event);
        }
    }

    if ticks.is_empty() {
        return Err(format!(
            "{} contains no BTCUSDT trade events",
            path.display()
        ));
    }

    Ok(ticks)
}

pub fn nearest_rank_percentile(sorted: &[u64], percentile: usize) -> u64 {
    assert!(!sorted.is_empty(), "percentile input must not be empty");
    assert!(
        (1..=100).contains(&percentile),
        "percentile must be between 1 and 100"
    );

    let rank = (percentile * sorted.len()).div_ceil(100);
    sorted[rank - 1]
}

pub async fn run_once(
    scenario: Scenario,
    source_ticks: &[MarketStreamEvent<InstrumentIndex, DataKind>],
    messages_per_task: usize,
) -> Result<RunResult, String> {
    run_once_with_producers(
        scenario,
        source_ticks,
        messages_per_task,
        DEFAULT_SATURATED_PRODUCERS,
    )
    .await
}

pub async fn run_once_with_producers(
    scenario: Scenario,
    source_ticks: &[MarketStreamEvent<InstrumentIndex, DataKind>],
    messages_per_task: usize,
    saturated_producers: usize,
) -> Result<RunResult, String> {
    if source_ticks.is_empty() {
        return Err("source tick collection must not be empty".to_owned());
    }
    if messages_per_task == 0 {
        return Err("messages per task must be greater than zero".to_owned());
    }
    validate_producer_count(saturated_producers)?;

    let producers = scenario.producers(saturated_producers);
    let total_events = producers
        .checked_mul(messages_per_task)
        .ok_or_else(|| "event count overflow".to_owned())?;
    let (events_by_producer, expected_orders) =
        prepare_events(source_ticks, producers, messages_per_task)?;
    let expected_orders = Arc::new(expected_orders);
    let timings = Arc::new(Timings::new(total_events));
    let barrier = Arc::new(Barrier::new(producers + 1));
    let go = Arc::new(AtomicBool::new(false));
    let cancel = Arc::new(AtomicBool::new(false));

    let (feed_tx, mut feed_rx) = mpsc_unbounded::<TickEvent>();
    let (execution_tx, execution_rx) = mpsc_unbounded::<ExecutionRequest>();
    let engine = build_engine(execution_tx, total_events);
    let (execution_ack, mut producer_ack) = match scenario {
        Scenario::Unloaded => {
            let (ack_tx, ack_rx) = mpsc::unbounded_channel::<usize>();
            (Some(ack_tx), Some(ack_rx))
        }
        Scenario::Saturated => (None, None),
    };
    let (ready_tx, mut ready_rx) = mpsc::unbounded_channel::<()>();

    let mut tasks = JoinSet::<Result<TaskOutcome, String>>::new();
    let engine_ready = ready_tx.clone();
    tasks.spawn_blocking(move || {
        let mut engine = engine;
        engine_ready
            .send(())
            .map_err(|_| "failed to report engine readiness".to_owned())?;
        let _shutdown = sync_run(&mut feed_rx, &mut engine);
        let instrument = engine
            .state
            .instruments
            .instrument_index(&InstrumentIndex(0));
        let audited_events = usize::try_from(engine.meta.sequence.value())
            .map_err(|_| "engine event sequence does not fit usize".to_owned())?;

        Ok(TaskOutcome::Engine(EngineSummary {
            callbacks: instrument.data.market_callbacks,
            in_flight_orders: instrument.orders.0.len(),
            audited_events,
        }))
    });

    let receiver_timings = Arc::clone(&timings);
    let receiver_ready = ready_tx.clone();
    tasks.spawn(async move {
        receive_execution_requests(
            execution_rx,
            receiver_timings,
            expected_orders,
            execution_ack,
            receiver_ready,
        )
        .await
        .map(TaskOutcome::Receiver)
    });

    for events in events_by_producer {
        let producer_feed = feed_tx.clone();
        let producer_timings = Arc::clone(&timings);
        let producer_barrier = Arc::clone(&barrier);
        let producer_go = Arc::clone(&go);
        let producer_cancel = Arc::clone(&cancel);
        let producer_ready = ready_tx.clone();
        let producer_ack = producer_ack.take();

        if let Some(mut producer_ack) = producer_ack {
            tasks.spawn(async move {
                let mut sent = 0;
                producer_ready
                    .send(())
                    .map_err(|_| "failed to report producer readiness".to_owned())?;
                producer_barrier.wait().await;
                while !producer_go.load(Ordering::Acquire) {
                    if producer_cancel.load(Ordering::Acquire) {
                        return Err("unloaded producer cancelled before start".to_owned());
                    }
                    tokio::task::yield_now().await;
                }
                for (sequence, event) in events {
                    if producer_cancel.load(Ordering::Acquire) {
                        return Err(format!(
                            "unloaded producer cancelled after {sent} events"
                        ));
                    }
                    producer_timings.starts_ns[sequence]
                        .store(producer_timings.now_ns(), Ordering::Release);
                    producer_feed
                        .send(event)
                        .map_err(|error| format!("failed to send feed event: {error:?}"))?;
                    sent += 1;

                    let acknowledged = producer_ack
                        .recv()
                        .await
                        .ok_or_else(|| "execution acknowledgement channel closed".to_owned())?;
                    if acknowledged != sequence {
                        return Err(format!(
                            "out-of-order unloaded acknowledgement: expected {sequence}, got {acknowledged}"
                        ));
                    }
                }
                Ok(TaskOutcome::Producer { sent })
            });
        } else {
            tasks.spawn(async move {
                let mut sent = 0;
                producer_ready
                    .send(())
                    .map_err(|_| "failed to report producer readiness".to_owned())?;
                producer_barrier.wait().await;
                while !producer_go.load(Ordering::Acquire) {
                    if producer_cancel.load(Ordering::Acquire) {
                        return Err("saturated producer cancelled before start".to_owned());
                    }
                    tokio::task::yield_now().await;
                }
                for (sequence, event) in events {
                    if producer_cancel.load(Ordering::Acquire) {
                        return Err(format!("saturated producer cancelled after {sent} events"));
                    }
                    producer_timings.starts_ns[sequence]
                        .store(producer_timings.now_ns(), Ordering::Release);
                    producer_feed
                        .send(event)
                        .map_err(|error| format!("failed to send feed event: {error:?}"))?;
                    sent += 1;
                }
                Ok(TaskOutcome::Producer { sent })
            });
        }
    }

    drop(ready_tx);
    let ready_deadline = TokioInstant::now() + RUN_TIMEOUT;
    let readiness = async {
        for _ in 0..(producers + 2) {
            timeout_at(ready_deadline, ready_rx.recv())
                .await
                .map_err(|_| format!("benchmark tasks were not ready after {RUN_TIMEOUT:?}"))?
                .ok_or_else(|| "benchmark readiness channel closed early".to_owned())?;
        }
        Ok::<(), String>(())
    }
    .await;

    if let Err(error) = readiness {
        return Err(cleanup_after_error(&mut tasks, &cancel, &go, &feed_tx, false, error).await);
    }

    barrier.wait().await;
    let phase_start_ns = timings.now_ns();
    go.store(true, Ordering::Release);
    let deadline = TokioInstant::now() + RUN_TIMEOUT;
    let mut producers_done = 0;
    let mut sent = 0;
    let mut engine_summary = None;
    let mut receiver_summary = None;
    let mut shutdown_sent = false;

    let supervision = async {
        while let Some(joined) = timeout_at(deadline, tasks.join_next())
            .await
            .map_err(|_| format!("tick-to-trade run timed out after {RUN_TIMEOUT:?}"))?
        {
            let outcome = joined.map_err(|error| format!("benchmark task failed: {error}"))??;

            match outcome {
                TaskOutcome::Producer {
                    sent: producer_sent,
                } => {
                    if producer_sent != messages_per_task {
                        return Err(format!(
                            "producer sent {producer_sent} of {messages_per_task} expected events"
                        ));
                    }
                    producers_done += 1;
                    sent += producer_sent;
                    if producers_done == producers {
                        feed_tx.send(EngineEvent::shutdown()).map_err(|error| {
                            format!("failed to send engine shutdown: {error:?}")
                        })?;
                        shutdown_sent = true;
                    }
                }
                TaskOutcome::Engine(summary) => engine_summary = Some(summary),
                TaskOutcome::Receiver(summary) => receiver_summary = Some(summary),
            }
        }

        Ok::<(), String>(())
    }
    .await;

    if let Err(error) = supervision {
        return Err(
            cleanup_after_error(&mut tasks, &cancel, &go, &feed_tx, shutdown_sent, error).await,
        );
    }

    if producers_done != producers {
        return Err(format!(
            "only {producers_done} of {producers} producer tasks completed"
        ));
    }
    if !shutdown_sent {
        return Err("engine did not complete an orderly shutdown".to_owned());
    }

    let engine = engine_summary.ok_or_else(|| "engine task did not finish".to_owned())?;
    let receiver =
        receiver_summary.ok_or_else(|| "execution receiver did not finish".to_owned())?;
    if sent != total_events
        || engine.callbacks != total_events
        || engine.in_flight_orders != total_events
        || receiver.orders != total_events
    {
        return Err(format!(
            "conservation failure: expected {total_events}, sent {sent}, callbacks {}, in-flight {}, orders {}",
            engine.callbacks, engine.in_flight_orders, receiver.orders
        ));
    }
    if engine.audited_events != total_events + 1 {
        return Err(format!(
            "expected {} audited events including shutdown, received {}",
            total_events + 1,
            engine.audited_events
        ));
    }
    if receiver.shutdowns != 1 {
        return Err(format!(
            "expected one execution shutdown, received {}",
            receiver.shutdowns
        ));
    }

    let mut starts_ns = Vec::with_capacity(total_events);
    let mut ends_ns = Vec::with_capacity(total_events);
    let mut latencies_ns = Vec::with_capacity(total_events);
    for sequence in 0..total_events {
        if timings.seen[sequence].load(Ordering::Acquire) != 1 {
            return Err(format!("missing execution request for sequence {sequence}"));
        }

        let start_ns = timings.starts_ns[sequence].load(Ordering::Acquire);
        let end_ns = timings.ends_ns[sequence].load(Ordering::Acquire);
        let latency_ns = end_ns.checked_sub(start_ns).ok_or_else(|| {
            format!("clock moved backwards for sequence {sequence}: {start_ns} -> {end_ns}")
        })?;
        if latency_ns == 0 {
            return Err(format!(
                "zero tick-to-trade latency for sequence {sequence}"
            ));
        }
        starts_ns.push(start_ns);
        ends_ns.push(end_ns);
        latencies_ns.push(latency_ns);
    }

    let strict_one_in_flight = scenario == Scenario::Unloaded
        && starts_ns
            .iter()
            .skip(1)
            .zip(ends_ns.iter())
            .all(|(next_start, previous_end)| next_start >= previous_end);
    if scenario == Scenario::Unloaded && !strict_one_in_flight {
        return Err("unloaded producer sent before the previous endpoint".to_owned());
    }
    let earliest_send_ns = *starts_ns
        .iter()
        .min()
        .ok_or_else(|| "run contains no send timestamps".to_owned())?;
    if earliest_send_ns < phase_start_ns {
        return Err("producer sent before the measured phase started".to_owned());
    }
    let wall_time_ns = receiver
        .last_open_ns
        .checked_sub(phase_start_ns)
        .ok_or_else(|| "wall clock moved backwards".to_owned())?;

    Ok(RunResult {
        producers,
        messages_per_task,
        sent,
        engine_callbacks: engine.callbacks,
        orders: receiver.orders,
        in_flight_orders: engine.in_flight_orders,
        shutdowns: receiver.shutdowns,
        phase_start_ns,
        earliest_send_ns,
        wall_time_ns,
        latencies_ns,
        strict_one_in_flight,
        sequence_order: receiver.sequence_order,
    })
}

fn prepare_events(
    source_ticks: &[MarketStreamEvent<InstrumentIndex, DataKind>],
    producers: usize,
    messages_per_task: usize,
) -> Result<(EventsByProducer, Vec<ExpectedOrder>), String> {
    let total_events = producers * messages_per_task;
    let mut expected = Vec::with_capacity(total_events);
    let mut by_producer = Vec::with_capacity(producers);

    for producer in 0..producers {
        let mut events = Vec::with_capacity(messages_per_task);
        for local_index in 0..messages_per_task {
            let sequence = producer * messages_per_task + local_index;
            let mut stream_event = source_ticks[sequence % source_ticks.len()].clone();
            let MarketStreamEvent::Item(event) = &mut stream_event else {
                return Err("filtered source unexpectedly contains a reconnect event".to_owned());
            };
            let DataKind::Trade(trade) = &mut event.kind else {
                return Err("filtered source unexpectedly contains a non-trade event".to_owned());
            };

            trade.id = format!("{CID_PREFIX}{sequence}");
            let price = Decimal::from_f64(trade.price)
                .ok_or_else(|| format!("non-finite trade price at sequence {sequence}"))?;
            let quantity = Decimal::from_f64(trade.amount)
                .ok_or_else(|| format!("non-finite trade amount at sequence {sequence}"))?;
            expected.push(ExpectedOrder { price, quantity });
            events.push((sequence, EngineEvent::Market(stream_event)));
        }
        by_producer.push(events);
    }

    Ok((by_producer, expected))
}

fn build_engine(execution_tx: UnboundedTx<ExecutionRequest>, order_capacity: usize) -> TickEngine {
    let instruments = IndexedInstruments::builder()
        .add_instrument(Instrument::spot(
            ExchangeId::BinanceSpot,
            "binance_spot_btc_usdt",
            "BTCUSDT",
            Underlying::new("btc", "usdt"),
            None,
        ))
        .build();
    let mut state = EngineState::builder(&instruments, DefaultGlobalData, |_| {
        TickInstrumentData::default()
    })
    .trading_state(TradingState::Enabled)
    .build();
    state
        .instruments
        .instrument_index_mut(&InstrumentIndex(0))
        .orders
        .0
        .reserve(order_capacity);

    let execution_txs =
        MultiExchangeTxMap::from_iter([(ExchangeId::BinanceSpot, Some(execution_tx))]);

    Engine::new(
        LiveClock,
        state,
        execution_txs,
        TickStrategy::default(),
        DefaultRiskManager::default(),
    )
}

async fn receive_execution_requests(
    mut execution_rx: UnboundedRx<ExecutionRequest>,
    timings: Arc<Timings>,
    expected_orders: Arc<Vec<ExpectedOrder>>,
    ack_tx: Option<mpsc::UnboundedSender<usize>>,
    ready_tx: mpsc::UnboundedSender<()>,
) -> Result<ReceiverSummary, String> {
    match ack_tx {
        Some(ack_tx) => {
            let sequence_order = Vec::with_capacity(expected_orders.len());
            ready_tx
                .send(())
                .map_err(|_| "failed to report execution receiver readiness".to_owned())?;
            receive_unloaded_execution_requests(
                &mut execution_rx,
                &timings,
                &expected_orders,
                ack_tx,
                sequence_order,
            )
            .await
        }
        None => {
            let observed_orders = Vec::with_capacity(expected_orders.len());
            let sequence_order = Vec::with_capacity(expected_orders.len());
            ready_tx
                .send(())
                .map_err(|_| "failed to report execution receiver readiness".to_owned())?;
            receive_saturated_execution_requests(
                &mut execution_rx,
                &timings,
                &expected_orders,
                observed_orders,
                sequence_order,
            )
            .await
        }
    }
}

async fn receive_unloaded_execution_requests(
    execution_rx: &mut UnboundedRx<ExecutionRequest>,
    timings: &Timings,
    expected_orders: &[ExpectedOrder],
    ack_tx: mpsc::UnboundedSender<usize>,
    mut sequence_order: Vec<usize>,
) -> Result<ReceiverSummary, String> {
    let mut orders = 0;
    let mut shutdowns = 0;
    let mut last_open_ns = 0;
    while let Some(request) = StreamExt::next(&mut *execution_rx).await {
        match request {
            ExecutionRequest::Open(open) => {
                let end_ns = timings.now_ns();
                if shutdowns != 0 {
                    return Err("received an open request after execution shutdown".to_owned());
                }
                let sequence = validate_and_record_open(end_ns, &open, timings, expected_orders)?;
                orders += 1;
                last_open_ns = end_ns;
                sequence_order.push(sequence);
                ack_tx
                    .send(sequence)
                    .map_err(|_| format!("failed to acknowledge execution request {sequence}"))?;
            }
            ExecutionRequest::Cancel(_) => {
                return Err("strategy emitted an unexpected cancel request".to_owned());
            }
            ExecutionRequest::Shutdown => {
                shutdowns += 1;
                if shutdowns > 1 {
                    return Err("received duplicate execution shutdown requests".to_owned());
                }
            }
        }
    }

    if orders != expected_orders.len() {
        return Err(format!(
            "execution channel closed after {orders} of {} orders",
            expected_orders.len()
        ));
    }
    if shutdowns != 1 {
        return Err(format!(
            "execution channel closed with {shutdowns} shutdown requests"
        ));
    }

    Ok(ReceiverSummary {
        orders,
        shutdowns,
        last_open_ns,
        sequence_order,
    })
}

async fn receive_saturated_execution_requests(
    execution_rx: &mut UnboundedRx<ExecutionRequest>,
    timings: &Timings,
    expected_orders: &[ExpectedOrder],
    mut observed_orders: Vec<(u64, OrderRequestOpen)>,
    sequence_order: Vec<usize>,
) -> Result<ReceiverSummary, String> {
    let mut orders = 0;
    let mut shutdowns = 0;
    let mut shutdown_after_orders = None;
    let mut last_open_ns = 0;
    while let Some(request) = StreamExt::next(&mut *execution_rx).await {
        match request {
            ExecutionRequest::Open(open) => {
                let end_ns = timings.now_ns();
                orders += 1;
                last_open_ns = end_ns;
                observed_orders.push((end_ns, open));
            }
            ExecutionRequest::Cancel(_) => {
                return Err("strategy emitted an unexpected cancel request".to_owned());
            }
            ExecutionRequest::Shutdown => {
                shutdowns += 1;
                shutdown_after_orders.get_or_insert(orders);
            }
        }
    }

    if orders != expected_orders.len() {
        return Err(format!(
            "execution channel closed after {orders} of {} orders",
            expected_orders.len()
        ));
    }
    if shutdowns != 1 {
        return Err(format!(
            "execution channel closed with {shutdowns} shutdown requests"
        ));
    }
    if shutdown_after_orders != Some(orders) {
        return Err("received an open request after execution shutdown".to_owned());
    }

    let sequence_order =
        validate_observed_orders(observed_orders, timings, expected_orders, sequence_order)?;

    Ok(ReceiverSummary {
        orders,
        shutdowns,
        last_open_ns,
        sequence_order,
    })
}

fn validate_observed_orders(
    observed_orders: Vec<(u64, OrderRequestOpen)>,
    timings: &Timings,
    expected_orders: &[ExpectedOrder],
    mut sequence_order: Vec<usize>,
) -> Result<Vec<usize>, String> {
    for (end_ns, open) in observed_orders {
        sequence_order.push(validate_and_record_open(
            end_ns,
            &open,
            timings,
            expected_orders,
        )?);
    }
    Ok(sequence_order)
}

fn validate_and_record_open(
    end_ns: u64,
    open: &OrderRequestOpen,
    timings: &Timings,
    expected_orders: &[ExpectedOrder],
) -> Result<usize, String> {
    let sequence = parse_sequence(open.key.cid.0.as_str())?;
    if sequence >= expected_orders.len() {
        return Err(format!(
            "CID sequence {sequence} is outside the expected range"
        ));
    }
    if timings.seen[sequence].swap(1, Ordering::AcqRel) != 0 {
        return Err(format!(
            "duplicate execution request for sequence {sequence}"
        ));
    }

    let start_ns = timings.starts_ns[sequence].load(Ordering::Acquire);
    if start_ns == 0 {
        return Err(format!(
            "sequence {sequence} was dequeued before send timing"
        ));
    }

    if open.key.exchange != ExchangeIndex(0)
        || open.key.instrument != InstrumentIndex(0)
        || open.key.strategy != StrategyId::new(STRATEGY_ID)
    {
        return Err(format!("incorrect execution route for sequence {sequence}"));
    }
    if open.state.kind != OrderKind::Market
        || open.state.time_in_force != TimeInForce::ImmediateOrCancel
        || open.state.side != Side::Buy
    {
        return Err(format!("sequence {sequence} is not a buy IOC market order"));
    }

    let expected = &expected_orders[sequence];
    if open.state.price != expected.price || open.state.quantity != expected.quantity {
        return Err(format!(
            "sequence {sequence} did not preserve real trade price/quantity"
        ));
    }

    timings.ends_ns[sequence].store(end_ns, Ordering::Release);
    Ok(sequence)
}

fn parse_sequence(cid: &str) -> Result<usize, String> {
    cid.strip_prefix(CID_PREFIX)
        .ok_or_else(|| format!("unexpected client order id: {cid}"))?
        .parse()
        .map_err(|error| format!("invalid client order id {cid}: {error}"))
}

pub fn parse_positive_usize(name: &str, value: &str) -> Result<usize, String> {
    let parsed = value
        .parse::<usize>()
        .map_err(|error| format!("invalid {name}={value}: {error}"))?;
    if parsed == 0 {
        return Err(format!("{name} must be greater than zero"));
    }
    Ok(parsed)
}

pub fn validate_producer_count(producers: usize) -> Result<usize, String> {
    if producers == 0 {
        return Err("T2T_PRODUCERS must be greater than zero".to_owned());
    }
    Ok(producers)
}

pub fn parse_scenarios(value: &str) -> Result<Vec<Scenario>, String> {
    match value {
        "unloaded" => Ok(vec![Scenario::Unloaded]),
        "saturated" => Ok(vec![Scenario::Saturated]),
        "all" => Ok(vec![Scenario::Unloaded, Scenario::Saturated]),
        _ => Err(format!(
            "invalid T2T_SCENARIO={value}; expected unloaded, saturated, or all"
        )),
    }
}

fn env_positive_usize(name: &str, default: usize) -> Result<usize, String> {
    let Some(value) = env::var_os(name) else {
        return Ok(default);
    };
    let value = value
        .into_string()
        .map_err(|_| format!("{name} must contain valid UTF-8"))?;
    parse_positive_usize(name, &value)
}

fn env_scenarios() -> Result<Vec<Scenario>, String> {
    let Some(value) = env::var_os("T2T_SCENARIO") else {
        return parse_scenarios("all");
    };
    let value = value
        .into_string()
        .map_err(|_| "T2T_SCENARIO must contain valid UTF-8".to_owned())?;
    parse_scenarios(&value)
}

async fn run_benchmark() -> Result<(), String> {
    let messages_per_task = env_positive_usize("T2T_MESSAGES_PER_TASK", DEFAULT_MESSAGES_PER_TASK)?;
    let warmup_runs = env_positive_usize("T2T_WARMUP_RUNS", DEFAULT_WARMUP_RUNS)?;
    let measured_runs = env_positive_usize("T2T_MEASURED_RUNS", DEFAULT_MEASURED_RUNS)?;
    let saturated_producers = validate_producer_count(env_positive_usize(
        "T2T_PRODUCERS",
        DEFAULT_SATURATED_PRODUCERS,
    )?)?;
    let scenarios = env_scenarios()?;
    let source_ticks = load_real_ticks()?;

    for scenario in scenarios {
        for _ in 0..warmup_runs {
            run_once_with_producers(
                scenario,
                &source_ticks,
                messages_per_task,
                saturated_producers,
            )
            .await?;
        }

        for run in 1..=measured_runs {
            let result = run_once_with_producers(
                scenario,
                &source_ticks,
                messages_per_task,
                saturated_producers,
            )
            .await?;
            let report = T2tReport::new(scenario, run, &result);
            let json = serde_json::to_string(&report)
                .map_err(|error| format!("failed to serialize benchmark report: {error}"))?;
            println!("T2T_RESULT {json}");
        }
    }

    Ok(())
}

fn main() {
    let runtime = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(RUNTIME_WORKER_THREADS)
        .enable_all()
        .build()
        .expect("build Tokio benchmark runtime");

    let result = runtime.block_on(run_benchmark());
    runtime.shutdown_timeout(CLEANUP_TIMEOUT);

    if let Err(error) = result {
        eprintln!("tick-to-trade benchmark failed: {error}");
        std::process::exit(1);
    }
}

#[cfg(test)]
#[allow(dead_code)]
mod post_drain_validation_tests {
    use super::*;

    fn expected_order() -> ExpectedOrder {
        ExpectedOrder {
            price: Decimal::new(10_000, 2),
            quantity: Decimal::new(25, 2),
        }
    }

    fn open_order(sequence: usize, exchange: ExchangeIndex) -> OrderRequestOpen {
        let expected = expected_order();
        OrderRequestOpen {
            key: OrderKey {
                exchange,
                instrument: InstrumentIndex(0),
                strategy: StrategyId::new(STRATEGY_ID),
                cid: ClientOrderId::new(format!("{CID_PREFIX}{sequence}")),
            },
            state: RequestOpen {
                side: Side::Buy,
                price: expected.price,
                quantity: expected.quantity,
                kind: OrderKind::Market,
                time_in_force: TimeInForce::ImmediateOrCancel,
            },
        }
    }

    #[test]
    fn post_drain_validation_rejects_duplicate_cid() {
        let timings = Timings::new(2);
        timings.starts_ns[0].store(1, Ordering::Release);
        timings.starts_ns[1].store(1, Ordering::Release);
        let expected = vec![expected_order(), expected_order()];
        let observed = vec![
            (10, open_order(0, ExchangeIndex(0))),
            (11, open_order(0, ExchangeIndex(0))),
        ];

        let error = validate_observed_orders(observed, &timings, &expected, Vec::with_capacity(2))
            .expect_err("duplicate CID must fail validation");

        assert!(error.contains("duplicate execution request for sequence 0"));
    }

    #[test]
    fn post_drain_validation_rejects_wrong_route() {
        let timings = Timings::new(1);
        timings.starts_ns[0].store(1, Ordering::Release);
        let expected = vec![expected_order()];
        let observed = vec![(10, open_order(0, ExchangeIndex(1)))];

        let error = validate_observed_orders(observed, &timings, &expected, Vec::with_capacity(1))
            .expect_err("wrong route must fail validation");

        assert!(error.contains("incorrect execution route for sequence 0"));
    }
}
