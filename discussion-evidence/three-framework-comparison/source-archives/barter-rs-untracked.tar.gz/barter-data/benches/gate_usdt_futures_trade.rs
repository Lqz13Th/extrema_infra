use std::time::Duration;

use barter_data::{
    event::MarketEvent,
    exchange::gateio::perpetual::{GateioPerpetualsUsd, trade::GateioFuturesTrades},
    subscription::{
        Map,
        trade::{PublicTrade, PublicTrades},
    },
    transformer::{ExchangeTransformer, stateless::StatelessTransformer},
};
use barter_instrument::{Side, exchange::ExchangeId};
use barter_integration::{
    Transformer,
    protocol::{
        StreamParser,
        websocket::{WebSocketSerdeParser, WsMessage},
    },
    subscription::SubscriptionId,
};
use criterion::{BatchSize, Criterion, Throughput, black_box, criterion_group, criterion_main};

// Shared verbatim with Extrema's Gate benchmark. Barter's production
// normalization additionally performs an instrument-map lookup, calls
// Utc::now() for time_received, and allocates the numeric trade id as a String.
const PAYLOAD: &str = r#"{"time":1669843487,"time_ms":1669843487733,"channel":"futures.trades","event":"update","result":[{"contract":"BTC_USDT","create_time":1669843487,"create_time_ms":1669843487724,"id":180276616,"price":"1287","size":-3}]}"#;
const INSTRUMENT_KEY: u64 = 7;

type TradeTransformer =
    StatelessTransformer<GateioPerpetualsUsd, u64, PublicTrades, GateioFuturesTrades>;

fn init_transformer() -> TradeTransformer {
    let instrument_map = Map::from_iter([(
        SubscriptionId::from("futures.trades|BTC_USDT"),
        INSTRUMENT_KEY,
    )]);
    let (ws_sink_tx, _ws_sink_rx) = tokio::sync::mpsc::unbounded_channel();

    futures::executor::block_on(TradeTransformer::init(instrument_map, &[], ws_sink_tx))
        .expect("stateless transformer initialization must succeed")
}

fn parse_and_normalize(
    message: WsMessage,
    transformer: &mut TradeTransformer,
) -> MarketEvent<u64, PublicTrade> {
    let wire = <WebSocketSerdeParser as StreamParser<GateioFuturesTrades>>::parse(Ok(message))
        .expect("a text WebSocket message must produce a parse result")
        .expect("the Gate futures trade payload must deserialize");

    let mut events = transformer.transform(wire);
    debug_assert_eq!(events.len(), 1, "one trade must produce one market event");
    events
        .pop()
        .expect("one market event must be present")
        .expect("the configured contract must normalize")
}

fn assert_expected(event: &MarketEvent<u64, PublicTrade>) {
    assert_eq!(event.exchange, ExchangeId::GateioPerpetualsUsd);
    assert_eq!(event.instrument, INSTRUMENT_KEY);
    assert_eq!(event.time_exchange.timestamp_millis(), 1_669_843_487_724);
    assert_eq!(event.kind.id, "180276616");
    assert_eq!(event.kind.price, 1287.0);
    assert_eq!(event.kind.amount, -3.0);
    assert_eq!(event.kind.side, Side::Sell);
}

fn benchmark_gate_usdt_futures_trade(c: &mut Criterion) {
    let message = WsMessage::text(PAYLOAD);
    let mut transformer = init_transformer();

    let preflight = parse_and_normalize(message.clone(), &mut transformer);
    assert_expected(&preflight);

    let mut group = c.benchmark_group("gate_usdt_futures_trade");
    group.throughput(Throughput::Elements(1));
    group.bench_function("parse_normalize", |b| {
        b.iter_batched(
            || message.clone(),
            |message| {
                let normalized = parse_and_normalize(message, &mut transformer);
                black_box(normalized);
            },
            BatchSize::SmallInput,
        );
    });
    group.finish();
}

criterion_group! {
    name = benches;
    config = Criterion::default()
        .warm_up_time(Duration::from_secs(1))
        .measurement_time(Duration::from_secs(3))
        .sample_size(100);
    targets = benchmark_gate_usdt_futures_trade
}
criterion_main!(benches);
