use std::time::Duration;

use barter_data::{
    books::Level,
    event::{MarketEvent, MarketIter},
    exchange::binance::book::l1::BinanceOrderBookL1,
    subscription::book::OrderBookL1,
};
use barter_instrument::exchange::ExchangeId;
use chrono::{TimeZone, Utc};
use criterion::{Criterion, Throughput, black_box, criterion_group, criterion_main};
use rust_decimal_macros::dec;

const PAYLOAD: &[u8] = br#"{"e":"bookTicker","u":10708444522016,"s":"BTCUSDT","b":"63405.40","B":"4.629","a":"63405.50","A":"2.357","T":1780563843114,"E":1780563843114}"#;
const INSTRUMENT_KEY: u64 = 7;

fn parse_and_normalize(payload: &[u8]) -> MarketEvent<u64, OrderBookL1> {
    let wire = serde_json::from_slice::<BinanceOrderBookL1>(payload)
        .expect("the Binance USD-M bookTicker payload must deserialize");

    let MarketIter(mut events) = (ExchangeId::BinanceFuturesUsd, INSTRUMENT_KEY, wire).into();
    debug_assert_eq!(events.len(), 1, "one bookTicker must produce one event");
    events
        .pop()
        .expect("one market event must be present")
        .expect("bookTicker normalization must succeed")
}

fn assert_expected(event: &MarketEvent<u64, OrderBookL1>) {
    let expected_time = Utc.timestamp_millis_opt(1_780_563_843_114).unwrap();

    assert_eq!(event.exchange, ExchangeId::BinanceFuturesUsd);
    assert_eq!(event.instrument, INSTRUMENT_KEY);
    assert_eq!(event.time_exchange, expected_time);
    assert_eq!(event.kind.last_update_time, expected_time);
    assert_eq!(
        event.kind.best_bid,
        Some(Level::new(dec!(63405.40), dec!(4.629)))
    );
    assert_eq!(
        event.kind.best_ask,
        Some(Level::new(dec!(63405.50), dec!(2.357)))
    );
}

fn benchmark_binance_usdm_book_ticker(c: &mut Criterion) {
    let preflight = parse_and_normalize(PAYLOAD);
    assert_expected(&preflight);

    let mut group = c.benchmark_group("binance_usdm_book_ticker");
    group.throughput(Throughput::Elements(1));
    group.bench_function("parse_only", |b| {
        b.iter(|| {
            let wire = serde_json::from_slice::<BinanceOrderBookL1>(black_box(PAYLOAD))
                .expect("the Binance USD-M bookTicker payload must deserialize");
            black_box(wire);
        });
    });
    group.bench_function("parse_normalize", |b| {
        b.iter(|| {
            let normalized = parse_and_normalize(black_box(PAYLOAD));
            black_box(normalized);
        });
    });
    group.finish();
}

criterion_group! {
    name = benches;
    config = Criterion::default()
        .warm_up_time(Duration::from_secs(1))
        .measurement_time(Duration::from_secs(3))
        .sample_size(100);
    targets = benchmark_binance_usdm_book_ticker
}
criterion_main!(benches);
