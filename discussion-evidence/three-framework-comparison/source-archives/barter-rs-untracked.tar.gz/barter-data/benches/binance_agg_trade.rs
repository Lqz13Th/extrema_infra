use barter_data::{
    event::MarketEvent,
    exchange::binance::{
        futures::BinanceFuturesUsd,
        trade::{BinanceTrade, de_side_from_buyer_is_maker, de_trade_subscription_id},
    },
    subscription::{
        Map,
        trade::{PublicTrade, PublicTrades},
    },
    transformer::{ExchangeTransformer, stateless::StatelessTransformer},
};
use barter_instrument::{Side, exchange::ExchangeId};
use barter_integration::{
    Transformer,
    protocol::{
        StreamParser,
        websocket::{WebSocketSerdeParser, WsMessage},
    },
    subscription::SubscriptionId,
};
use chrono::{DateTime, Utc};
use criterion::{BatchSize, Criterion, black_box, criterion_group, criterion_main};
use serde::Deserialize;

const PAYLOAD: &str = r#"{"e":"aggTrade","E":1735689600000,"s":"BTCUSDT","a":5933014,"p":"0.001","q":"100","f":100,"l":105,"T":1735689599996,"m":true}"#;
const INSTRUMENT_KEY: u64 = 7;

type TradeTransformer = StatelessTransformer<BinanceFuturesUsd, u64, PublicTrades, BinanceTrade>;

// Barter's production BinanceTrade accepts the trade stream's `t` id, but Binance USD-M
// aggTrade messages use `a`. Keep that wire compatibility shim local to this benchmark while
// reusing Barter's production protocol parser, field deserializers, and trade transformer.
#[derive(Deserialize)]
struct BinanceAggTrade {
    #[serde(rename = "s", deserialize_with = "de_trade_subscription_id")]
    subscription_id: SubscriptionId,
    #[serde(
        rename = "T",
        deserialize_with = "barter_integration::serde::de::de_u64_epoch_ms_as_datetime_utc"
    )]
    time: DateTime<Utc>,
    #[serde(rename = "a")]
    id: u64,
    #[serde(
        rename = "p",
        deserialize_with = "barter_integration::serde::de::de_str"
    )]
    price: f64,
    #[serde(
        rename = "q",
        deserialize_with = "barter_integration::serde::de::de_str"
    )]
    amount: f64,
    #[serde(rename = "m", deserialize_with = "de_side_from_buyer_is_maker")]
    side: Side,
}

impl From<BinanceAggTrade> for BinanceTrade {
    fn from(value: BinanceAggTrade) -> Self {
        Self {
            subscription_id: value.subscription_id,
            time: value.time,
            id: value.id,
            price: value.price,
            amount: value.amount,
            side: value.side,
        }
    }
}

fn init_transformer() -> TradeTransformer {
    let instrument_map = Map::from_iter([(SubscriptionId::from("@trade|BTCUSDT"), INSTRUMENT_KEY)]);
    let (ws_sink_tx, _ws_sink_rx) = tokio::sync::mpsc::unbounded_channel();

    futures::executor::block_on(TradeTransformer::init(instrument_map, &[], ws_sink_tx))
        .expect("stateless transformer initialization must succeed")
}

fn parse_and_normalize(
    message: WsMessage,
    transformer: &mut TradeTransformer,
) -> MarketEvent<u64, PublicTrade> {
    let wire = <WebSocketSerdeParser as StreamParser<BinanceAggTrade>>::parse(Ok(message))
        .expect("a text WebSocket message must produce a parse result")
        .expect("the benchmark aggTrade payload must deserialize");

    let mut events = transformer.transform(wire.into());
    debug_assert_eq!(
        events.len(),
        1,
        "one aggTrade must produce one market event"
    );
    events
        .pop()
        .expect("one market event must be present")
        .expect("the configured symbol must normalize")
}

fn assert_expected(event: &MarketEvent<u64, PublicTrade>) {
    assert_eq!(event.exchange, ExchangeId::BinanceFuturesUsd);
    assert_eq!(event.instrument, INSTRUMENT_KEY);
    assert_eq!(event.time_exchange.timestamp_millis(), 1_735_689_599_996);
    assert_eq!(event.kind.id, "5933014");
    assert_eq!(event.kind.price, 0.001);
    assert_eq!(event.kind.amount, 100.0);
    assert_eq!(event.kind.side, Side::Sell);
}

fn benchmark_binance_agg_trade(c: &mut Criterion) {
    let message = WsMessage::text(PAYLOAD);
    let mut transformer = init_transformer();

    let preflight = parse_and_normalize(message.clone(), &mut transformer);
    assert_expected(&preflight);

    c.bench_function("parse_normalize", |b| {
        b.iter_batched(
            || message.clone(),
            |message| {
                let normalized_event = parse_and_normalize(message, &mut transformer);
                black_box(normalized_event);
            },
            BatchSize::SmallInput,
        );
    });
}

criterion_group!(benches, benchmark_binance_agg_trade);
criterion_main!(benches);
