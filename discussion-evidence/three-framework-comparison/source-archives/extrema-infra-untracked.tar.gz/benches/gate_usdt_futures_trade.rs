use std::time::Duration;

use criterion::{Criterion, Throughput, black_box, criterion_group, criterion_main};
use extrema_infra::{
    arch::market_assets::{base_data::OrderSide, market_core::Market},
    ws_decode_benchmark::gate_usdt_futures_trade,
};

// Shared verbatim with Barter's Gate benchmark. This path returns Extrema's
// production Vec<WsTrade>, whose normalized price and size fields are f64.
const PAYLOAD: &[u8] = br#"{"time":1669843487,"time_ms":1669843487733,"channel":"futures.trades","event":"update","result":[{"contract":"BTC_USDT","create_time":1669843487,"create_time_ms":1669843487724,"id":180276616,"price":"1287","size":-3}]}"#;

fn benchmark_gate_usdt_futures_trade(c: &mut Criterion) {
    let decoded = gate_usdt_futures_trade(PAYLOAD).expect("fixture must decode");
    assert_eq!(decoded.len(), 1);
    let trade = &decoded[0];
    assert_eq!(trade.timestamp, 1_669_843_487_724_000);
    assert_eq!(trade.market, Market::GateFutures);
    assert_eq!(trade.inst, "BTC_USDT_PERP");
    assert_eq!(trade.price, 1287.0);
    assert_eq!(trade.size, 3.0);
    assert_eq!(trade.side, OrderSide::SELL);
    assert_eq!(trade.trade_id, 180_276_616);

    let mut group = c.benchmark_group("gate_usdt_futures_trade");
    group.throughput(Throughput::Elements(1));
    group.bench_function("parse_normalize", |b| {
        b.iter(|| {
            let normalized =
                gate_usdt_futures_trade(black_box(PAYLOAD)).expect("fixture must decode");
            black_box(normalized)
        });
    });
    group.finish();
}

criterion_group! {
    name = benches;
    config = Criterion::default()
        .warm_up_time(Duration::from_secs(1))
        .measurement_time(Duration::from_secs(3))
        .sample_size(100);
    targets = benchmark_gate_usdt_futures_trade
}
criterion_main!(benches);
