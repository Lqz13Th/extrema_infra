use extrema_infra::live_pipeline_benchmark::{
    LiveMode, LivePipelineConfig, LiveScenario, LiveTopology, run_live_pipeline,
};
use serde::Serialize;

const DEFAULT_TASKS: usize = 5;
const DEFAULT_INSTRUMENTS_PER_TASK: usize = 20;
const DEFAULT_MESSAGES_PER_INSTRUMENT: usize = 256;
const DEFAULT_ORDER_EVERY: usize = 20;
const DEFAULT_SIGNAL_COMPUTE_NS: u64 = 0;
const DEFAULT_REJECT_EVERY: usize = 10;
const DEFAULT_WARMUP_RUNS: usize = 1;
const DEFAULT_MEASURED_RUNS: usize = 5;
const DEFAULT_WORKER_THREADS: usize = 16;

#[derive(Serialize)]
struct ResultLine<'a> {
    benchmark: &'static str,
    run: usize,
    runtime_worker_threads: usize,
    #[serde(flatten)]
    report: &'a extrema_infra::live_pipeline_benchmark::LivePipelineReport,
}

fn main() {
    let runtime_worker_threads = positive_env("LIVE_WORKER_THREADS", DEFAULT_WORKER_THREADS);
    let runtime = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(runtime_worker_threads)
        .enable_all()
        .build()
        .expect("build live pipeline benchmark runtime");
    runtime.block_on(run(runtime_worker_threads));
    runtime.shutdown_timeout(std::time::Duration::from_secs(5));
}

async fn run(runtime_worker_threads: usize) {
    let config = LivePipelineConfig {
        tasks: positive_env("LIVE_TASKS", DEFAULT_TASKS),
        instruments_per_task: positive_env(
            "LIVE_INSTRUMENTS_PER_TASK",
            DEFAULT_INSTRUMENTS_PER_TASK,
        ),
        messages_per_instrument: positive_env(
            "LIVE_MESSAGES_PER_INSTRUMENT",
            DEFAULT_MESSAGES_PER_INSTRUMENT,
        ),
        mode: match std::env::var("LIVE_MODE")
            .unwrap_or_else(|_| "stress".into())
            .as_str()
        {
            "stress" => LiveMode::Stress,
            "mixed_live" => LiveMode::MixedLive,
            value => panic!("LIVE_MODE must be stress or mixed_live; got {value:?}"),
        },
        order_every: positive_env("LIVE_ORDER_EVERY", DEFAULT_ORDER_EVERY),
        signal_compute_ns: nonnegative_u64_env("LIVE_SIGNAL_COMPUTE_NS", DEFAULT_SIGNAL_COMPUTE_NS),
        reject_every: positive_env("LIVE_REJECT_EVERY", DEFAULT_REJECT_EVERY),
        scenario: match std::env::var("LIVE_SCENARIO")
            .unwrap_or_else(|_| "success".into())
            .as_str()
        {
            "success" => LiveScenario::Success,
            "business_error" => LiveScenario::BusinessError,
            value => panic!("LIVE_SCENARIO must be success or business_error; got {value:?}"),
        },
        topology: match std::env::var("LIVE_TOPOLOGY")
            .unwrap_or_else(|_| "shared_handler".into())
            .as_str()
        {
            "shared_handler" => LiveTopology::SharedHandler,
            "batch_sharded" => LiveTopology::BatchSharded,
            "ws5_strategy20" => LiveTopology::Ws5Strategy20,
            value => panic!(
                "LIVE_TOPOLOGY must be shared_handler, batch_sharded, or ws5_strategy20; got {value:?}"
            ),
        },
    };
    let warmup_runs = nonnegative_env("LIVE_WARMUP_RUNS", DEFAULT_WARMUP_RUNS);
    let measured_runs = positive_env("LIVE_MEASURED_RUNS", DEFAULT_MEASURED_RUNS);

    for _ in 0..warmup_runs {
        run_live_pipeline(config)
            .await
            .expect("live pipeline warmup failed");
    }
    for run in 1..=measured_runs {
        let report = run_live_pipeline(config)
            .await
            .expect("live pipeline measured run failed");
        let line = ResultLine {
            benchmark: "live_pipeline",
            run,
            runtime_worker_threads,
            report: &report,
        };
        println!(
            "LIVE_PIPELINE_RESULT {}",
            serde_json::to_string(&line).expect("live pipeline report must serialize")
        );
    }
}

fn positive_env(name: &str, default: usize) -> usize {
    let value = nonnegative_env(name, default);
    assert!(value > 0, "{name} must be greater than zero");
    value
}

fn nonnegative_env(name: &str, default: usize) -> usize {
    std::env::var(name).map_or(default, |value| {
        value
            .parse::<usize>()
            .unwrap_or_else(|error| panic!("invalid {name}={value:?}: {error}"))
    })
}

fn nonnegative_u64_env(name: &str, default: u64) -> u64 {
    std::env::var(name).map_or(default, |value| {
        value
            .parse::<u64>()
            .unwrap_or_else(|error| panic!("invalid {name}={value:?}: {error}"))
    })
}
