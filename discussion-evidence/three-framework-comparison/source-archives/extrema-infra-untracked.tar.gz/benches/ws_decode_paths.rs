use std::{hint::black_box, time::Duration};

use criterion::{Criterion, criterion_group, criterion_main};
use extrema_infra::ws_decode_benchmark::{
    GATE_BBO, GATE_CONTROL, GATE_INCREMENTAL, GATE_SNAPSHOT, HYPERLIQUID_BBO, HYPERLIQUID_L2,
    HYPERLIQUID_PONG, gate_bbo_legacy, gate_bbo_specialized, gate_control_legacy,
    gate_control_specialized, gate_incremental_legacy, gate_incremental_specialized,
    gate_snapshot_legacy, gate_snapshot_specialized, hyperliquid_bbo_legacy,
    hyperliquid_bbo_specialized, hyperliquid_l2_legacy, hyperliquid_l2_specialized,
    hyperliquid_pong_legacy, hyperliquid_pong_specialized,
};

fn benchmark_ws_decode_paths(c: &mut Criterion) {
    assert_eq!(
        format!("{:?}", gate_bbo_legacy(GATE_BBO)),
        format!("{:?}", gate_bbo_specialized(GATE_BBO))
    );
    assert_eq!(
        format!("{:?}", gate_snapshot_legacy(GATE_SNAPSHOT)),
        format!("{:?}", gate_snapshot_specialized(GATE_SNAPSHOT))
    );
    assert_eq!(
        format!("{:?}", gate_incremental_legacy(GATE_INCREMENTAL)),
        format!("{:?}", gate_incremental_specialized(GATE_INCREMENTAL))
    );
    assert_eq!(
        format!("{:?}", gate_control_legacy(GATE_CONTROL)),
        format!("{:?}", gate_control_specialized(GATE_CONTROL))
    );
    assert_eq!(
        format!("{:?}", hyperliquid_bbo_legacy(HYPERLIQUID_BBO)),
        format!("{:?}", hyperliquid_bbo_specialized(HYPERLIQUID_BBO))
    );
    assert_eq!(
        format!("{:?}", hyperliquid_l2_legacy(HYPERLIQUID_L2)),
        format!("{:?}", hyperliquid_l2_specialized(HYPERLIQUID_L2))
    );
    assert_eq!(
        format!("{:?}", hyperliquid_pong_legacy(HYPERLIQUID_PONG)),
        format!("{:?}", hyperliquid_pong_specialized(HYPERLIQUID_PONG))
    );

    let mut group = c.benchmark_group("ws_decode_normalize");
    group.bench_function("gate_bbo/legacy_untagged", |b| {
        b.iter(|| black_box(gate_bbo_legacy(black_box(GATE_BBO))))
    });
    group.bench_function("gate_bbo/specialized", |b| {
        b.iter(|| black_box(gate_bbo_specialized(black_box(GATE_BBO))))
    });
    group.bench_function("gate_snapshot/legacy_untagged", |b| {
        b.iter(|| black_box(gate_snapshot_legacy(black_box(GATE_SNAPSHOT))))
    });
    group.bench_function("gate_snapshot/specialized", |b| {
        b.iter(|| black_box(gate_snapshot_specialized(black_box(GATE_SNAPSHOT))))
    });
    group.bench_function("gate_incremental/legacy_untagged", |b| {
        b.iter(|| black_box(gate_incremental_legacy(black_box(GATE_INCREMENTAL))))
    });
    group.bench_function("gate_incremental/specialized", |b| {
        b.iter(|| black_box(gate_incremental_specialized(black_box(GATE_INCREMENTAL))))
    });
    group.bench_function("gate_control/legacy_untagged", |b| {
        b.iter(|| black_box(gate_control_legacy(black_box(GATE_CONTROL))))
    });
    group.bench_function("gate_control/specialized_fallback", |b| {
        b.iter(|| black_box(gate_control_specialized(black_box(GATE_CONTROL))))
    });
    group.bench_function("hyperliquid_bbo/legacy_untagged", |b| {
        b.iter(|| black_box(hyperliquid_bbo_legacy(black_box(HYPERLIQUID_BBO))))
    });
    group.bench_function("hyperliquid_bbo/specialized", |b| {
        b.iter(|| black_box(hyperliquid_bbo_specialized(black_box(HYPERLIQUID_BBO))))
    });
    group.bench_function("hyperliquid_l2/legacy_untagged", |b| {
        b.iter(|| black_box(hyperliquid_l2_legacy(black_box(HYPERLIQUID_L2))))
    });
    group.bench_function("hyperliquid_l2/specialized", |b| {
        b.iter(|| black_box(hyperliquid_l2_specialized(black_box(HYPERLIQUID_L2))))
    });
    group.bench_function("hyperliquid_pong/legacy_untagged", |b| {
        b.iter(|| black_box(hyperliquid_pong_legacy(black_box(HYPERLIQUID_PONG))))
    });
    group.bench_function("hyperliquid_pong/specialized_fallback", |b| {
        b.iter(|| black_box(hyperliquid_pong_specialized(black_box(HYPERLIQUID_PONG))))
    });
    group.finish();
}

fn config() -> Criterion {
    Criterion::default()
        .warm_up_time(Duration::from_secs(1))
        .measurement_time(Duration::from_secs(3))
        .sample_size(100)
}

criterion_group! {
    name = benches;
    config = config();
    targets = benchmark_ws_decode_paths
}
criterion_main!(benches);
