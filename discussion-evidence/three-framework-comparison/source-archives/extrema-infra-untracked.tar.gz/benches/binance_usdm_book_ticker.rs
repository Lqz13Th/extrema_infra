use std::time::Duration;

use criterion::{Criterion, Throughput, black_box, criterion_group, criterion_main};
use extrema_infra::arch::{
    market_assets::{exchange::binance::benchmark::decode_um_book_ticker, market_core::Market},
    strategy_base::handler::lob_events::{LobEventKind, LobLevelAction},
};

const PAYLOAD: &[u8] = br#"{"e":"bookTicker","u":10708444522016,"s":"BTCUSDT","b":"63405.40","B":"4.629","a":"63405.50","A":"2.357","T":1780563843114,"E":1780563843114}"#;

fn benchmark_binance_usdm_book_ticker(c: &mut Criterion) {
    let decoded = decode_um_book_ticker(PAYLOAD).expect("fixture must decode");
    assert_eq!(decoded.len(), 1);

    let lob = &decoded[0];
    assert_eq!(lob.timestamp, 1_780_563_843_114_000);
    assert_eq!(lob.market, Market::BinanceUmFutures);
    assert_eq!(lob.inst, "BTC_USDT_PERP");
    assert!(matches!(lob.event, LobEventKind::Bbo));
    assert_eq!(lob.bids.len(), 1);
    assert_eq!(lob.bids[0].price, 63_405.40);
    assert_eq!(lob.bids[0].size, 4.629);
    assert!(matches!(lob.bids[0].action, LobLevelAction::Upsert));
    assert_eq!(lob.bids[0].level_update_id, Some(10_708_444_522_016));
    assert_eq!(lob.asks.len(), 1);
    assert_eq!(lob.asks[0].price, 63_405.50);
    assert_eq!(lob.asks[0].size, 2.357);
    assert!(matches!(lob.asks[0].action, LobLevelAction::Upsert));
    assert_eq!(lob.asks[0].level_update_id, Some(10_708_444_522_016));
    assert_eq!(lob.seq.as_ref().and_then(|seq| seq.prev), None);
    assert_eq!(
        lob.seq.as_ref().and_then(|seq| seq.first),
        Some(10_708_444_522_016)
    );
    assert_eq!(
        lob.seq.as_ref().and_then(|seq| seq.last),
        Some(10_708_444_522_016)
    );

    let mut group = c.benchmark_group("binance_usdm_book_ticker");
    group.throughput(Throughput::Elements(1));
    group.bench_function("parse_normalize", |b| {
        b.iter(|| {
            let normalized =
                decode_um_book_ticker(black_box(PAYLOAD)).expect("fixture must decode");
            black_box(normalized)
        });
    });
    group.finish();
}

criterion_group! {
    name = benches;
    config = Criterion::default()
        .warm_up_time(Duration::from_secs(1))
        .measurement_time(Duration::from_secs(3))
        .sample_size(100);
    targets = benchmark_binance_usdm_book_ticker
}
criterion_main!(benches);
