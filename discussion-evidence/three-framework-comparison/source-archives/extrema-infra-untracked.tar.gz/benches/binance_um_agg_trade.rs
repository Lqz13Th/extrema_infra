use std::time::Duration;

use criterion::{Criterion, Throughput, black_box, criterion_group, criterion_main};
use extrema_infra::arch::market_assets::{
    base_data::OrderSide, exchange::binance::benchmark::decode_um_agg_trade, market_core::Market,
};

const PAYLOAD: &[u8] = br#"{"e":"aggTrade","E":1735689600000,"s":"BTCUSDT","a":5933014,"p":"0.001","q":"100","f":100,"l":105,"T":1735689599996,"m":true}"#;

fn benchmark_binance_um_agg_trade(c: &mut Criterion) {
    let payload = PAYLOAD.to_vec();

    let decoded = decode_um_agg_trade(&payload).expect("fixture must decode");
    assert_eq!(decoded.len(), 1);
    let trade = &decoded[0];
    assert_eq!(trade.timestamp, 1_735_689_599_996_000);
    assert_eq!(trade.market, Market::BinanceUmFutures);
    assert_eq!(trade.inst, "BTC_USDT_PERP");
    assert_eq!(trade.price, 0.001);
    assert_eq!(trade.size, 100.0);
    assert_eq!(trade.side, OrderSide::SELL);
    assert_eq!(trade.trade_id, 5_933_014);

    let mut group = c.benchmark_group("binance_usdm_agg_trade");
    group.throughput(Throughput::Elements(1));
    group.bench_function("parse_normalize", |b| {
        b.iter(|| {
            let normalized_event =
                decode_um_agg_trade(black_box(payload.as_slice())).expect("fixture must decode");
            black_box(normalized_event)
        });
    });
    group.finish();
}

criterion_group! {
    name = benches;
    config = Criterion::default()
        .warm_up_time(Duration::from_secs(1))
        .measurement_time(Duration::from_secs(3))
        .sample_size(100);
    targets = benchmark_binance_um_agg_trade
}
criterion_main!(benches);
