use extrema_infra::benchmark::{NativeTickToTradeWorkload, run_native_tick_to_trade};
use serde::Serialize;

const DEFAULT_MESSAGES_PER_TASK: usize = 4_096;
const DEFAULT_SATURATED_TASKS: usize = 16;
const DEFAULT_WARMUP_ROUNDS: usize = 1;
const DEFAULT_MEASURED_ROUNDS: usize = 5;

#[derive(Serialize)]
struct ResultLine<'a> {
    benchmark: &'static str,
    round: usize,
    #[serde(flatten)]
    report: &'a extrema_infra::benchmark::NativeTickToTradeReport,
}

#[tokio::main(flavor = "multi_thread", worker_threads = 16)]
async fn main() {
    let messages_per_task = positive_env("T2T_MESSAGES_PER_TASK", DEFAULT_MESSAGES_PER_TASK);
    let saturated_tasks = positive_env("T2T_PRODUCERS", DEFAULT_SATURATED_TASKS);
    let warmup_rounds = nonnegative_env("T2T_WARMUP_RUNS", DEFAULT_WARMUP_ROUNDS);
    let measured_rounds = positive_env("T2T_MEASURED_RUNS", DEFAULT_MEASURED_ROUNDS);
    let workloads = match std::env::var("T2T_SCENARIO")
        .unwrap_or_else(|_| "all".into())
        .as_str()
    {
        "all" => vec![
            NativeTickToTradeWorkload::Unloaded,
            NativeTickToTradeWorkload::Saturated {
                tasks: saturated_tasks,
            },
        ],
        "unloaded" => vec![NativeTickToTradeWorkload::Unloaded],
        "saturated" => vec![NativeTickToTradeWorkload::Saturated {
            tasks: saturated_tasks,
        }],
        value => panic!("T2T_SCENARIO must be unloaded, saturated, or all; got {value:?}"),
    };

    for workload in workloads {
        for _ in 0..warmup_rounds {
            run_native_tick_to_trade(workload, messages_per_task)
                .await
                .expect("native tick-to-trade warmup failed conservation checks");
        }

        for round in 1..=measured_rounds {
            let report = run_native_tick_to_trade(workload, messages_per_task)
                .await
                .expect("native tick-to-trade measured run failed conservation checks");
            let line = ResultLine {
                benchmark: "native_tick_to_trade",
                round,
                report: &report,
            };
            println!(
                "T2T_RESULT {}",
                serde_json::to_string(&line).expect("benchmark result must serialize")
            );
        }
    }
}

fn positive_env(name: &str, default: usize) -> usize {
    let value = nonnegative_env(name, default);
    assert!(value > 0, "{name} must be greater than zero");
    value
}

fn nonnegative_env(name: &str, default: usize) -> usize {
    std::env::var(name).map_or(default, |value| {
        value
            .parse::<usize>()
            .unwrap_or_else(|error| panic!("invalid {name}={value:?}: {error}"))
    })
}
