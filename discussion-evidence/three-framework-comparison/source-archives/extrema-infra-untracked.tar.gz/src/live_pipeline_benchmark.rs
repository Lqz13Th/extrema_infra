//! Internal full live-shaped pipeline benchmark support.

use std::{
    collections::HashMap,
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, AtomicU8, AtomicU32, AtomicU64, Ordering},
    },
    time::{Duration, Instant},
};

use serde::Serialize;
use serde_json::json;
use tokio::{
    sync::{Barrier, Notify, broadcast, mpsc},
    task::JoinSet,
};

use crate::{
    arch::{
        market_assets::{
            api_general::OrderParams,
            base_data::{OrderSide, OrderStatus, OrderType},
            exchange::binance::{
                api_utils::binance_fut_inst_to_cli,
                benchmark::{decode_um_account_order, decode_um_agg_trade},
            },
            market_core::Market,
        },
        strategy_base::{
            command::command_core::{CommandHandle, CommandRegistry, TaskCommand},
            handler::{
                events::{InfraMsg, WsAccOrder, WsTrade, alt_events::AltOrder},
                handler_core::strategy_handler_loop_with_lag_observer,
                task_channel::{
                    ACC_ORDER_CHANNEL_CAPACITY, ORDER_EXECUTION_CHANNEL_CAPACITY,
                    TRADE_CHANNEL_CAPACITY, TaskChannels, TaskEvent,
                },
            },
        },
        task_execution::{
            TaskInfo, TaskKey,
            alt_runner::AltTaskRunner,
            task_alt::{AltTaskInfo, AltTaskType},
            task_ws::WsChannel,
        },
        traits::strategy::{CommandEmitter, EventHandler, Strategy},
    },
    errors::{InfraError, InfraResult},
};

const TASK_ID_BASE: u64 = 1;
const TRADE_LANE_TASK_ID_BASE: u64 = 1_000_000;
const BATCH_TRADE_LANES: usize = 20;
const SIGNAL_HANDLERS_PER_BATCH: usize = 5;
const TRADE_LANES_PER_SIGNAL_HANDLER: usize = BATCH_TRADE_LANES / SIGNAL_HANDLERS_PER_BATCH;
const WS5_STRATEGY20_PUBLIC_WS_TASKS: usize = 20;
const WS5_STRATEGY20_SYMBOLS_PER_WS: usize = 5;
const PUBLIC_TIME_BASE_MS: u64 = 1_800_000_000_000;
const PRIVATE_TIME_BASE_MS: u64 = 1_810_000_000_000;
const CID_PREFIX: &str = "live-";
const ORDER_SIZE: &str = "0.001";
const ORDER_SIZE_F64: f64 = 0.001;
const PRIVATE_INGRESS_CAPACITY: usize = 8_192;
const RUN_TIMEOUT: Duration = Duration::from_secs(30);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LiveMode {
    Stress,
    MixedLive,
}

impl LiveMode {
    pub fn name(self) -> &'static str {
        match self {
            Self::Stress => "stress",
            Self::MixedLive => "mixed_live",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LiveScenario {
    Success,
    BusinessError,
}

impl LiveScenario {
    pub fn name(self) -> &'static str {
        match self {
            Self::Success => "success",
            Self::BusinessError => "business_error",
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum LiveTopology {
    #[default]
    SharedHandler,
    BatchSharded,
    Ws5Strategy20,
}

impl LiveTopology {
    pub fn name(self) -> &'static str {
        match self {
            Self::SharedHandler => "shared_handler",
            Self::BatchSharded => "batch_sharded",
            Self::Ws5Strategy20 => "ws5_strategy20",
        }
    }

    fn producer_tasks(self, batches: usize) -> Option<usize> {
        match self {
            Self::SharedHandler => Some(batches),
            Self::BatchSharded => batches.checked_mul(BATCH_TRADE_LANES),
            Self::Ws5Strategy20 => Some(batches),
        }
    }

    fn signal_handlers(self, batches: usize) -> Option<usize> {
        match self {
            Self::SharedHandler => Some(1),
            Self::BatchSharded => batches.checked_mul(SIGNAL_HANDLERS_PER_BATCH),
            Self::Ws5Strategy20 => Some(batches),
        }
    }

    fn account_receivers_per_batch(self) -> usize {
        match self {
            Self::SharedHandler => 1,
            Self::BatchSharded => SIGNAL_HANDLERS_PER_BATCH,
            Self::Ws5Strategy20 => WS5_STRATEGY20_PUBLIC_WS_TASKS,
        }
    }

    fn fanout_domains(self, tasks: usize) -> usize {
        match self {
            Self::SharedHandler | Self::BatchSharded => tasks,
            Self::Ws5Strategy20 => 1,
        }
    }

    fn venue_handlers(self, tasks: usize) -> usize {
        match self {
            Self::SharedHandler | Self::Ws5Strategy20 => 1,
            Self::BatchSharded => tasks,
        }
    }

    fn account_owner_handlers(self, tasks: usize) -> usize {
        match self {
            Self::SharedHandler | Self::Ws5Strategy20 => 1,
            Self::BatchSharded => tasks,
        }
    }

    fn order_runners(self, tasks: usize) -> usize {
        match self {
            Self::SharedHandler | Self::BatchSharded => tasks,
            Self::Ws5Strategy20 => 1,
        }
    }

    fn batch_count(self, tasks: usize) -> usize {
        match self {
            Self::SharedHandler | Self::Ws5Strategy20 => 1,
            Self::BatchSharded => tasks,
        }
    }

    fn public_ws_tasks_per_fanout_domain(self) -> usize {
        match self {
            Self::SharedHandler => 1,
            Self::BatchSharded => BATCH_TRADE_LANES,
            Self::Ws5Strategy20 => WS5_STRATEGY20_PUBLIC_WS_TASKS,
        }
    }

    fn symbols_per_public_ws(self, instruments_per_task: usize) -> usize {
        match self {
            Self::SharedHandler | Self::Ws5Strategy20 => instruments_per_task,
            Self::BatchSharded => 1,
        }
    }

    fn symbols_per_signal_handler(self, tasks: usize, instruments_per_task: usize) -> usize {
        match self {
            Self::SharedHandler => tasks.saturating_mul(instruments_per_task),
            Self::BatchSharded => TRADE_LANES_PER_SIGNAL_HANDLER,
            Self::Ws5Strategy20 => instruments_per_task,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct LivePipelineConfig {
    pub tasks: usize,
    pub instruments_per_task: usize,
    pub messages_per_instrument: usize,
    pub mode: LiveMode,
    pub order_every: usize,
    pub signal_compute_ns: u64,
    pub reject_every: usize,
    pub scenario: LiveScenario,
    pub topology: LiveTopology,
}

impl Default for LivePipelineConfig {
    fn default() -> Self {
        Self {
            tasks: 5,
            instruments_per_task: 20,
            messages_per_instrument: 256,
            mode: LiveMode::Stress,
            order_every: 20,
            signal_compute_ns: 0,
            reject_every: 10,
            scenario: LiveScenario::Success,
            topology: LiveTopology::SharedHandler,
        }
    }
}

impl LivePipelineConfig {
    fn validate(self) -> InfraResult<()> {
        for (name, value) in [
            ("LIVE_TASKS", self.tasks),
            ("LIVE_INSTRUMENTS_PER_TASK", self.instruments_per_task),
            ("LIVE_MESSAGES_PER_INSTRUMENT", self.messages_per_instrument),
            ("LIVE_ORDER_EVERY", self.order_every),
            ("LIVE_REJECT_EVERY", self.reject_every),
        ] {
            if value == 0 {
                return Err(InfraError::Msg(format!("{name} must be greater than zero")));
            }
        }
        if self.topology == LiveTopology::BatchSharded
            && self.instruments_per_task != BATCH_TRADE_LANES
        {
            return Err(InfraError::Msg(format!(
                "batch_sharded topology requires LIVE_INSTRUMENTS_PER_TASK={BATCH_TRADE_LANES}"
            )));
        }
        if self.topology == LiveTopology::Ws5Strategy20
            && self.tasks != WS5_STRATEGY20_PUBLIC_WS_TASKS
        {
            return Err(InfraError::Msg(format!(
                "ws5_strategy20 topology requires LIVE_TASKS={WS5_STRATEGY20_PUBLIC_WS_TASKS}"
            )));
        }
        if self.topology == LiveTopology::Ws5Strategy20
            && self.instruments_per_task != WS5_STRATEGY20_SYMBOLS_PER_WS
        {
            return Err(InfraError::Msg(format!(
                "ws5_strategy20 topology requires LIVE_INSTRUMENTS_PER_TASK={WS5_STRATEGY20_SYMBOLS_PER_WS}"
            )));
        }
        self.topology
            .producer_tasks(self.tasks)
            .ok_or_else(|| InfraError::Msg("live pipeline producer count overflow usize".into()))?;
        self.topology.signal_handlers(self.tasks).ok_or_else(|| {
            InfraError::Msg("live pipeline signal handler count overflow usize".into())
        })?;
        Ok(())
    }
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct LivePipelineReport {
    pub framework: &'static str,
    pub mode: &'static str,
    pub scenario: &'static str,
    pub topology: &'static str,
    pub tasks: usize,
    pub instruments_per_task: usize,
    pub messages_per_instrument: usize,
    pub order_every: usize,
    pub signal_compute_ns: u64,
    pub reject_every: usize,
    pub batch_count: usize,
    pub public_ws_tasks: usize,
    pub public_ws_tasks_per_fanout_domain: usize,
    pub symbols_per_public_ws: usize,
    pub symbols_per_signal_handler: usize,
    pub producer_tasks: usize,
    pub trade_ingress_lanes: usize,
    pub trade_task_keys: usize,
    pub public_cooperative_yields: u64,
    pub account_broadcast_rings: usize,
    pub account_broadcast_topics: usize,
    pub account_fanout_domains: usize,
    pub signal_handlers: usize,
    pub trade_lanes_per_signal_handler: usize,
    pub account_receivers_per_ring: usize,
    pub account_handlers_per_fanout_domain: usize,
    pub venue_handlers: usize,
    pub account_ingress_tasks: usize,
    pub account_ingress_lanes: usize,
    pub private_ingress_capacity: usize,
    pub trade_broadcast_capacity: usize,
    pub order_execution_broadcast_capacity: usize,
    pub account_order_broadcast_capacity: usize,
    pub account_owner_handlers: usize,
    pub order_runners: usize,
    pub total_ticks: u64,
    pub expected_orders: u64,
    pub expected_fills: u64,
    pub expected_business_errors: u64,
    pub ticks_sent: u64,
    pub public_parsed: u64,
    pub trade_callbacks: u64,
    pub signal_compute_calls: u64,
    pub strategy_signals: u64,
    pub orders_submitted: u64,
    pub orders_relayed: u64,
    pub order_endpoint_calls: u64,
    pub private_frames_parsed: u64,
    pub expected_private_fanout_callbacks: u64,
    pub private_fanout_callbacks: u64,
    pub account_observation_callbacks: u64,
    pub native_owner_callbacks: u64,
    pub account_non_owner_callbacks: u64,
    pub acks: u64,
    pub fills: u64,
    pub terminal_callbacks: u64,
    pub broadcast_lagged: u64,
    pub drops: u64,
    pub duplicates: u64,
    pub missing_correlations: u64,
    pub route_errors: u64,
    pub cross_batch_errors: u64,
    pub business_errors: u64,
    pub max_in_flight: u64,
    pub ending_in_flight: u64,
    pub per_task_sent_min: u64,
    pub per_task_sent_max: u64,
    pub per_task_completed_min: u64,
    pub per_task_completed_max: u64,
    pub per_signal_trade_callbacks_min: u64,
    pub per_signal_trade_callbacks_max: u64,
    pub per_signal_private_callbacks_min: u64,
    pub per_signal_private_callbacks_max: u64,
    pub wall_elapsed_ns: u64,
    pub wall_throughput_ticks_s: f64,
    pub public_decode_samples: u64,
    pub public_decode_p50_ns: u64,
    pub public_decode_p95_ns: u64,
    pub public_decode_p99_ns: u64,
    pub public_decode_max_ns: u64,
    pub tick_to_order_samples: u64,
    pub tick_to_order_p50_ns: u64,
    pub tick_to_order_p95_ns: u64,
    pub tick_to_order_p99_ns: u64,
    pub tick_to_order_max_ns: u64,
    pub tick_to_ack_samples: u64,
    pub tick_to_ack_p50_ns: u64,
    pub tick_to_ack_p95_ns: u64,
    pub tick_to_ack_p99_ns: u64,
    pub tick_to_ack_max_ns: u64,
    pub tick_to_fill_samples: u64,
    pub tick_to_fill_p50_ns: u64,
    pub tick_to_fill_p95_ns: u64,
    pub tick_to_fill_p99_ns: u64,
    pub tick_to_fill_max_ns: u64,
    pub public_decoder: &'static str,
    pub private_decoder: &'static str,
    pub public_ingress_model: &'static str,
    pub private_ingress_model: &'static str,
    pub signal_handler_model: &'static str,
    pub handler_kind: &'static str,
    pub batch_isolation_model: &'static str,
    pub private_fanout_model: &'static str,
    pub account_owner_selection_model: &'static str,
    pub broadcast_lag_observable: bool,
    pub overflow_model: &'static str,
    pub benchmark_local_decode_bridge: bool,
}

#[derive(Clone, Debug)]
struct RawPublicFrame {
    global_index: usize,
    payload: Vec<u8>,
}

#[derive(Clone, Debug)]
struct PrivateFrames {
    ack: Option<Arc<Vec<u8>>>,
    terminal: Arc<Vec<u8>>,
}

#[derive(Clone, Debug)]
struct RawPrivateFrame {
    global_index: usize,
    payload: Arc<Vec<u8>>,
}

#[derive(Clone, Debug)]
struct TickExpectation {
    task_index: usize,
    instrument_index: usize,
    trade_task_id: u64,
    order_task_id: u64,
    account_task_id: u64,
    symbol: String,
    instrument: String,
    timestamp_micros: u64,
    price: f64,
    price_text: String,
    side: OrderSide,
    should_order: bool,
    should_reject: bool,
    client_order_id: Option<String>,
}

#[derive(Debug)]
struct Fixture {
    public_frames: Vec<Vec<RawPublicFrame>>,
    private_frames: Vec<Option<PrivateFrames>>,
    expected: Vec<TickExpectation>,
    ticks_per_task: usize,
    ticks_per_producer: usize,
    producer_tasks: usize,
    expected_private_frames_by_task: Vec<usize>,
    expected_private_fanout_callbacks: usize,
    expected_orders: usize,
    expected_fills: usize,
    expected_business_errors: usize,
}

impl Fixture {
    fn build(config: LivePipelineConfig) -> InfraResult<Self> {
        config.validate()?;
        let ticks_per_task = config
            .instruments_per_task
            .checked_mul(config.messages_per_instrument)
            .ok_or_else(|| InfraError::Msg("ticks per task overflow usize".into()))?;
        let total_ticks = config
            .tasks
            .checked_mul(ticks_per_task)
            .ok_or_else(|| InfraError::Msg("total tick count overflow usize".into()))?;
        let producer_tasks = config
            .topology
            .producer_tasks(config.tasks)
            .ok_or_else(|| InfraError::Msg("live pipeline producer count overflow usize".into()))?;
        let ticks_per_producer = match config.topology {
            LiveTopology::SharedHandler | LiveTopology::Ws5Strategy20 => ticks_per_task,
            LiveTopology::BatchSharded => config.messages_per_instrument,
        };
        let max_index = u64::try_from(total_ticks - 1)
            .map_err(|_| InfraError::Msg("tick correlation exceeds u64".into()))?;
        PUBLIC_TIME_BASE_MS
            .checked_add(max_index)
            .and_then(|value| value.checked_mul(1_000))
            .ok_or_else(|| InfraError::Msg("public fixture timestamp overflow".into()))?;
        PRIVATE_TIME_BASE_MS
            .checked_add(max_index.saturating_mul(2))
            .and_then(|value| value.checked_add(1))
            .ok_or_else(|| InfraError::Msg("private fixture timestamp overflow".into()))?;

        let mut public_frames = (0..producer_tasks)
            .map(|_| Vec::with_capacity(ticks_per_producer))
            .collect::<Vec<_>>();
        let mut expected = Vec::with_capacity(total_ticks);
        let mut private_frames = vec![None; total_ticks];
        let mut expected_private_frames_by_task = vec![0usize; config.tasks];
        let mut expected_orders = 0usize;
        let mut expected_fills = 0usize;
        let mut expected_business_errors = 0usize;

        for (task_index, expected_private_frames_for_task) in
            expected_private_frames_by_task.iter_mut().enumerate()
        {
            for message_index in 0..config.messages_per_instrument {
                for instrument_index in 0..config.instruments_per_task {
                    let global_index = task_index * ticks_per_task
                        + message_index * config.instruments_per_task
                        + instrument_index;
                    let symbol = format!("T{task_index:03}I{instrument_index:03}USDT");
                    let instrument = binance_fut_inst_to_cli(&symbol);
                    let timestamp_ms = PUBLIC_TIME_BASE_MS + global_index as u64;
                    let timestamp_micros = timestamp_ms * 1_000;
                    let price_text = format!("{:.2}", 10_000.0 + global_index as f64 * 0.01);
                    let price = price_text
                        .parse::<f64>()
                        .expect("generated public fixture price is valid");
                    let side = if message_index.is_multiple_of(2) {
                        OrderSide::BUY
                    } else {
                        OrderSide::SELL
                    };
                    let should_order = match config.mode {
                        LiveMode::Stress => true,
                        LiveMode::MixedLive => {
                            (message_index + 1).is_multiple_of(config.order_every)
                        },
                    };
                    let should_reject = should_order
                        && config.scenario == LiveScenario::BusinessError
                        && expected_orders.is_multiple_of(config.reject_every);
                    let client_order_id =
                        should_order.then(|| format!("{CID_PREFIX}{global_index}"));
                    let trade_task_id = match config.topology {
                        LiveTopology::SharedHandler | LiveTopology::Ws5Strategy20 => {
                            batch_task_id(task_index)
                        },
                        LiveTopology::BatchSharded => {
                            trade_lane_task_id(task_index, instrument_index)
                        },
                    };
                    let (order_task_id, account_task_id) = match config.topology {
                        LiveTopology::SharedHandler | LiveTopology::BatchSharded => {
                            (batch_task_id(task_index), batch_task_id(task_index))
                        },
                        LiveTopology::Ws5Strategy20 => (batch_task_id(0), batch_task_id(0)),
                    };
                    let expectation = TickExpectation {
                        task_index,
                        instrument_index,
                        trade_task_id,
                        order_task_id,
                        account_task_id,
                        symbol,
                        instrument,
                        timestamp_micros,
                        price,
                        price_text,
                        side,
                        should_order,
                        should_reject,
                        client_order_id,
                    };
                    let payload = build_public_frame(global_index, &expectation)?;

                    if should_order {
                        expected_orders += 1;
                        if should_reject {
                            expected_business_errors += 1;
                        } else {
                            expected_fills += 1;
                        }
                        let frames = build_private_frames(global_index, &expectation)?;
                        *expected_private_frames_for_task += usize::from(frames.ack.is_some()) + 1;
                        private_frames[global_index] = Some(frames);
                    }
                    let producer_index = match config.topology {
                        LiveTopology::SharedHandler | LiveTopology::Ws5Strategy20 => task_index,
                        LiveTopology::BatchSharded => {
                            task_index * BATCH_TRADE_LANES + instrument_index
                        },
                    };
                    public_frames[producer_index].push(RawPublicFrame {
                        global_index,
                        payload,
                    });
                    expected.push(expectation);
                }
            }
        }

        let expected_private_fanout_callbacks = expected_private_frames_by_task
            .iter()
            .sum::<usize>()
            .checked_mul(config.topology.account_receivers_per_batch())
            .ok_or_else(|| {
                InfraError::Msg("private fan-out callback count overflow usize".into())
            })?;

        Ok(Self {
            public_frames,
            private_frames,
            expected,
            ticks_per_task,
            ticks_per_producer,
            producer_tasks,
            expected_private_frames_by_task,
            expected_private_fanout_callbacks,
            expected_orders,
            expected_fills,
            expected_business_errors,
        })
    }
}

fn build_public_frame(index: usize, expected: &TickExpectation) -> InfraResult<Vec<u8>> {
    let timestamp_ms = expected.timestamp_micros / 1_000;
    serde_json::to_vec(&json!({
        "e": "aggTrade",
        "E": timestamp_ms,
        "s": expected.symbol.as_str(),
        "a": index as u64,
        "p": expected.price_text.as_str(),
        "q": ORDER_SIZE,
        "f": index as u64,
        "l": index as u64,
        "T": timestamp_ms,
        "m": matches!(expected.side, OrderSide::SELL)
    }))
    .map_err(|error| InfraError::Msg(format!("failed to build public fixture: {error}")))
}

fn build_private_frames(index: usize, expected: &TickExpectation) -> InfraResult<PrivateFrames> {
    let (ack, terminal) = if expected.should_reject {
        (
            None,
            Arc::new(build_private_frame(
                index, expected, "REJECTED", "REJECTED", false,
            )?),
        )
    } else {
        (
            Some(Arc::new(build_private_frame(
                index, expected, "NEW", "NEW", false,
            )?)),
            Arc::new(build_private_frame(
                index, expected, "TRADE", "FILLED", true,
            )?),
        )
    };
    Ok(PrivateFrames { ack, terminal })
}

fn build_private_frame(
    index: usize,
    expected: &TickExpectation,
    execution_type: &str,
    status: &str,
    filled: bool,
) -> InfraResult<Vec<u8>> {
    let event_time = PRIVATE_TIME_BASE_MS + index as u64 * 2 + u64::from(status != "NEW");
    let side = match expected.side {
        OrderSide::BUY => "BUY",
        OrderSide::SELL => "SELL",
        OrderSide::Unknown => "UNKNOWN",
    };
    let filled_quantity = if filled { ORDER_SIZE } else { "0" };
    let fill_price = if filled {
        expected.price_text.as_str()
    } else {
        "0"
    };
    let client_order_id = expected
        .client_order_id
        .as_deref()
        .expect("private fixtures are only generated for expected orders");

    serde_json::to_vec(&json!({
        "e": "ORDER_TRADE_UPDATE",
        "E": event_time,
        "T": event_time,
        "o": {
            "s": expected.symbol.as_str(),
            "c": client_order_id,
            "S": side,
            "o": "MARKET",
            "f": "GTC",
            "q": ORDER_SIZE,
            "p": "0",
            "ap": fill_price,
            "sp": "0",
            "x": execution_type,
            "X": status,
            "i": 10_000_000_u64 + index as u64,
            "l": filled_quantity,
            "z": filled_quantity,
            "L": fill_price,
            "N": null,
            "n": null,
            "T": event_time,
            "t": 20_000_000_u64 + index as u64,
            "b": "0",
            "a": "0",
            "m": false,
            "R": false,
            "wt": "CONTRACT_PRICE",
            "ot": "MARKET",
            "ps": "BOTH",
            "cp": false,
            "AP": null,
            "cr": null,
            "pP": false,
            "rp": "0",
            "V": "NONE",
            "pm": "NONE",
            "gtd": 0,
            "er": "0"
        }
    }))
    .map_err(|error| InfraError::Msg(format!("failed to build private fixture: {error}")))
}

struct TimingState {
    origin: Instant,
    phase_start_ns: AtomicU64,
    last_trade_callback_completed_ns: AtomicU64,
    last_terminal_callback_ns: AtomicU64,
    last_private_fanout_callback_ns: AtomicU64,
    t0: Vec<AtomicU64>,
    t_public: Vec<AtomicU64>,
    t_order: Vec<AtomicU64>,
    t_ack: Vec<AtomicU64>,
    t_fill: Vec<AtomicU64>,
    public_seen: Vec<AtomicU8>,
    trade_seen: Vec<AtomicU8>,
    order_seen: Vec<AtomicU8>,
    ack_seen: Vec<AtomicU8>,
    terminal_seen: Vec<AtomicU8>,
    ack_fanout_seen: Vec<AtomicU32>,
    terminal_fanout_seen: Vec<AtomicU32>,
}

impl TimingState {
    fn new(total_ticks: usize) -> Self {
        Self {
            origin: Instant::now(),
            phase_start_ns: AtomicU64::new(0),
            last_trade_callback_completed_ns: AtomicU64::new(0),
            last_terminal_callback_ns: AtomicU64::new(0),
            last_private_fanout_callback_ns: AtomicU64::new(0),
            t0: atomic_u64_slots(total_ticks),
            t_public: atomic_u64_slots(total_ticks),
            t_order: atomic_u64_slots(total_ticks),
            t_ack: atomic_u64_slots(total_ticks),
            t_fill: atomic_u64_slots(total_ticks),
            public_seen: atomic_u8_slots(total_ticks),
            trade_seen: atomic_u8_slots(total_ticks),
            order_seen: atomic_u8_slots(total_ticks),
            ack_seen: atomic_u8_slots(total_ticks),
            terminal_seen: atomic_u8_slots(total_ticks),
            ack_fanout_seen: atomic_u32_slots(total_ticks),
            terminal_fanout_seen: atomic_u32_slots(total_ticks),
        }
    }

    fn now_ns(&self) -> u64 {
        u64::try_from(self.origin.elapsed().as_nanos())
            .unwrap_or(u64::MAX - 1)
            .saturating_add(1)
    }
}

fn atomic_u64_slots(len: usize) -> Vec<AtomicU64> {
    (0..len).map(|_| AtomicU64::new(0)).collect()
}

fn atomic_u8_slots(len: usize) -> Vec<AtomicU8> {
    (0..len).map(|_| AtomicU8::new(0)).collect()
}

fn atomic_u32_slots(len: usize) -> Vec<AtomicU32> {
    (0..len).map(|_| AtomicU32::new(0)).collect()
}

struct Counters {
    ticks_sent: AtomicU64,
    public_cooperative_yields: AtomicU64,
    public_parsed: AtomicU64,
    trade_callbacks: AtomicU64,
    signal_compute_calls: AtomicU64,
    strategy_signals: AtomicU64,
    orders_submitted: AtomicU64,
    orders_relayed: Arc<AtomicU64>,
    order_endpoint_calls: AtomicU64,
    private_frames_parsed: AtomicU64,
    private_fanout_callbacks: AtomicU64,
    acks: AtomicU64,
    fills: AtomicU64,
    terminal_callbacks: AtomicU64,
    broadcast_lagged: AtomicU64,
    first_broadcast_lag: Mutex<Option<String>>,
    drops: AtomicU64,
    duplicates: AtomicU64,
    route_errors: AtomicU64,
    cross_batch_errors: AtomicU64,
    business_errors: AtomicU64,
    in_flight: AtomicU64,
    max_in_flight: AtomicU64,
    runner_failures: Arc<AtomicU64>,
    sent_by_task: Vec<AtomicU64>,
    completed_by_task: Vec<AtomicU64>,
    trade_callbacks_by_signal_handler: Vec<AtomicU64>,
    private_callbacks_by_signal_handler: Vec<AtomicU64>,
}

impl Counters {
    fn new(config: LivePipelineConfig) -> Self {
        let signal_handlers = config
            .topology
            .signal_handlers(config.tasks)
            .expect("validated live pipeline signal handler count");
        Self {
            ticks_sent: AtomicU64::new(0),
            public_cooperative_yields: AtomicU64::new(0),
            public_parsed: AtomicU64::new(0),
            trade_callbacks: AtomicU64::new(0),
            signal_compute_calls: AtomicU64::new(0),
            strategy_signals: AtomicU64::new(0),
            orders_submitted: AtomicU64::new(0),
            orders_relayed: Arc::new(AtomicU64::new(0)),
            order_endpoint_calls: AtomicU64::new(0),
            private_frames_parsed: AtomicU64::new(0),
            private_fanout_callbacks: AtomicU64::new(0),
            acks: AtomicU64::new(0),
            fills: AtomicU64::new(0),
            terminal_callbacks: AtomicU64::new(0),
            broadcast_lagged: AtomicU64::new(0),
            first_broadcast_lag: Mutex::new(None),
            drops: AtomicU64::new(0),
            duplicates: AtomicU64::new(0),
            route_errors: AtomicU64::new(0),
            cross_batch_errors: AtomicU64::new(0),
            business_errors: AtomicU64::new(0),
            in_flight: AtomicU64::new(0),
            max_in_flight: AtomicU64::new(0),
            runner_failures: Arc::new(AtomicU64::new(0)),
            sent_by_task: atomic_u64_slots(config.tasks),
            completed_by_task: atomic_u64_slots(config.tasks),
            trade_callbacks_by_signal_handler: atomic_u64_slots(signal_handlers),
            private_callbacks_by_signal_handler: atomic_u64_slots(signal_handlers),
        }
    }

    fn record_broadcast_lag(&self, key: &TaskKey, skipped: u64, completion: &Notify) {
        self.broadcast_lagged.fetch_add(skipped, Ordering::AcqRel);
        let mut first = self
            .first_broadcast_lag
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        if first.is_none() {
            *first = Some(format!("{key:?}: skipped={skipped}"));
        }
        drop(first);
        completion.notify_one();
    }

    fn first_broadcast_lag(&self) -> String {
        self.first_broadcast_lag
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .clone()
            .unwrap_or_else(|| "unknown task key".into())
    }
}

#[derive(Clone, Copy, Debug, Default)]
struct LatencySummary {
    samples: u64,
    p50_ns: u64,
    p95_ns: u64,
    p99_ns: u64,
    max_ns: u64,
}

fn summarize_latencies(mut values: Vec<u64>) -> LatencySummary {
    values.sort_unstable();
    LatencySummary {
        samples: values.len() as u64,
        p50_ns: percentile(&values, 50),
        p95_ns: percentile(&values, 95),
        p99_ns: percentile(&values, 99),
        max_ns: values.last().copied().unwrap_or(0),
    }
}

fn percentile(sorted: &[u64], percentile: usize) -> u64 {
    if sorted.is_empty() {
        return 0;
    }
    let rank = (percentile.min(100) * sorted.len()).div_ceil(100).max(1);
    sorted[rank - 1]
}

fn batch_task_id(task_index: usize) -> u64 {
    TASK_ID_BASE + task_index as u64
}

fn trade_lane_task_id(task_index: usize, instrument_index: usize) -> u64 {
    TRADE_LANE_TASK_ID_BASE + (task_index * BATCH_TRADE_LANES + instrument_index) as u64
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum SignalBinding {
    Shared {
        counter_index: usize,
    },
    Batch {
        batch_index: usize,
        handler_index: usize,
        counter_index: usize,
    },
    Ws5Strategy20 {
        task_index: usize,
        counter_index: usize,
    },
}

impl SignalBinding {
    fn counter_index(self) -> usize {
        match self {
            Self::Shared { counter_index }
            | Self::Batch { counter_index, .. }
            | Self::Ws5Strategy20 { counter_index, .. } => counter_index,
        }
    }
}

#[derive(Debug)]
struct SignalHandlerPlan {
    binding: SignalBinding,
    trade_key_indices: Vec<usize>,
    account_key_index: Option<usize>,
}

#[derive(Debug)]
struct TopologyPlan {
    trade_keys: Vec<TaskKey>,
    order_keys: Vec<TaskKey>,
    account_keys: Vec<TaskKey>,
    signal_handlers: Vec<SignalHandlerPlan>,
}

impl TopologyPlan {
    fn build(config: LivePipelineConfig) -> InfraResult<Self> {
        config.validate()?;
        let trade_keys: Vec<TaskKey> = match config.topology {
            LiveTopology::SharedHandler | LiveTopology::Ws5Strategy20 => (0..config.tasks)
                .map(|batch| TaskKey::ws(&WsChannel::Trades(None), batch_task_id(batch)))
                .collect(),
            LiveTopology::BatchSharded => (0..config.tasks)
                .flat_map(|batch| {
                    (0..BATCH_TRADE_LANES).map(move |lane| {
                        TaskKey::ws(&WsChannel::Trades(None), trade_lane_task_id(batch, lane))
                    })
                })
                .collect(),
        };
        let order_keys = (0..config.topology.order_runners(config.tasks))
            .map(|batch| TaskKey::alt(&AltTaskType::OrderExecution, batch_task_id(batch)))
            .collect::<Vec<_>>();
        let account_keys = (0..config.topology.fanout_domains(config.tasks))
            .map(|batch| TaskKey::ws(&WsChannel::AccountOrders, batch_task_id(batch)))
            .collect::<Vec<_>>();
        let signal_handlers = match config.topology {
            LiveTopology::SharedHandler => vec![SignalHandlerPlan {
                binding: SignalBinding::Shared { counter_index: 0 },
                trade_key_indices: (0..trade_keys.len()).collect(),
                account_key_index: None,
            }],
            LiveTopology::BatchSharded => {
                let mut handlers = Vec::with_capacity(config.tasks * SIGNAL_HANDLERS_PER_BATCH);
                for batch_index in 0..config.tasks {
                    for handler_index in 0..SIGNAL_HANDLERS_PER_BATCH {
                        let first_lane = batch_index * BATCH_TRADE_LANES
                            + handler_index * TRADE_LANES_PER_SIGNAL_HANDLER;
                        handlers.push(SignalHandlerPlan {
                            binding: SignalBinding::Batch {
                                batch_index,
                                handler_index,
                                counter_index: handlers.len(),
                            },
                            trade_key_indices: (first_lane
                                ..first_lane + TRADE_LANES_PER_SIGNAL_HANDLER)
                                .collect(),
                            account_key_index: Some(batch_index),
                        });
                    }
                }
                handlers
            },
            LiveTopology::Ws5Strategy20 => (0..config.tasks)
                .map(|task_index| SignalHandlerPlan {
                    binding: SignalBinding::Ws5Strategy20 {
                        task_index,
                        counter_index: task_index,
                    },
                    trade_key_indices: vec![task_index],
                    account_key_index: Some(0),
                })
                .collect(),
        };

        Ok(Self {
            trade_keys,
            order_keys,
            account_keys,
            signal_handlers,
        })
    }

    fn runtime_tasks(&self, topology: LiveTopology) -> usize {
        match topology {
            LiveTopology::SharedHandler => {
                self.signal_handlers.len() + 2 + self.order_keys.len() * 2
            },
            LiveTopology::BatchSharded => self.signal_handlers.len() + self.order_keys.len() * 3,
            LiveTopology::Ws5Strategy20 => self.signal_handlers.len() + 3,
        }
    }
}

fn parse_correlation(client_order_id: &str) -> Option<usize> {
    client_order_id.strip_prefix(CID_PREFIX)?.parse().ok()
}

fn mark_once(slot: &AtomicU8, counters: &Counters) -> bool {
    if slot.swap(1, Ordering::AcqRel) == 0 {
        true
    } else {
        counters.duplicates.fetch_add(1, Ordering::Relaxed);
        false
    }
}

fn route_error(counters: &Counters) {
    counters.route_errors.fetch_add(1, Ordering::Relaxed);
}

fn cross_batch_error(counters: &Counters) {
    counters.cross_batch_errors.fetch_add(1, Ordering::Relaxed);
    route_error(counters);
}

fn validate_account_event(
    msg: &InfraMsg<Vec<WsAccOrder>>,
    fixture: &Fixture,
    counters: &Counters,
    expected_batch: Option<usize>,
) -> Option<usize> {
    let Some(order) = msg.data.first() else {
        route_error(counters);
        return None;
    };
    if msg.data.len() != 1 {
        route_error(counters);
        return None;
    }
    let Some(client_order_id) = order.cli_order_id.as_deref() else {
        route_error(counters);
        return None;
    };
    let Some(global_index) = parse_correlation(client_order_id) else {
        route_error(counters);
        return None;
    };
    let Some(expected) = fixture.expected.get(global_index) else {
        route_error(counters);
        return None;
    };
    if expected_batch.is_some_and(|batch| batch != expected.task_index) {
        cross_batch_error(counters);
        return None;
    }
    let status_matches = match order.status {
        OrderStatus::Live => !expected.should_reject,
        OrderStatus::Filled => {
            !expected.should_reject
                && order.filled_size == ORDER_SIZE_F64
                && order.price == expected.price
        },
        OrderStatus::Rejected => expected.should_reject,
        _ => false,
    };
    if msg.task_id != expected.account_task_id
        || !expected.should_order
        || order.market != Market::BinanceUmFutures
        || order.inst != expected.instrument
        || order.side != expected.side
        || order.size != ORDER_SIZE_F64
        || order.order_type != OrderType::Market
        || expected.client_order_id.as_deref() != Some(client_order_id)
        || !status_matches
    {
        route_error(counters);
        return None;
    }
    Some(global_index)
}

fn mark_private_delivery(
    global_index: usize,
    status: OrderStatus,
    receiver_index: usize,
    counters: &Counters,
    timing: &TimingState,
) -> bool {
    let seen = match status {
        OrderStatus::Live => &timing.ack_fanout_seen[global_index],
        OrderStatus::Filled | OrderStatus::Rejected => &timing.terminal_fanout_seen[global_index],
        _ => {
            route_error(counters);
            return false;
        },
    };
    let Some(bit) = 1_u32.checked_shl(receiver_index as u32) else {
        route_error(counters);
        return false;
    };
    if seen.fetch_or(bit, Ordering::AcqRel) & bit != 0 {
        counters.duplicates.fetch_add(1, Ordering::Relaxed);
        return false;
    }

    true
}

fn finish_private_delivery(
    signal_counter_index: Option<usize>,
    fixture: &Fixture,
    counters: &Counters,
    timing: &TimingState,
    completion: &Notify,
) {
    if let Some(counter_index) = signal_counter_index {
        counters.private_callbacks_by_signal_handler[counter_index].fetch_add(1, Ordering::Relaxed);
    }
    let completed_ns = timing.now_ns();
    timing
        .last_private_fanout_callback_ns
        .fetch_max(completed_ns, Ordering::Relaxed);
    let callbacks = counters
        .private_fanout_callbacks
        .fetch_add(1, Ordering::AcqRel)
        + 1;
    if callbacks == fixture.expected_private_fanout_callbacks as u64 {
        completion.notify_one();
    }
}

#[derive(Clone)]
struct TradeStrategy {
    registry: Arc<CommandRegistry>,
    fixture: Arc<Fixture>,
    counters: Arc<Counters>,
    timing: Arc<TimingState>,
    completion: Arc<Notify>,
    binding: SignalBinding,
    signal_compute_ns: u64,
}

impl Strategy for TradeStrategy {
    async fn initialize(&mut self) {}
}

impl CommandEmitter for TradeStrategy {
    fn command_init(&mut self, registry: Arc<CommandRegistry>) {
        self.registry = registry;
    }

    fn command_registry(&self) -> Arc<CommandRegistry> {
        Arc::clone(&self.registry)
    }
}

impl TradeStrategy {
    #[inline]
    fn run_signal_compute(&self) {
        if self.signal_compute_ns != 0 {
            let started = Instant::now();
            let duration = Duration::from_nanos(self.signal_compute_ns);
            while started.elapsed() < duration {
                std::hint::spin_loop();
            }
        }
        self.counters
            .signal_compute_calls
            .fetch_add(1, Ordering::Relaxed);
    }

    async fn process_trade(&self, msg: InfraMsg<Vec<WsTrade>>) {
        let Some(trade) = msg.data.first() else {
            route_error(&self.counters);
            return;
        };
        if msg.data.len() != 1 {
            route_error(&self.counters);
            return;
        }
        let Ok(global_index) = usize::try_from(trade.trade_id) else {
            route_error(&self.counters);
            return;
        };
        let Some(expected) = self.fixture.expected.get(global_index) else {
            route_error(&self.counters);
            return;
        };
        if !mark_once(&self.timing.trade_seen[global_index], &self.counters) {
            return;
        }
        let handler_binding_matches = match self.binding {
            SignalBinding::Shared { .. } => true,
            SignalBinding::Batch {
                batch_index,
                handler_index,
                ..
            } => {
                if expected.task_index != batch_index {
                    cross_batch_error(&self.counters);
                    return;
                }
                expected.instrument_index / TRADE_LANES_PER_SIGNAL_HANDLER == handler_index
            },
            SignalBinding::Ws5Strategy20 { task_index, .. } => {
                if expected.task_index != task_index {
                    cross_batch_error(&self.counters);
                    return;
                }
                true
            },
        };
        if !handler_binding_matches
            || msg.task_id != expected.trade_task_id
            || trade.market != Market::BinanceUmFutures
            || trade.inst != expected.instrument
            || trade.timestamp != expected.timestamp_micros
            || trade.price != expected.price
            || trade.size != ORDER_SIZE_F64
            || trade.side != expected.side
        {
            route_error(&self.counters);
            return;
        }

        self.run_signal_compute();
        if !expected.should_order {
            self.counters.completed_by_task[expected.task_index].fetch_add(1, Ordering::Relaxed);
            return;
        }
        self.counters
            .strategy_signals
            .fetch_add(1, Ordering::Relaxed);

        let Some(handle) = self
            .registry
            .find_alt_handle(&AltTaskType::OrderExecution, expected.order_task_id)
        else {
            route_error(&self.counters);
            return;
        };
        let order = AltOrder {
            timestamp: trade.timestamp,
            market: trade.market.clone(),
            order_params: OrderParams {
                inst: trade.inst.clone(),
                side: trade.side.clone(),
                size: ORDER_SIZE.into(),
                order_type: OrderType::Market,
                client_order_id: expected.client_order_id.clone(),
                ..Default::default()
            },
            metadata: HashMap::new(),
        };

        if handle
            .send_command(TaskCommand::OrderExecute(vec![order]), None)
            .await
            .is_ok()
        {
            self.counters
                .orders_submitted
                .fetch_add(1, Ordering::Relaxed);
        } else {
            self.counters.drops.fetch_add(1, Ordering::Relaxed);
        }
    }
}

impl EventHandler for TradeStrategy {
    async fn on_trade(&mut self, msg: InfraMsg<Vec<WsTrade>>) {
        self.process_trade(msg).await;
        self.counters.trade_callbacks_by_signal_handler[self.binding.counter_index()]
            .fetch_add(1, Ordering::Relaxed);
        self.timing
            .last_trade_callback_completed_ns
            .fetch_max(self.timing.now_ns(), Ordering::Relaxed);
        let callbacks = self.counters.trade_callbacks.fetch_add(1, Ordering::AcqRel) + 1;
        if callbacks == self.fixture.expected.len() as u64 {
            self.completion.notify_one();
        }
    }

    async fn on_acc_order(&mut self, msg: InfraMsg<Vec<WsAccOrder>>) {
        let callback_ns = self.timing.now_ns();
        let (expected_batch, receiver_index, counter_index, canonical) = match self.binding {
            SignalBinding::Batch {
                batch_index,
                handler_index,
                counter_index,
            } => (
                Some(batch_index),
                handler_index,
                counter_index,
                handler_index == 0,
            ),
            SignalBinding::Ws5Strategy20 {
                task_index,
                counter_index,
            } => (None, task_index, counter_index, task_index == 0),
            SignalBinding::Shared { .. } => {
                route_error(&self.counters);
                return;
            },
        };
        let Some(global_index) =
            validate_account_event(&msg, &self.fixture, &self.counters, expected_batch)
        else {
            return;
        };

        if !mark_private_delivery(
            global_index,
            msg.data[0].status.clone(),
            receiver_index,
            &self.counters,
            &self.timing,
        ) {
            return;
        }
        if canonical {
            process_canonical_account(
                global_index,
                &msg.data[0],
                callback_ns,
                &self.fixture,
                &self.counters,
                &self.timing,
                &self.completion,
            );
        }
        finish_private_delivery(
            Some(counter_index),
            &self.fixture,
            &self.counters,
            &self.timing,
            &self.completion,
        );
    }
}

#[derive(Clone)]
enum VenueBinding {
    Shared {
        private_senders: Arc<Vec<mpsc::Sender<RawPrivateFrame>>>,
    },
    Batch {
        batch_index: usize,
        private_sender: mpsc::Sender<RawPrivateFrame>,
    },
    Global {
        private_sender: mpsc::Sender<RawPrivateFrame>,
    },
}

#[derive(Clone)]
struct VenueStrategy {
    registry: Arc<CommandRegistry>,
    fixture: Arc<Fixture>,
    counters: Arc<Counters>,
    timing: Arc<TimingState>,
    binding: VenueBinding,
}

impl Strategy for VenueStrategy {
    async fn initialize(&mut self) {}
}

impl CommandEmitter for VenueStrategy {
    fn command_init(&mut self, registry: Arc<CommandRegistry>) {
        self.registry = registry;
    }

    fn command_registry(&self) -> Arc<CommandRegistry> {
        Arc::clone(&self.registry)
    }
}

impl VenueStrategy {
    async fn emit_private(
        &self,
        global_index: usize,
        payload: &Arc<Vec<u8>>,
        expected: &TickExpectation,
    ) -> bool {
        let sender = match &self.binding {
            VenueBinding::Shared { private_senders } => &private_senders[expected.task_index],
            VenueBinding::Batch {
                batch_index,
                private_sender,
            } if *batch_index == expected.task_index => private_sender,
            VenueBinding::Batch { .. } => {
                cross_batch_error(&self.counters);
                return false;
            },
            VenueBinding::Global { private_sender } => private_sender,
        };
        if sender
            .send(RawPrivateFrame {
                global_index,
                payload: Arc::clone(payload),
            })
            .await
            .is_err()
        {
            self.counters.drops.fetch_add(1, Ordering::Relaxed);
            return false;
        }
        true
    }

    async fn process_order(&self, msg: InfraMsg<Vec<AltOrder>>, endpoint_ns: u64) {
        let Some(order) = msg.data.first() else {
            route_error(&self.counters);
            return;
        };
        if msg.data.len() != 1 {
            route_error(&self.counters);
            return;
        }
        let Some(client_order_id) = order.order_params.client_order_id.as_deref() else {
            route_error(&self.counters);
            return;
        };
        let Some(global_index) = parse_correlation(client_order_id) else {
            route_error(&self.counters);
            return;
        };
        let Some(expected) = self.fixture.expected.get(global_index) else {
            route_error(&self.counters);
            return;
        };
        if !expected.should_order
            || !mark_once(&self.timing.order_seen[global_index], &self.counters)
        {
            return;
        }
        self.timing.t_order[global_index].store(endpoint_ns, Ordering::Release);
        let binding_matches = match &self.binding {
            VenueBinding::Shared { .. } | VenueBinding::Global { .. } => true,
            VenueBinding::Batch { batch_index, .. } => *batch_index == expected.task_index,
        };
        if !binding_matches {
            cross_batch_error(&self.counters);
            return;
        }
        if msg.task_id != expected.order_task_id
            || order.timestamp != expected.timestamp_micros
            || order.market != Market::BinanceUmFutures
            || order.order_params.inst != expected.instrument
            || order.order_params.side != expected.side
            || order.order_params.size != ORDER_SIZE
            || order.order_params.order_type != OrderType::Market
            || expected.client_order_id.as_deref() != Some(client_order_id)
        {
            route_error(&self.counters);
            return;
        }

        let Some(frames) = self.fixture.private_frames[global_index].as_ref() else {
            route_error(&self.counters);
            return;
        };
        if let Some(ack) = frames.ack.as_ref()
            && !self.emit_private(global_index, ack, expected).await
        {
            return;
        }
        self.emit_private(global_index, &frames.terminal, expected)
            .await;
    }
}

impl EventHandler for VenueStrategy {
    async fn on_order_execution(&mut self, msg: InfraMsg<Vec<AltOrder>>) {
        let endpoint_ns = self.timing.now_ns();
        let in_flight = self.counters.in_flight.fetch_add(1, Ordering::AcqRel) + 1;
        self.counters
            .max_in_flight
            .fetch_max(in_flight, Ordering::Relaxed);
        self.counters
            .order_endpoint_calls
            .fetch_add(1, Ordering::Relaxed);
        self.process_order(msg, endpoint_ns).await;
    }
}

async fn run_account_ingress(
    expected_task_index: Option<usize>,
    mut private_rx: mpsc::Receiver<RawPrivateFrame>,
    account_sender: broadcast::Sender<TaskEvent>,
    expected_receivers: usize,
    fixture: Arc<Fixture>,
    counters: Arc<Counters>,
) {
    while let Some(frame) = private_rx.recv().await {
        let Some(expected) = fixture.expected.get(frame.global_index) else {
            route_error(&counters);
            continue;
        };
        if expected_task_index.is_some_and(|task_index| expected.task_index != task_index) {
            cross_batch_error(&counters);
            continue;
        }
        if !expected.should_order {
            route_error(&counters);
            continue;
        }
        let decoded = match decode_um_account_order(frame.payload.as_slice()) {
            Ok(decoded) => decoded,
            Err(_) => {
                counters.drops.fetch_add(1, Ordering::Relaxed);
                continue;
            },
        };
        counters
            .private_frames_parsed
            .fetch_add(1, Ordering::Relaxed);
        if decoded.len() != 1 {
            route_error(&counters);
            continue;
        }
        match account_sender.send(TaskEvent::AccOrder(InfraMsg {
            task_id: expected.account_task_id,
            data: Arc::new(decoded),
        })) {
            Ok(receivers) if receivers == expected_receivers => {},
            Ok(_) => route_error(&counters),
            Err(_) => {
                counters.drops.fetch_add(1, Ordering::Relaxed);
            },
        }
    }
}

fn finish_terminal(
    global_index: usize,
    callback_ns: u64,
    filled: bool,
    fixture: &Fixture,
    counters: &Counters,
    timing: &TimingState,
    completion: &Notify,
) {
    if !mark_once(&timing.terminal_seen[global_index], counters) {
        return;
    }
    let expected = &fixture.expected[global_index];
    if filled {
        timing.t_fill[global_index].store(callback_ns, Ordering::Release);
        counters.fills.fetch_add(1, Ordering::Relaxed);
    } else {
        counters.business_errors.fetch_add(1, Ordering::Relaxed);
    }
    counters.completed_by_task[expected.task_index].fetch_add(1, Ordering::Relaxed);
    if counters
        .in_flight
        .fetch_update(Ordering::AcqRel, Ordering::Acquire, |value| {
            value.checked_sub(1)
        })
        .is_err()
    {
        route_error(counters);
    }
    timing
        .last_terminal_callback_ns
        .fetch_max(callback_ns, Ordering::Relaxed);
    let terminals = counters.terminal_callbacks.fetch_add(1, Ordering::AcqRel) + 1;
    if terminals == fixture.expected_orders as u64 {
        completion.notify_one();
    }
}

fn process_canonical_account(
    global_index: usize,
    order: &WsAccOrder,
    callback_ns: u64,
    fixture: &Fixture,
    counters: &Counters,
    timing: &TimingState,
    completion: &Notify,
) {
    let expected = &fixture.expected[global_index];
    match order.status {
        OrderStatus::Live if !expected.should_reject => {
            if mark_once(&timing.ack_seen[global_index], counters) {
                timing.t_ack[global_index].store(callback_ns, Ordering::Release);
                counters.acks.fetch_add(1, Ordering::Relaxed);
            }
        },
        OrderStatus::Filled if !expected.should_reject => finish_terminal(
            global_index,
            callback_ns,
            true,
            fixture,
            counters,
            timing,
            completion,
        ),
        OrderStatus::Rejected if expected.should_reject => finish_terminal(
            global_index,
            callback_ns,
            false,
            fixture,
            counters,
            timing,
            completion,
        ),
        _ => route_error(counters),
    }
}

#[derive(Clone)]
struct AccountStrategy {
    registry: Arc<CommandRegistry>,
    fixture: Arc<Fixture>,
    counters: Arc<Counters>,
    timing: Arc<TimingState>,
    completion: Arc<Notify>,
    batch_index: Option<usize>,
}

impl Strategy for AccountStrategy {
    async fn initialize(&mut self) {}
}

impl CommandEmitter for AccountStrategy {
    fn command_init(&mut self, registry: Arc<CommandRegistry>) {
        self.registry = registry;
    }

    fn command_registry(&self) -> Arc<CommandRegistry> {
        Arc::clone(&self.registry)
    }
}

impl AccountStrategy {
    fn process_account(&self, msg: InfraMsg<Vec<WsAccOrder>>, callback_ns: u64) {
        let Some(global_index) =
            validate_account_event(&msg, &self.fixture, &self.counters, self.batch_index)
        else {
            return;
        };
        if !mark_private_delivery(
            global_index,
            msg.data[0].status.clone(),
            0,
            &self.counters,
            &self.timing,
        ) {
            return;
        }
        process_canonical_account(
            global_index,
            &msg.data[0],
            callback_ns,
            &self.fixture,
            &self.counters,
            &self.timing,
            &self.completion,
        );
        finish_private_delivery(
            None,
            &self.fixture,
            &self.counters,
            &self.timing,
            &self.completion,
        );
    }
}

impl EventHandler for AccountStrategy {
    async fn on_acc_order(&mut self, msg: InfraMsg<Vec<WsAccOrder>>) {
        let callback_ns = self.timing.now_ns();
        self.process_account(msg, callback_ns);
    }
}

struct PreparedRun {
    public_frames: Vec<Vec<RawPublicFrame>>,
    trade_senders: Vec<broadcast::Sender<TaskEvent>>,
    runtime_tasks: JoinSet<()>,
    fixture: Arc<Fixture>,
    counters: Arc<Counters>,
    timing: Arc<TimingState>,
    completion: Arc<Notify>,
    _channels_guard: Arc<TaskChannels>,
    _registry_guard: Arc<CommandRegistry>,
}

async fn prepare_run(config: LivePipelineConfig) -> InfraResult<PreparedRun> {
    let mut fixture = Fixture::build(config)?;
    let public_frames = std::mem::take(&mut fixture.public_frames);
    let fixture = Arc::new(fixture);
    let counters = Arc::new(Counters::new(config));
    let timing = Arc::new(TimingState::new(fixture.expected.len()));
    let completion = Arc::new(Notify::new());
    let plan = TopologyPlan::build(config)?;
    let runtime_task_count = plan.runtime_tasks(config.topology);
    let TopologyPlan {
        trade_keys,
        order_keys,
        account_keys,
        signal_handlers,
    } = plan;
    let channels = Arc::new(TaskChannels::new(
        trade_keys
            .iter()
            .chain(order_keys.iter())
            .chain(account_keys.iter())
            .cloned(),
    )?);

    let alt_info = Arc::new(AltTaskInfo {
        alt_task_type: AltTaskType::OrderExecution,
        chunk: order_keys.len() as u64,
        task_base_id: Some(TASK_ID_BASE),
    });
    let mut command_handles = Vec::with_capacity(order_keys.len());
    let mut runners = Vec::with_capacity(order_keys.len());
    for (batch_index, order_key) in order_keys.iter().enumerate() {
        let (cmd_tx, cmd_rx) = mpsc::channel::<TaskCommand>(8_192);
        command_handles.push(Arc::new(CommandHandle {
            cmd_tx,
            task_info: TaskInfo::AltTask(Arc::clone(&alt_info)),
            task_id: batch_task_id(batch_index),
        }));
        runners.push(AltTaskRunner {
            cmd_rx,
            event_tx: channels
                .sender(order_key)
                .expect("order TaskChannel was registered"),
            alt_info: Arc::clone(&alt_info),
            task_id: batch_task_id(batch_index),
        });
    }
    let registry = Arc::new(CommandRegistry::new(command_handles));
    let account_senders = Arc::new(
        account_keys
            .iter()
            .map(|key| {
                channels
                    .sender(key)
                    .expect("account TaskChannel was registered")
            })
            .collect::<Vec<_>>(),
    );
    let fanout_domains = config.topology.fanout_domains(config.tasks);
    let mut private_senders = Vec::with_capacity(fanout_domains);
    let mut private_receivers = Vec::with_capacity(fanout_domains);
    for _ in 0..fanout_domains {
        let (private_tx, private_rx) = mpsc::channel(PRIVATE_INGRESS_CAPACITY);
        private_senders.push(private_tx);
        private_receivers.push(private_rx);
    }
    let private_senders = Arc::new(private_senders);

    let ready = Arc::new(Barrier::new(runtime_task_count + 1));
    let mut runtime_tasks = JoinSet::new();

    for handler in signal_handlers {
        let mut keys = handler
            .trade_key_indices
            .iter()
            .map(|index| trade_keys[*index].clone())
            .collect::<Vec<_>>();
        if let Some(account_key_index) = handler.account_key_index {
            keys.push(account_keys[account_key_index].clone());
        }
        let receivers = channels.subscribe(keys)?;
        let strategy = TradeStrategy {
            registry: Arc::clone(&registry),
            fixture: Arc::clone(&fixture),
            counters: Arc::clone(&counters),
            timing: Arc::clone(&timing),
            completion: Arc::clone(&completion),
            binding: handler.binding,
            signal_compute_ns: config.signal_compute_ns,
        };
        let task_ready = Arc::clone(&ready);
        let lag_counters = Arc::clone(&counters);
        let lag_completion = Arc::clone(&completion);
        runtime_tasks.spawn(async move {
            task_ready.wait().await;
            strategy_handler_loop_with_lag_observer(strategy, receivers, move |key, skipped| {
                lag_counters.record_broadcast_lag(key, skipped, &lag_completion);
            })
            .await;
        });
    }

    for (domain_index, private_rx) in private_receivers.into_iter().enumerate() {
        let account_sender = account_senders[domain_index].clone();
        let expected_receivers = config.topology.account_receivers_per_batch();
        let expected_task_index = match config.topology {
            LiveTopology::SharedHandler | LiveTopology::BatchSharded => Some(domain_index),
            LiveTopology::Ws5Strategy20 => None,
        };
        let fixture = Arc::clone(&fixture);
        let counters = Arc::clone(&counters);
        let task_ready = Arc::clone(&ready);
        runtime_tasks.spawn(async move {
            task_ready.wait().await;
            run_account_ingress(
                expected_task_index,
                private_rx,
                account_sender,
                expected_receivers,
                fixture,
                counters,
            )
            .await;
        });
    }

    match config.topology {
        LiveTopology::SharedHandler => {
            let venue_receivers = channels.subscribe(order_keys.clone())?;
            let venue_strategy = VenueStrategy {
                registry: Arc::clone(&registry),
                fixture: Arc::clone(&fixture),
                counters: Arc::clone(&counters),
                timing: Arc::clone(&timing),
                binding: VenueBinding::Shared {
                    private_senders: Arc::clone(&private_senders),
                },
            };
            let task_ready = Arc::clone(&ready);
            let lag_counters = Arc::clone(&counters);
            let lag_completion = Arc::clone(&completion);
            runtime_tasks.spawn(async move {
                task_ready.wait().await;
                strategy_handler_loop_with_lag_observer(
                    venue_strategy,
                    venue_receivers,
                    move |key, skipped| {
                        lag_counters.record_broadcast_lag(key, skipped, &lag_completion);
                    },
                )
                .await;
            });

            let account_receivers = channels.subscribe(account_keys.clone())?;
            let account_strategy = AccountStrategy {
                registry: Arc::clone(&registry),
                fixture: Arc::clone(&fixture),
                counters: Arc::clone(&counters),
                timing: Arc::clone(&timing),
                completion: Arc::clone(&completion),
                batch_index: None,
            };
            let task_ready = Arc::clone(&ready);
            let lag_counters = Arc::clone(&counters);
            let lag_completion = Arc::clone(&completion);
            runtime_tasks.spawn(async move {
                task_ready.wait().await;
                strategy_handler_loop_with_lag_observer(
                    account_strategy,
                    account_receivers,
                    move |key, skipped| {
                        lag_counters.record_broadcast_lag(key, skipped, &lag_completion);
                    },
                )
                .await;
            });
        },
        LiveTopology::BatchSharded => {
            for batch_index in 0..config.tasks {
                let venue_receivers = channels.subscribe([order_keys[batch_index].clone()])?;
                let venue_strategy = VenueStrategy {
                    registry: Arc::clone(&registry),
                    fixture: Arc::clone(&fixture),
                    counters: Arc::clone(&counters),
                    timing: Arc::clone(&timing),
                    binding: VenueBinding::Batch {
                        batch_index,
                        private_sender: private_senders[batch_index].clone(),
                    },
                };
                let task_ready = Arc::clone(&ready);
                let lag_counters = Arc::clone(&counters);
                let lag_completion = Arc::clone(&completion);
                runtime_tasks.spawn(async move {
                    task_ready.wait().await;
                    strategy_handler_loop_with_lag_observer(
                        venue_strategy,
                        venue_receivers,
                        move |key, skipped| {
                            lag_counters.record_broadcast_lag(key, skipped, &lag_completion);
                        },
                    )
                    .await;
                });
            }
        },
        LiveTopology::Ws5Strategy20 => {
            let venue_receivers = channels.subscribe([order_keys[0].clone()])?;
            let venue_strategy = VenueStrategy {
                registry: Arc::clone(&registry),
                fixture: Arc::clone(&fixture),
                counters: Arc::clone(&counters),
                timing: Arc::clone(&timing),
                binding: VenueBinding::Global {
                    private_sender: private_senders[0].clone(),
                },
            };
            let task_ready = Arc::clone(&ready);
            let lag_counters = Arc::clone(&counters);
            let lag_completion = Arc::clone(&completion);
            runtime_tasks.spawn(async move {
                task_ready.wait().await;
                strategy_handler_loop_with_lag_observer(
                    venue_strategy,
                    venue_receivers,
                    move |key, skipped| {
                        lag_counters.record_broadcast_lag(key, skipped, &lag_completion);
                    },
                )
                .await;
            });
        },
    }
    for mut runner in runners {
        let task_ready = Arc::clone(&ready);
        let orders_relayed = Arc::clone(&counters.orders_relayed);
        let failures = Arc::clone(&counters.runner_failures);
        runtime_tasks.spawn(async move {
            task_ready.wait().await;
            runner
                .benchmark_order_execution(orders_relayed, failures)
                .await;
        });
    }

    if runtime_tasks.len() != runtime_task_count {
        return Err(InfraError::Msg(format!(
            "live pipeline runtime topology mismatch: spawned={}, expected={runtime_task_count}",
            runtime_tasks.len()
        )));
    }
    for key in &trade_keys {
        let receivers = channels
            .sender(key)
            .expect("trade TaskChannel was registered")
            .receiver_count();
        if receivers != 1 {
            return Err(InfraError::Msg(format!(
                "trade TaskChannel must have exactly one receiver, got {receivers}: {key:?}"
            )));
        }
    }
    for key in &order_keys {
        let receivers = channels
            .sender(key)
            .expect("order TaskChannel was registered")
            .receiver_count();
        if receivers != 1 {
            return Err(InfraError::Msg(format!(
                "order TaskChannel must have exactly one receiver, got {receivers}: {key:?}"
            )));
        }
    }
    let expected_account_receivers = config.topology.account_receivers_per_batch();
    for key in &account_keys {
        let receivers = channels
            .sender(key)
            .expect("account TaskChannel was registered")
            .receiver_count();
        if receivers != expected_account_receivers {
            return Err(InfraError::Msg(format!(
                "account TaskChannel receiver mismatch: got={receivers}, expected={expected_account_receivers}: {key:?}"
            )));
        }
    }
    ready.wait().await;

    let trade_senders = trade_keys
        .iter()
        .map(|key| {
            channels
                .sender(key)
                .expect("trade TaskChannel was registered")
        })
        .collect();
    Ok(PreparedRun {
        public_frames,
        trade_senders,
        runtime_tasks,
        fixture,
        counters,
        timing,
        completion,
        _channels_guard: channels,
        _registry_guard: registry,
    })
}

#[derive(Debug)]
struct ProducerTerminal {
    producer_index: usize,
    task_index: usize,
    sent: usize,
}

#[allow(clippy::too_many_arguments)]
async fn run_public_producer(
    producer_index: usize,
    task_index: usize,
    frames: Vec<RawPublicFrame>,
    sender: broadcast::Sender<TaskEvent>,
    barrier: Arc<Barrier>,
    go: Arc<AtomicBool>,
    fixture: Arc<Fixture>,
    counters: Arc<Counters>,
    timing: Arc<TimingState>,
) -> Result<ProducerTerminal, String> {
    barrier.wait().await;
    while !go.load(Ordering::Acquire) {
        tokio::task::yield_now().await;
    }
    let mut sent = 0;
    for frame in frames {
        let start_ns = timing.now_ns();
        timing.t0[frame.global_index].store(start_ns, Ordering::Release);
        let decoded = match decode_um_agg_trade(&frame.payload) {
            Ok(decoded) => decoded,
            Err(error) => {
                counters.drops.fetch_add(1, Ordering::Relaxed);
                return Err(format!("public frame decode failed: {error}"));
            },
        };
        let public_ns = timing.now_ns();
        timing.t_public[frame.global_index].store(public_ns, Ordering::Release);
        counters.public_parsed.fetch_add(1, Ordering::Relaxed);
        if !mark_once(&timing.public_seen[frame.global_index], &counters) {
            continue;
        }
        let expected = &fixture.expected[frame.global_index];
        let Some(trade) = decoded.first() else {
            route_error(&counters);
            continue;
        };
        if expected.task_index != task_index {
            cross_batch_error(&counters);
            continue;
        }
        if decoded.len() != 1
            || trade.trade_id != frame.global_index as u64
            || trade.inst != expected.instrument
        {
            route_error(&counters);
            continue;
        }
        match sender.send(TaskEvent::Trade(InfraMsg {
            task_id: expected.trade_task_id,
            data: Arc::new(decoded),
        })) {
            Ok(1) => {},
            Ok(_) => {
                route_error(&counters);
                continue;
            },
            Err(_) => {
                counters.drops.fetch_add(1, Ordering::Relaxed);
                continue;
            },
        }
        counters.ticks_sent.fetch_add(1, Ordering::Relaxed);
        counters.sent_by_task[task_index].fetch_add(1, Ordering::Relaxed);
        sent += 1;
        tokio::task::yield_now().await;
        counters
            .public_cooperative_yields
            .fetch_add(1, Ordering::Relaxed);
    }
    Ok(ProducerTerminal {
        producer_index,
        task_index,
        sent,
    })
}

async fn wait_for_phase(
    producers: &mut JoinSet<Result<ProducerTerminal, String>>,
    runtime_tasks: &mut JoinSet<()>,
    fixture: &Fixture,
    counters: &Counters,
    completion: &Notify,
    producer_tasks: usize,
) -> InfraResult<()> {
    let mut producer_done = vec![false; producer_tasks];
    let mut producers_completed = 0;
    loop {
        let broadcast_lagged = counters.broadcast_lagged.load(Ordering::Acquire);
        if broadcast_lagged != 0 {
            return Err(InfraError::Msg(format!(
                "live pipeline broadcast lagged: skipped={broadcast_lagged}, first={}",
                counters.first_broadcast_lag()
            )));
        }
        let callbacks_complete =
            counters.trade_callbacks.load(Ordering::Acquire) == fixture.expected.len() as u64;
        let terminals_complete =
            counters.terminal_callbacks.load(Ordering::Acquire) == fixture.expected_orders as u64;
        let private_fanout_complete = counters.private_fanout_callbacks.load(Ordering::Acquire)
            == fixture.expected_private_fanout_callbacks as u64;
        if producers_completed == producer_tasks
            && callbacks_complete
            && terminals_complete
            && private_fanout_complete
        {
            return Ok(());
        }

        tokio::select! {
            joined = producers.join_next(), if producers_completed < producer_tasks => {
                let terminal = joined
                    .ok_or_else(|| InfraError::Msg("public producer set closed early".into()))?
                    .map_err(|error| InfraError::Msg(format!("public producer task failed: {error}")))?
                    .map_err(InfraError::Msg)?;
                if terminal.producer_index >= producer_tasks || producer_done[terminal.producer_index] {
                    return Err(InfraError::Msg("duplicate or invalid producer terminal".into()));
                }
                if terminal.task_index >= fixture.expected_private_frames_by_task.len()
                    || terminal.sent != fixture.ticks_per_producer
                {
                    return Err(InfraError::Msg(format!(
                        "producer {} sent {} of {} ticks",
                        terminal.producer_index, terminal.sent, fixture.ticks_per_producer
                    )));
                }
                producer_done[terminal.producer_index] = true;
                producers_completed += 1;
            },
            joined = runtime_tasks.join_next() => {
                let error = match joined {
                    Some(Ok(())) => "runtime task exited unexpectedly".into(),
                    Some(Err(error)) => format!("runtime task failed: {error}"),
                    None => "runtime task set closed unexpectedly".into(),
                };
                return Err(InfraError::Msg(error));
            },
            _ = completion.notified() => {},
        }
    }
}

async fn teardown(
    runtime_tasks: &mut JoinSet<()>,
    producers: &mut JoinSet<Result<ProducerTerminal, String>>,
) -> InfraResult<()> {
    producers.abort_all();
    runtime_tasks.abort_all();
    while let Some(joined) = producers.join_next().await {
        if let Err(error) = joined
            && !error.is_cancelled()
        {
            return Err(InfraError::Msg(format!(
                "producer failed during cleanup: {error}"
            )));
        }
    }
    while let Some(joined) = runtime_tasks.join_next().await {
        if let Err(error) = joined
            && !error.is_cancelled()
        {
            return Err(InfraError::Msg(format!(
                "runtime failed during cleanup: {error}"
            )));
        }
    }
    Ok(())
}

fn checked_latency(start_ns: u64, end_ns: u64) -> Option<u64> {
    (start_ns != 0 && end_ns >= start_ns).then_some(end_ns.saturating_sub(start_ns))
}

fn task_min_max(slots: &[AtomicU64]) -> (u64, u64) {
    let mut values = slots.iter().map(|slot| slot.load(Ordering::Acquire));
    let first = values.next().unwrap_or(0);
    values.fold((first, first), |(min, max), value| {
        (min.min(value), max.max(value))
    })
}

fn build_report(
    config: LivePipelineConfig,
    fixture: &Fixture,
    counters: &Counters,
    timing: &TimingState,
) -> LivePipelineReport {
    let mut public_decode = Vec::with_capacity(fixture.expected.len());
    let mut tick_to_order = Vec::with_capacity(fixture.expected_orders);
    let mut tick_to_ack = Vec::with_capacity(fixture.expected_orders);
    let mut tick_to_fill = Vec::with_capacity(fixture.expected_orders);
    let mut missing_correlations = 0;
    let expected_fanout_mask = 1_u32
        .checked_shl(config.topology.account_receivers_per_batch() as u32)
        .unwrap_or(0)
        .saturating_sub(1);

    for (index, expected) in fixture.expected.iter().enumerate() {
        let start = timing.t0[index].load(Ordering::Acquire);
        let mut missing = timing.public_seen[index].load(Ordering::Acquire) == 0
            || timing.trade_seen[index].load(Ordering::Acquire) == 0;
        match checked_latency(start, timing.t_public[index].load(Ordering::Acquire)) {
            Some(latency) => public_decode.push(latency),
            None => missing = true,
        }
        if expected.should_order {
            match checked_latency(start, timing.t_order[index].load(Ordering::Acquire)) {
                Some(latency) => tick_to_order.push(latency),
                None => missing = true,
            }
            if timing.terminal_seen[index].load(Ordering::Acquire) == 0 {
                missing = true;
            }
            if timing.terminal_fanout_seen[index].load(Ordering::Acquire) != expected_fanout_mask {
                missing = true;
            }
            if !expected.should_reject {
                if timing.ack_fanout_seen[index].load(Ordering::Acquire) != expected_fanout_mask {
                    missing = true;
                }
                match checked_latency(start, timing.t_ack[index].load(Ordering::Acquire)) {
                    Some(latency) => tick_to_ack.push(latency),
                    None => missing = true,
                }
                match checked_latency(start, timing.t_fill[index].load(Ordering::Acquire)) {
                    Some(latency) => tick_to_fill.push(latency),
                    None => missing = true,
                }
            }
        }
        missing_correlations += u64::from(missing);
    }

    let public_decode = summarize_latencies(public_decode);
    let tick_to_order = summarize_latencies(tick_to_order);
    let tick_to_ack = summarize_latencies(tick_to_ack);
    let tick_to_fill = summarize_latencies(tick_to_fill);
    let (per_task_sent_min, per_task_sent_max) = task_min_max(&counters.sent_by_task);
    let (per_task_completed_min, per_task_completed_max) =
        task_min_max(&counters.completed_by_task);
    let (per_signal_trade_callbacks_min, per_signal_trade_callbacks_max) =
        task_min_max(&counters.trade_callbacks_by_signal_handler);
    let (per_signal_private_callbacks_min, per_signal_private_callbacks_max) =
        task_min_max(&counters.private_callbacks_by_signal_handler);
    let phase_start = timing.phase_start_ns.load(Ordering::Acquire);
    let wall_end = timing
        .last_trade_callback_completed_ns
        .load(Ordering::Acquire)
        .max(timing.last_terminal_callback_ns.load(Ordering::Acquire))
        .max(
            timing
                .last_private_fanout_callback_ns
                .load(Ordering::Acquire),
        );
    let wall_elapsed_ns = wall_end.saturating_sub(phase_start);
    let total_ticks = fixture.expected.len() as u64;

    let private_fanout_callbacks = counters.private_fanout_callbacks.load(Ordering::Acquire);
    let native_owner_callbacks = counters
        .acks
        .load(Ordering::Acquire)
        .saturating_add(counters.terminal_callbacks.load(Ordering::Acquire));

    LivePipelineReport {
        framework: "extrema_infra",
        mode: config.mode.name(),
        scenario: config.scenario.name(),
        topology: config.topology.name(),
        tasks: config.tasks,
        instruments_per_task: config.instruments_per_task,
        messages_per_instrument: config.messages_per_instrument,
        order_every: config.order_every,
        signal_compute_ns: config.signal_compute_ns,
        reject_every: config.reject_every,
        batch_count: config.topology.batch_count(config.tasks),
        public_ws_tasks: fixture.producer_tasks,
        public_ws_tasks_per_fanout_domain: config.topology.public_ws_tasks_per_fanout_domain(),
        symbols_per_public_ws: config
            .topology
            .symbols_per_public_ws(config.instruments_per_task),
        symbols_per_signal_handler: config
            .topology
            .symbols_per_signal_handler(config.tasks, config.instruments_per_task),
        producer_tasks: fixture.producer_tasks,
        trade_ingress_lanes: fixture.producer_tasks,
        trade_task_keys: fixture.producer_tasks,
        public_cooperative_yields: counters.public_cooperative_yields.load(Ordering::Acquire),
        account_broadcast_rings: config.topology.fanout_domains(config.tasks),
        account_broadcast_topics: 0,
        account_fanout_domains: config.topology.fanout_domains(config.tasks),
        signal_handlers: config
            .topology
            .signal_handlers(config.tasks)
            .expect("validated signal handler count"),
        trade_lanes_per_signal_handler: match config.topology {
            LiveTopology::SharedHandler => fixture.producer_tasks,
            LiveTopology::BatchSharded => TRADE_LANES_PER_SIGNAL_HANDLER,
            LiveTopology::Ws5Strategy20 => 1,
        },
        account_receivers_per_ring: config.topology.account_receivers_per_batch(),
        account_handlers_per_fanout_domain: config.topology.account_receivers_per_batch(),
        venue_handlers: config.topology.venue_handlers(config.tasks),
        account_ingress_tasks: config.topology.fanout_domains(config.tasks),
        account_ingress_lanes: config.topology.fanout_domains(config.tasks),
        private_ingress_capacity: PRIVATE_INGRESS_CAPACITY,
        trade_broadcast_capacity: TRADE_CHANNEL_CAPACITY,
        order_execution_broadcast_capacity: ORDER_EXECUTION_CHANNEL_CAPACITY,
        account_order_broadcast_capacity: ACC_ORDER_CHANNEL_CAPACITY,
        account_owner_handlers: config.topology.account_owner_handlers(config.tasks),
        order_runners: config.topology.order_runners(config.tasks),
        total_ticks,
        expected_orders: fixture.expected_orders as u64,
        expected_fills: fixture.expected_fills as u64,
        expected_business_errors: fixture.expected_business_errors as u64,
        ticks_sent: counters.ticks_sent.load(Ordering::Acquire),
        public_parsed: counters.public_parsed.load(Ordering::Acquire),
        trade_callbacks: counters.trade_callbacks.load(Ordering::Acquire),
        signal_compute_calls: counters.signal_compute_calls.load(Ordering::Acquire),
        strategy_signals: counters.strategy_signals.load(Ordering::Acquire),
        orders_submitted: counters.orders_submitted.load(Ordering::Acquire),
        orders_relayed: counters.orders_relayed.load(Ordering::Acquire),
        order_endpoint_calls: counters.order_endpoint_calls.load(Ordering::Acquire),
        private_frames_parsed: counters.private_frames_parsed.load(Ordering::Acquire),
        expected_private_fanout_callbacks: fixture.expected_private_fanout_callbacks as u64,
        private_fanout_callbacks,
        account_observation_callbacks: private_fanout_callbacks,
        native_owner_callbacks,
        account_non_owner_callbacks: private_fanout_callbacks
            .saturating_sub(native_owner_callbacks),
        acks: counters.acks.load(Ordering::Acquire),
        fills: counters.fills.load(Ordering::Acquire),
        terminal_callbacks: counters.terminal_callbacks.load(Ordering::Acquire),
        broadcast_lagged: counters.broadcast_lagged.load(Ordering::Acquire),
        drops: counters.drops.load(Ordering::Acquire)
            + counters.runner_failures.load(Ordering::Acquire),
        duplicates: counters.duplicates.load(Ordering::Acquire),
        missing_correlations,
        route_errors: counters.route_errors.load(Ordering::Acquire),
        cross_batch_errors: counters.cross_batch_errors.load(Ordering::Acquire),
        business_errors: counters.business_errors.load(Ordering::Acquire),
        max_in_flight: counters.max_in_flight.load(Ordering::Acquire),
        ending_in_flight: counters.in_flight.load(Ordering::Acquire),
        per_task_sent_min,
        per_task_sent_max,
        per_task_completed_min,
        per_task_completed_max,
        per_signal_trade_callbacks_min,
        per_signal_trade_callbacks_max,
        per_signal_private_callbacks_min,
        per_signal_private_callbacks_max,
        wall_elapsed_ns,
        wall_throughput_ticks_s: if wall_elapsed_ns == 0 {
            0.0
        } else {
            total_ticks as f64 * 1_000_000_000.0 / wall_elapsed_ns as f64
        },
        public_decode_samples: public_decode.samples,
        public_decode_p50_ns: public_decode.p50_ns,
        public_decode_p95_ns: public_decode.p95_ns,
        public_decode_p99_ns: public_decode.p99_ns,
        public_decode_max_ns: public_decode.max_ns,
        tick_to_order_samples: tick_to_order.samples,
        tick_to_order_p50_ns: tick_to_order.p50_ns,
        tick_to_order_p95_ns: tick_to_order.p95_ns,
        tick_to_order_p99_ns: tick_to_order.p99_ns,
        tick_to_order_max_ns: tick_to_order.max_ns,
        tick_to_ack_samples: tick_to_ack.samples,
        tick_to_ack_p50_ns: tick_to_ack.p50_ns,
        tick_to_ack_p95_ns: tick_to_ack.p95_ns,
        tick_to_ack_p99_ns: tick_to_ack.p99_ns,
        tick_to_ack_max_ns: tick_to_ack.max_ns,
        tick_to_fill_samples: tick_to_fill.samples,
        tick_to_fill_p50_ns: tick_to_fill.p50_ns,
        tick_to_fill_p95_ns: tick_to_fill.p95_ns,
        tick_to_fill_p99_ns: tick_to_fill.p99_ns,
        tick_to_fill_max_ns: tick_to_fill.max_ns,
        public_decoder: "production BinanceWsData<WsAggTradeBinanceUM>",
        private_decoder: "production BinanceWsData<WsAccountOrderBinanceUM>",
        public_ingress_model: match config.topology {
            LiveTopology::SharedHandler => {
                "one cooperative Tokio task per logical batch, multiplexing its Trade instruments with one explicit yield after every published message"
            },
            LiveTopology::BatchSharded => {
                "one cooperative Tokio task per Trade WS lane with one explicit yield after every published message"
            },
            LiveTopology::Ws5Strategy20 => {
                "twenty cooperative Tokio public WS tasks, each round-robin publishing five symbols with one explicit yield after every message"
            },
        },
        private_ingress_model: match config.topology {
            LiveTopology::SharedHandler | LiveTopology::BatchSharded => {
                "one bounded raw AccountOrder WS task per batch"
            },
            LiveTopology::Ws5Strategy20 => {
                "one global bounded raw AccountOrder WS task for all twenty public WS tasks"
            },
        },
        signal_handler_model: match config.topology {
            LiveTopology::SharedHandler => {
                "one native Extrema Strategy task shared by all logical batches"
            },
            LiveTopology::BatchSharded => {
                "five native Extrema Strategy tasks per batch, four Trade lanes each"
            },
            LiveTopology::Ws5Strategy20 => {
                "twenty native Extrema Strategy tasks, each bound to one public WS task carrying five symbols"
            },
        },
        handler_kind: "native_strategy_tasks",
        batch_isolation_model: match config.topology {
            LiveTopology::SharedHandler => {
                "logical batches share signal, venue and account handlers"
            },
            LiveTopology::BatchSharded => {
                "batch-local task keys, handlers, runners and rings on one Tokio runtime"
            },
            LiveTopology::Ws5Strategy20 => {
                "twenty isolated public Trade task keys and signal handlers share one global venue and account fan-out domain"
            },
        },
        private_fanout_model: match config.topology {
            LiveTopology::SharedHandler => {
                "decoded Arc delivered to one native account Strategy handler"
            },
            LiveTopology::BatchSharded => {
                "one TaskChannels broadcast ring per batch; decoded Arc delivered to five native Strategy handlers"
            },
            LiveTopology::Ws5Strategy20 => {
                "one global TaskChannels AccountOrder ring; each private frame decoded once and its Arc delivered to twenty native Strategy handlers"
            },
        },
        account_owner_selection_model: match config.topology {
            LiveTopology::SharedHandler => "the single account Strategy handler is canonical",
            LiveTopology::BatchSharded => "fixed signal handler 0 is canonical in every batch",
            LiveTopology::Ws5Strategy20 => {
                "fixed signal handler 0 is the sole canonical owner; nineteen handlers are observers"
            },
        },
        broadcast_lag_observable: true,
        overflow_model: "broadcast lag is a hard failure; bounded raw private mpsc applies send().await backpressure",
        benchmark_local_decode_bridge: false,
    }
}

impl LivePipelineReport {
    fn validate(&self, fixture: &Fixture, config: LivePipelineConfig) -> InfraResult<()> {
        let expected_ticks = fixture.expected.len() as u64;
        let expected_orders = fixture.expected_orders as u64;
        let expected_fills = fixture.expected_fills as u64;
        let expected_business_errors = fixture.expected_business_errors as u64;
        let expected_per_task = fixture.ticks_per_task as u64;
        let expected_private_frames = expected_fills
            .saturating_mul(2)
            .saturating_add(expected_business_errors);
        let expected_producer_tasks = fixture.producer_tasks;
        let expected_signal_handlers = config
            .topology
            .signal_handlers(config.tasks)
            .expect("validated signal handler count");
        let expected_trade_lanes_per_handler = match config.topology {
            LiveTopology::SharedHandler => fixture.producer_tasks,
            LiveTopology::BatchSharded => TRADE_LANES_PER_SIGNAL_HANDLER,
            LiveTopology::Ws5Strategy20 => 1,
        };
        let expected_signal_trade_callbacks = match config.topology {
            LiveTopology::SharedHandler => expected_ticks,
            LiveTopology::BatchSharded => {
                (TRADE_LANES_PER_SIGNAL_HANDLER * config.messages_per_instrument) as u64
            },
            LiveTopology::Ws5Strategy20 => fixture.ticks_per_task as u64,
        };
        let (expected_signal_private_min, expected_signal_private_max) = match config.topology {
            LiveTopology::SharedHandler => (0, 0),
            LiveTopology::BatchSharded => {
                let min = fixture
                    .expected_private_frames_by_task
                    .iter()
                    .min()
                    .copied()
                    .unwrap_or(0) as u64;
                let max = fixture
                    .expected_private_frames_by_task
                    .iter()
                    .max()
                    .copied()
                    .unwrap_or(0) as u64;
                (min, max)
            },
            LiveTopology::Ws5Strategy20 => (expected_private_frames, expected_private_frames),
        };
        let topology_failure = self.topology != config.topology.name()
            || self.signal_compute_ns != config.signal_compute_ns
            || self.batch_count != config.topology.batch_count(config.tasks)
            || self.public_ws_tasks != expected_producer_tasks
            || self.public_ws_tasks_per_fanout_domain
                != config.topology.public_ws_tasks_per_fanout_domain()
            || self.symbols_per_public_ws
                != config
                    .topology
                    .symbols_per_public_ws(config.instruments_per_task)
            || self.symbols_per_signal_handler
                != config
                    .topology
                    .symbols_per_signal_handler(config.tasks, config.instruments_per_task)
            || self.producer_tasks != expected_producer_tasks
            || self.trade_ingress_lanes != expected_producer_tasks
            || self.trade_task_keys != expected_producer_tasks
            || self.account_broadcast_rings != config.topology.fanout_domains(config.tasks)
            || self.account_broadcast_topics != 0
            || self.account_fanout_domains != config.topology.fanout_domains(config.tasks)
            || self.signal_handlers != expected_signal_handlers
            || self.trade_lanes_per_signal_handler != expected_trade_lanes_per_handler
            || self.account_receivers_per_ring != config.topology.account_receivers_per_batch()
            || self.account_handlers_per_fanout_domain
                != config.topology.account_receivers_per_batch()
            || self.venue_handlers != config.topology.venue_handlers(config.tasks)
            || self.account_ingress_tasks != config.topology.fanout_domains(config.tasks)
            || self.account_ingress_lanes != config.topology.fanout_domains(config.tasks)
            || self.account_owner_handlers != config.topology.account_owner_handlers(config.tasks)
            || self.order_runners != config.topology.order_runners(config.tasks);
        let count_failure = topology_failure
            || self.total_ticks != expected_ticks
            || self.expected_orders != expected_orders
            || self.expected_fills != expected_fills
            || self.expected_business_errors != expected_business_errors
            || self.ticks_sent != expected_ticks
            || self.public_cooperative_yields != expected_ticks
            || self.public_parsed != expected_ticks
            || self.trade_callbacks != expected_ticks
            || self.signal_compute_calls != expected_ticks
            || self.strategy_signals != expected_orders
            || self.orders_submitted != expected_orders
            || self.orders_relayed != expected_orders
            || self.order_endpoint_calls != expected_orders
            || self.private_frames_parsed != expected_private_frames
            || self.expected_private_fanout_callbacks
                != fixture.expected_private_fanout_callbacks as u64
            || self.private_fanout_callbacks != fixture.expected_private_fanout_callbacks as u64
            || self.account_observation_callbacks
                != fixture.expected_private_fanout_callbacks as u64
            || self.native_owner_callbacks != expected_private_frames
            || self.account_non_owner_callbacks
                != fixture
                    .expected_private_fanout_callbacks
                    .saturating_sub(expected_private_frames as usize) as u64
            || self.acks != expected_fills
            || self.fills != expected_fills
            || self.terminal_callbacks != expected_orders
            || self.business_errors != expected_business_errors
            || self.broadcast_lagged != 0
            || self.drops != 0
            || self.duplicates != 0
            || self.missing_correlations != 0
            || self.route_errors != 0
            || self.cross_batch_errors != 0
            || self.ending_in_flight != 0
            || self.per_task_sent_min != expected_per_task
            || self.per_task_sent_max != expected_per_task
            || self.per_task_completed_min != expected_per_task
            || self.per_task_completed_max != expected_per_task
            || self.per_signal_trade_callbacks_min != expected_signal_trade_callbacks
            || self.per_signal_trade_callbacks_max != expected_signal_trade_callbacks
            || self.per_signal_private_callbacks_min != expected_signal_private_min
            || self.per_signal_private_callbacks_max != expected_signal_private_max
            || self.public_decode_samples != expected_ticks
            || self.tick_to_order_samples != expected_orders
            || self.tick_to_ack_samples != expected_fills
            || self.tick_to_fill_samples != expected_fills;
        let timing_failure = self.wall_elapsed_ns == 0
            || self.wall_throughput_ticks_s <= 0.0
            || (expected_orders > 0 && self.max_in_flight == 0)
            || self.public_decode_p50_ns > self.public_decode_p95_ns
            || self.public_decode_p95_ns > self.public_decode_p99_ns
            || self.public_decode_p99_ns > self.public_decode_max_ns
            || self.tick_to_order_p50_ns > self.tick_to_order_p95_ns
            || self.tick_to_order_p95_ns > self.tick_to_order_p99_ns
            || self.tick_to_order_p99_ns > self.tick_to_order_max_ns
            || self.tick_to_ack_p50_ns > self.tick_to_ack_p95_ns
            || self.tick_to_ack_p95_ns > self.tick_to_ack_p99_ns
            || self.tick_to_ack_p99_ns > self.tick_to_ack_max_ns
            || self.tick_to_fill_p50_ns > self.tick_to_fill_p95_ns
            || self.tick_to_fill_p95_ns > self.tick_to_fill_p99_ns
            || self.tick_to_fill_p99_ns > self.tick_to_fill_max_ns
            || self.public_decode_max_ns > self.wall_elapsed_ns
            || self.tick_to_order_max_ns > self.wall_elapsed_ns
            || self.tick_to_ack_max_ns > self.wall_elapsed_ns
            || self.tick_to_fill_max_ns > self.wall_elapsed_ns;
        if count_failure || timing_failure {
            return Err(InfraError::Msg(format!(
                "live pipeline conservation failed: topology={} producers={} trade_keys={} signal_handlers={} account_receivers={}; ticks expected={expected_ticks} sent={} yields={} parsed={} callbacks={} signal_compute_ns={} signal_compute_calls={}; orders expected={expected_orders} submitted={} relayed={} endpoint={} private_frames={} private_fanout={}/{} acks={} fills={} business_errors={}; broadcast_lagged={} drops={} duplicates={} missing={} route_errors={} cross_batch_errors={} ending_in_flight={}",
                self.topology,
                self.producer_tasks,
                self.trade_task_keys,
                self.signal_handlers,
                self.account_receivers_per_ring,
                self.ticks_sent,
                self.public_cooperative_yields,
                self.public_parsed,
                self.trade_callbacks,
                self.signal_compute_ns,
                self.signal_compute_calls,
                self.orders_submitted,
                self.orders_relayed,
                self.order_endpoint_calls,
                self.private_frames_parsed,
                self.private_fanout_callbacks,
                self.expected_private_fanout_callbacks,
                self.acks,
                self.fills,
                self.business_errors,
                self.broadcast_lagged,
                self.drops,
                self.duplicates,
                self.missing_correlations,
                self.route_errors,
                self.cross_batch_errors,
                self.ending_in_flight,
            )));
        }
        Ok(())
    }
}

pub async fn run_live_pipeline(config: LivePipelineConfig) -> InfraResult<LivePipelineReport> {
    config.validate()?;
    let mut prepared = prepare_run(config).await?;
    let producer_tasks = prepared.fixture.producer_tasks;
    let start_barrier = Arc::new(Barrier::new(producer_tasks + 1));
    let go = Arc::new(AtomicBool::new(false));
    let mut producers = JoinSet::new();
    for producer_index in 0..producer_tasks {
        let task_index = match config.topology {
            LiveTopology::SharedHandler | LiveTopology::Ws5Strategy20 => producer_index,
            LiveTopology::BatchSharded => producer_index / BATCH_TRADE_LANES,
        };
        let frames = std::mem::take(&mut prepared.public_frames[producer_index]);
        producers.spawn(run_public_producer(
            producer_index,
            task_index,
            frames,
            prepared.trade_senders[producer_index].clone(),
            Arc::clone(&start_barrier),
            Arc::clone(&go),
            Arc::clone(&prepared.fixture),
            Arc::clone(&prepared.counters),
            Arc::clone(&prepared.timing),
        ));
    }

    start_barrier.wait().await;
    prepared
        .timing
        .phase_start_ns
        .store(prepared.timing.now_ns(), Ordering::Release);
    go.store(true, Ordering::Release);
    let phase = tokio::time::timeout(
        RUN_TIMEOUT,
        wait_for_phase(
            &mut producers,
            &mut prepared.runtime_tasks,
            &prepared.fixture,
            &prepared.counters,
            &prepared.completion,
            producer_tasks,
        ),
    )
    .await;

    match phase {
        Ok(Ok(())) => teardown(&mut prepared.runtime_tasks, &mut producers).await?,
        Ok(Err(error)) => {
            let _ = teardown(&mut prepared.runtime_tasks, &mut producers).await;
            return Err(error);
        },
        Err(_) => {
            let callbacks = prepared.counters.trade_callbacks.load(Ordering::Acquire);
            let terminals = prepared.counters.terminal_callbacks.load(Ordering::Acquire);
            let private_fanout = prepared
                .counters
                .private_fanout_callbacks
                .load(Ordering::Acquire);
            let broadcast_lagged = prepared.counters.broadcast_lagged.load(Ordering::Acquire);
            let _ = teardown(&mut prepared.runtime_tasks, &mut producers).await;
            return Err(InfraError::Msg(format!(
                "live pipeline timed out after {RUN_TIMEOUT:?}: trade_callbacks={callbacks}/{}, terminal_callbacks={terminals}/{}, private_fanout_callbacks={private_fanout}/{}, broadcast_lagged={broadcast_lagged}",
                prepared.fixture.expected.len(),
                prepared.fixture.expected_orders,
                prepared.fixture.expected_private_fanout_callbacks,
            )));
        },
    }

    let report = build_report(
        config,
        &prepared.fixture,
        &prepared.counters,
        &prepared.timing,
    );
    report.validate(&prepared.fixture, config)?;
    Ok(report)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn shared_config(mode: LiveMode, scenario: LiveScenario) -> LivePipelineConfig {
        LivePipelineConfig {
            tasks: 2,
            instruments_per_task: 3,
            messages_per_instrument: 4,
            mode,
            order_every: 2,
            signal_compute_ns: 0,
            reject_every: 3,
            scenario,
            topology: LiveTopology::SharedHandler,
        }
    }

    fn batch_sharded_config(scenario: LiveScenario) -> LivePipelineConfig {
        LivePipelineConfig {
            tasks: 2,
            instruments_per_task: BATCH_TRADE_LANES,
            messages_per_instrument: 1,
            mode: LiveMode::Stress,
            order_every: 20,
            signal_compute_ns: 0,
            reject_every: 3,
            scenario,
            topology: LiveTopology::BatchSharded,
        }
    }

    fn ws5_strategy20_config(scenario: LiveScenario) -> LivePipelineConfig {
        LivePipelineConfig {
            tasks: WS5_STRATEGY20_PUBLIC_WS_TASKS,
            instruments_per_task: WS5_STRATEGY20_SYMBOLS_PER_WS,
            messages_per_instrument: 1,
            mode: LiveMode::Stress,
            order_every: 20,
            signal_compute_ns: 0,
            reject_every: 3,
            scenario,
            topology: LiveTopology::Ws5Strategy20,
        }
    }

    #[test]
    fn reject_every_must_be_positive() {
        let config = LivePipelineConfig {
            reject_every: 0,
            ..LivePipelineConfig::default()
        };

        let error = Fixture::build(config).unwrap_err();
        assert!(error.to_string().contains("LIVE_REJECT_EVERY"));
    }

    #[test]
    fn batch_sharded_requires_exactly_twenty_trade_lanes() {
        let mut config = batch_sharded_config(LiveScenario::Success);
        config.instruments_per_task = BATCH_TRADE_LANES - 1;

        let error = Fixture::build(config).unwrap_err();
        assert!(
            error
                .to_string()
                .contains("requires LIVE_INSTRUMENTS_PER_TASK=20")
        );
    }

    #[test]
    fn ws5_strategy20_requires_fixed_public_ws_and_symbol_counts() {
        let mut config = ws5_strategy20_config(LiveScenario::Success);
        config.tasks -= 1;
        let error = Fixture::build(config).unwrap_err();
        assert!(error.to_string().contains("requires LIVE_TASKS=20"));

        let mut config = ws5_strategy20_config(LiveScenario::Success);
        config.instruments_per_task -= 1;
        let error = Fixture::build(config).unwrap_err();
        assert!(
            error
                .to_string()
                .contains("requires LIVE_INSTRUMENTS_PER_TASK=5")
        );
    }

    #[test]
    fn batch_sharded_plan_assigns_four_disjoint_trade_lanes_per_signal() {
        let config = batch_sharded_config(LiveScenario::Success);
        let plan = TopologyPlan::build(config).unwrap();

        assert_eq!(plan.trade_keys.len(), 2 * BATCH_TRADE_LANES);
        assert_eq!(plan.order_keys.len(), 2);
        assert_eq!(plan.account_keys.len(), 2);
        assert_eq!(plan.signal_handlers.len(), 2 * SIGNAL_HANDLERS_PER_BATCH);
        assert_eq!(plan.runtime_tasks(config.topology), 16);

        let mut assigned = vec![0_u8; plan.trade_keys.len()];
        for handler in &plan.signal_handlers {
            let SignalBinding::Batch {
                batch_index,
                handler_index,
                ..
            } = handler.binding
            else {
                panic!("batch-sharded plan created a shared signal binding");
            };
            assert_eq!(
                handler.trade_key_indices.len(),
                TRADE_LANES_PER_SIGNAL_HANDLER
            );
            assert_eq!(handler.account_key_index, Some(batch_index));
            for &trade_index in &handler.trade_key_indices {
                assert_eq!(trade_index / BATCH_TRADE_LANES, batch_index);
                assert_eq!(
                    trade_index % BATCH_TRADE_LANES / TRADE_LANES_PER_SIGNAL_HANDLER,
                    handler_index
                );
                assigned[trade_index] += 1;
            }
        }
        assert!(assigned.into_iter().all(|count| count == 1));
    }

    #[test]
    fn ws5_strategy20_plan_binds_one_ws_and_five_round_robin_symbols_per_strategy() {
        let mut config = ws5_strategy20_config(LiveScenario::Success);
        config.messages_per_instrument = 2;
        let plan = TopologyPlan::build(config).unwrap();
        let fixture = Fixture::build(config).unwrap();

        assert_eq!(plan.trade_keys.len(), 20);
        assert_eq!(plan.order_keys.len(), 1);
        assert_eq!(plan.account_keys.len(), 1);
        assert_eq!(plan.signal_handlers.len(), 20);
        assert_eq!(plan.runtime_tasks(config.topology), 23);

        for (task_index, handler) in plan.signal_handlers.iter().enumerate() {
            assert_eq!(handler.trade_key_indices, [task_index]);
            assert_eq!(handler.account_key_index, Some(0));
            assert_eq!(
                handler.binding,
                SignalBinding::Ws5Strategy20 {
                    task_index,
                    counter_index: task_index,
                }
            );

            let instrument_order = fixture.public_frames[task_index]
                .iter()
                .map(|frame| fixture.expected[frame.global_index].instrument_index)
                .collect::<Vec<_>>();
            assert_eq!(instrument_order, [0, 1, 2, 3, 4, 0, 1, 2, 3, 4]);
        }
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 8)]
    async fn ws5_strategy20_success_conserves_global_private_fanout() {
        let report = run_live_pipeline(ws5_strategy20_config(LiveScenario::Success))
            .await
            .unwrap();

        assert_eq!(report.topology, "ws5_strategy20");
        assert_eq!(report.public_ws_tasks, 20);
        assert_eq!(report.public_ws_tasks_per_fanout_domain, 20);
        assert_eq!(report.symbols_per_public_ws, 5);
        assert_eq!(report.symbols_per_signal_handler, 5);
        assert_eq!(report.producer_tasks, 20);
        assert_eq!(report.trade_ingress_lanes, 20);
        assert_eq!(report.signal_handlers, 20);
        assert_eq!(report.account_broadcast_rings, 1);
        assert_eq!(report.account_fanout_domains, 1);
        assert_eq!(report.account_receivers_per_ring, 20);
        assert_eq!(report.account_handlers_per_fanout_domain, 20);
        assert_eq!(report.venue_handlers, 1);
        assert_eq!(report.account_ingress_tasks, 1);
        assert_eq!(report.account_ingress_lanes, 1);
        assert_eq!(report.account_owner_handlers, 1);
        assert_eq!(report.order_runners, 1);
        assert_eq!(report.total_ticks, 100);
        assert_eq!(report.signal_compute_ns, 0);
        assert_eq!(report.signal_compute_calls, 100);
        assert_eq!(report.expected_orders, 100);
        assert_eq!(report.private_frames_parsed, 200);
        assert_eq!(report.expected_private_fanout_callbacks, 4_000);
        assert_eq!(report.private_fanout_callbacks, 4_000);
        assert_eq!(report.native_owner_callbacks, 200);
        assert_eq!(report.account_non_owner_callbacks, 3_800);
        assert_eq!(report.per_signal_trade_callbacks_min, 5);
        assert_eq!(report.per_signal_trade_callbacks_max, 5);
        assert_eq!(report.per_signal_private_callbacks_min, 200);
        assert_eq!(report.per_signal_private_callbacks_max, 200);
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 8)]
    async fn ws5_strategy20_signal_compute_runs_for_order_and_no_order_ticks() {
        let mut config = ws5_strategy20_config(LiveScenario::Success);
        config.mode = LiveMode::MixedLive;
        config.messages_per_instrument = 2;
        config.order_every = 2;
        config.signal_compute_ns = 1_000;

        let report = run_live_pipeline(config).await.unwrap();

        assert_eq!(report.total_ticks, 200);
        assert_eq!(report.expected_orders, 100);
        assert_eq!(report.signal_compute_ns, 1_000);
        assert_eq!(report.signal_compute_calls, 200);
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 8)]
    async fn ws5_strategy20_business_error_conserves_global_private_fanout() {
        let report = run_live_pipeline(ws5_strategy20_config(LiveScenario::BusinessError))
            .await
            .unwrap();

        assert_eq!(report.expected_orders, 100);
        assert_eq!(report.expected_fills, 66);
        assert_eq!(report.expected_business_errors, 34);
        assert_eq!(report.private_frames_parsed, 166);
        assert_eq!(report.expected_private_fanout_callbacks, 3_320);
        assert_eq!(report.private_fanout_callbacks, 3_320);
        assert_eq!(report.native_owner_callbacks, 166);
        assert_eq!(report.account_non_owner_callbacks, 3_154);
        assert_eq!(report.acks, 66);
        assert_eq!(report.fills, 66);
        assert_eq!(report.business_errors, 34);
        assert_eq!(report.per_signal_private_callbacks_min, 166);
        assert_eq!(report.per_signal_private_callbacks_max, 166);
        assert_eq!(report.missing_correlations, 0);
        assert_eq!(report.broadcast_lagged, 0);
        assert_eq!(report.drops, 0);
        assert_eq!(report.duplicates, 0);
        assert_eq!(report.route_errors, 0);
        assert_eq!(report.cross_batch_errors, 0);
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn two_tasks_three_instruments_conserve_stress_and_mixed_live() {
        for (mode, order_every, expected_orders) in
            [(LiveMode::Stress, 20, 24), (LiveMode::MixedLive, 2, 12)]
        {
            let mut config = shared_config(mode, LiveScenario::Success);
            config.order_every = order_every;
            config.reject_every = 10;
            let report = run_live_pipeline(config).await.unwrap();

            assert_eq!(report.total_ticks, 24);
            assert_eq!(report.expected_orders, expected_orders);
            assert_eq!(report.public_parsed, 24);
            assert_eq!(report.trade_callbacks, 24);
            assert_eq!(report.public_cooperative_yields, 24);
            assert_eq!(report.account_ingress_lanes, 2);
            assert_eq!(report.cross_batch_errors, 0);
            assert_eq!(report.orders_submitted, expected_orders);
            assert_eq!(report.acks, expected_orders);
            assert_eq!(report.fills, expected_orders);
            assert_eq!(report.per_task_sent_min, 12);
            assert_eq!(report.per_task_completed_min, 12);
        }
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn business_error_rejects_every_nth_order_without_missing_fills() {
        let mut config = shared_config(LiveMode::Stress, LiveScenario::BusinessError);
        config.messages_per_instrument = 2;
        config.order_every = 20;
        let report = run_live_pipeline(config).await.unwrap();

        assert_eq!(report.expected_orders, 12);
        assert_eq!(report.expected_fills, 8);
        assert_eq!(report.expected_business_errors, 4);
        assert_eq!(report.private_frames_parsed, 20);
        assert_eq!(report.acks, 8);
        assert_eq!(report.fills, 8);
        assert_eq!(report.business_errors, 4);
        assert_eq!(report.missing_correlations, 0);
        assert_eq!(report.tick_to_ack_samples, 8);
        assert_eq!(report.tick_to_fill_samples, 8);
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn batch_sharded_two_batches_conserve_private_fanout() {
        for (scenario, expected_fills, expected_business_errors, expected_private_frames) in [
            (LiveScenario::Success, 40, 0, 80),
            (LiveScenario::BusinessError, 26, 14, 66),
        ] {
            let report = run_live_pipeline(batch_sharded_config(scenario))
                .await
                .unwrap();

            assert_eq!(report.topology, "batch_sharded");
            assert_eq!(report.producer_tasks, 40);
            assert_eq!(report.trade_task_keys, 40);
            assert_eq!(report.public_cooperative_yields, 40);
            assert_eq!(report.account_broadcast_rings, 2);
            assert_eq!(report.account_broadcast_topics, 0);
            assert_eq!(report.account_fanout_domains, 2);
            assert_eq!(report.signal_handlers, 10);
            assert_eq!(report.trade_lanes_per_signal_handler, 4);
            assert_eq!(report.account_receivers_per_ring, 5);
            assert_eq!(report.account_handlers_per_fanout_domain, 5);
            assert_eq!(report.venue_handlers, 2);
            assert_eq!(report.account_ingress_tasks, 2);
            assert_eq!(report.account_ingress_lanes, 2);
            assert_eq!(report.private_ingress_capacity, PRIVATE_INGRESS_CAPACITY);
            assert_eq!(report.trade_broadcast_capacity, TRADE_CHANNEL_CAPACITY);
            assert_eq!(
                report.order_execution_broadcast_capacity,
                ORDER_EXECUTION_CHANNEL_CAPACITY
            );
            assert_eq!(
                report.account_order_broadcast_capacity,
                ACC_ORDER_CHANNEL_CAPACITY
            );
            assert_eq!(report.account_owner_handlers, 2);
            assert_eq!(report.order_runners, 2);
            assert_eq!(report.total_ticks, 40);
            assert_eq!(report.expected_orders, 40);
            assert_eq!(report.expected_fills, expected_fills);
            assert_eq!(report.expected_business_errors, expected_business_errors);
            assert_eq!(report.private_frames_parsed, expected_private_frames);
            assert_eq!(
                report.expected_private_fanout_callbacks,
                expected_private_frames * 5
            );
            assert_eq!(report.private_fanout_callbacks, expected_private_frames * 5);
            assert_eq!(
                report.account_observation_callbacks,
                expected_private_frames * 5
            );
            assert_eq!(report.native_owner_callbacks, expected_private_frames);
            assert_eq!(
                report.account_non_owner_callbacks,
                expected_private_frames * 4
            );
            assert_eq!(report.acks, expected_fills);
            assert_eq!(report.fills, expected_fills);
            assert_eq!(report.terminal_callbacks, 40);
            assert_eq!(report.business_errors, expected_business_errors);
            assert_eq!(report.per_signal_trade_callbacks_min, 4);
            assert_eq!(report.per_signal_trade_callbacks_max, 4);
            assert_eq!(
                report.per_signal_private_callbacks_min,
                expected_private_frames / 2
            );
            assert_eq!(
                report.per_signal_private_callbacks_max,
                expected_private_frames / 2
            );
            assert_eq!(report.missing_correlations, 0);
            assert_eq!(report.broadcast_lagged, 0);
            assert_eq!(report.duplicates, 0);
            assert_eq!(report.route_errors, 0);
            assert_eq!(report.cross_batch_errors, 0);
        }
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn batch_sharded_mixed_live_conserves_multiple_messages_per_lane() {
        let mut config = batch_sharded_config(LiveScenario::Success);
        config.mode = LiveMode::MixedLive;
        config.messages_per_instrument = 4;
        config.order_every = 2;

        let report = run_live_pipeline(config).await.unwrap();

        assert_eq!(report.total_ticks, 160);
        assert_eq!(report.public_cooperative_yields, 160);
        assert_eq!(report.expected_orders, 80);
        assert_eq!(report.trade_callbacks, 160);
        assert_eq!(report.orders_submitted, 80);
        assert_eq!(report.private_frames_parsed, 160);
        assert_eq!(report.private_fanout_callbacks, 800);
        assert_eq!(report.per_signal_trade_callbacks_min, 16);
        assert_eq!(report.per_signal_trade_callbacks_max, 16);
        assert_eq!(report.per_signal_private_callbacks_min, 80);
        assert_eq!(report.per_signal_private_callbacks_max, 80);
        assert_eq!(report.broadcast_lagged, 0);
        assert_eq!(report.cross_batch_errors, 0);
    }

    #[test]
    fn mismatched_account_handler_batch_counts_cross_batch_and_route_errors() {
        let config = batch_sharded_config(LiveScenario::Success);
        let fixture = Fixture::build(config).unwrap();
        let counters = Counters::new(config);
        let expected = &fixture.expected[0];
        let private = fixture.private_frames[0].as_ref().unwrap();
        let decoded = decode_um_account_order(private.terminal.as_slice()).unwrap();
        let msg = InfraMsg {
            task_id: expected.account_task_id,
            data: Arc::new(decoded),
        };

        assert!(validate_account_event(&msg, &fixture, &counters, Some(1)).is_none());
        assert_eq!(counters.cross_batch_errors.load(Ordering::Acquire), 1);
        assert_eq!(counters.route_errors.load(Ordering::Acquire), 1);
    }

    #[tokio::test]
    async fn observed_broadcast_lag_fails_the_phase_immediately() {
        let config = batch_sharded_config(LiveScenario::Success);
        let key = TopologyPlan::build(config).unwrap().trade_keys[0].clone();
        let fixture = Fixture::build(config).unwrap();
        let counters = Counters::new(config);
        let completion = Notify::new();
        counters.record_broadcast_lag(&key, 7, &completion);
        let mut producers = JoinSet::new();
        let mut runtime_tasks = JoinSet::new();

        let error = wait_for_phase(
            &mut producers,
            &mut runtime_tasks,
            &fixture,
            &counters,
            &completion,
            fixture.producer_tasks,
        )
        .await
        .unwrap_err();

        let message = error.to_string();
        assert!(message.contains("broadcast lagged: skipped=7"));
        assert!(message.contains("Trades"));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn batch_sharded_report_serializes_auditable_topology() {
        let report = run_live_pipeline(batch_sharded_config(LiveScenario::Success))
            .await
            .unwrap();
        let value = serde_json::to_value(report).unwrap();

        for field in [
            "topology",
            "batch_count",
            "public_ws_tasks",
            "public_ws_tasks_per_fanout_domain",
            "symbols_per_public_ws",
            "symbols_per_signal_handler",
            "producer_tasks",
            "trade_ingress_lanes",
            "trade_task_keys",
            "public_cooperative_yields",
            "signal_compute_ns",
            "signal_compute_calls",
            "account_broadcast_rings",
            "account_broadcast_topics",
            "account_fanout_domains",
            "signal_handlers",
            "trade_lanes_per_signal_handler",
            "account_receivers_per_ring",
            "account_handlers_per_fanout_domain",
            "venue_handlers",
            "account_ingress_tasks",
            "account_ingress_lanes",
            "private_ingress_capacity",
            "trade_broadcast_capacity",
            "order_execution_broadcast_capacity",
            "account_order_broadcast_capacity",
            "account_owner_handlers",
            "order_runners",
            "expected_private_fanout_callbacks",
            "private_fanout_callbacks",
            "account_observation_callbacks",
            "native_owner_callbacks",
            "account_non_owner_callbacks",
            "cross_batch_errors",
            "broadcast_lagged",
            "public_ingress_model",
            "private_ingress_model",
            "signal_handler_model",
            "handler_kind",
            "batch_isolation_model",
            "private_fanout_model",
            "account_owner_selection_model",
            "broadcast_lag_observable",
            "overflow_model",
        ] {
            assert!(value.get(field).is_some(), "missing report field {field}");
        }
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 8)]
    async fn ws5_strategy20_report_serializes_auditable_topology() {
        let report = run_live_pipeline(ws5_strategy20_config(LiveScenario::Success))
            .await
            .unwrap();
        let value = serde_json::to_value(report).unwrap();

        for (field, expected) in [
            ("topology", json!("ws5_strategy20")),
            ("batch_count", json!(1)),
            ("public_ws_tasks", json!(20)),
            ("public_ws_tasks_per_fanout_domain", json!(20)),
            ("symbols_per_public_ws", json!(5)),
            ("symbols_per_signal_handler", json!(5)),
            ("producer_tasks", json!(20)),
            ("trade_ingress_lanes", json!(20)),
            ("trade_task_keys", json!(20)),
            ("signal_handlers", json!(20)),
            ("signal_compute_ns", json!(0)),
            ("signal_compute_calls", json!(100)),
            ("trade_lanes_per_signal_handler", json!(1)),
            ("account_broadcast_rings", json!(1)),
            ("account_fanout_domains", json!(1)),
            ("account_receivers_per_ring", json!(20)),
            ("account_handlers_per_fanout_domain", json!(20)),
            ("venue_handlers", json!(1)),
            ("account_ingress_tasks", json!(1)),
            ("account_ingress_lanes", json!(1)),
            ("account_owner_handlers", json!(1)),
            ("order_runners", json!(1)),
        ] {
            assert_eq!(
                value.get(field),
                Some(&expected),
                "wrong report field {field}"
            );
        }
    }
}
