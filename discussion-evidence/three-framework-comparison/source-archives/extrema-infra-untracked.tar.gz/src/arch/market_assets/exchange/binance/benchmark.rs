use crate::arch::{
    strategy_base::handler::{
        events::{WsAccOrder, WsTrade},
        lob_events::WsLob,
    },
    traits::conversion::IntoWsData,
};

use super::{
    binance_ws_msg::decode_single_ws_frame,
    schemas::um_futures_ws::{
        account_order::WsAccountOrderBinanceUM,
        agg_trades::WsAggTradeBinanceUM,
        lob::{WsBookTickerBinanceUM, WsDiffDepthBinanceUM},
    },
};

/// Decodes one Binance USD-M aggregate-trade frame through the production
/// websocket envelope and normalization types.
pub fn decode_um_agg_trade(payload: &[u8]) -> serde_json::Result<Vec<WsTrade>> {
    let decoded = decode_single_ws_frame::<WsAggTradeBinanceUM>(payload)?;
    Ok(decoded.into_ws())
}

/// Decodes one Binance USD-M private order-update frame through the production
/// websocket envelope and normalization types.
pub fn decode_um_account_order(payload: &[u8]) -> serde_json::Result<Vec<WsAccOrder>> {
    let decoded = decode_single_ws_frame::<WsAccountOrderBinanceUM>(payload)?;
    Ok(decoded.into_ws())
}

/// Decodes one Binance USD-M book-ticker frame through the production
/// specialized websocket decoder and normalization types.
pub fn decode_um_book_ticker(payload: &[u8]) -> serde_json::Result<Vec<WsLob>> {
    let decoded = decode_single_ws_frame::<WsBookTickerBinanceUM>(payload)?;
    Ok(decoded.into_ws())
}

/// Decodes one Binance USD-M incremental depth frame through the production
/// specialized websocket decoder and normalization types.
pub fn decode_um_diff_depth(payload: &[u8]) -> serde_json::Result<Vec<WsLob>> {
    let decoded = decode_single_ws_frame::<WsDiffDepthBinanceUM>(payload)?;
    Ok(decoded.into_ws())
}
