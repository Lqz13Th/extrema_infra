//! Internal native tick-to-trade benchmark support.

use std::{
    collections::HashMap,
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, AtomicU64, Ordering},
    },
    time::{Duration, Instant},
};

use serde::Serialize;
use tokio::{
    sync::{Barrier, Notify, mpsc},
    task::{JoinHandle, JoinSet},
};

use crate::{
    arch::{
        market_assets::{
            api_general::OrderParams,
            base_data::{OrderSide, OrderType},
            market_core::Market,
        },
        strategy_base::{
            command::command_core::{CommandHandle, CommandRegistry, TaskCommand},
            handler::{
                handler_core::strategy_handler_loop,
                task_channel::{InfraMsg, TaskChannels, TaskEvent},
            },
        },
        task_execution::{
            TaskInfo, TaskKey,
            alt_runner::AltTaskRunner,
            task_alt::{AltTaskInfo, AltTaskType},
            task_ws::WsChannel,
        },
        traits::strategy::{CommandEmitter, EventHandler, Strategy},
    },
    errors::{InfraError, InfraResult},
    prelude::{AltOrder, WsTrade},
};

const TASK_ID_BASE: u64 = 1;
const CORRELATION_TIMESTAMP_BASE: u64 = 1_800_000_000_000_000;
const RUN_TIMEOUT: Duration = Duration::from_secs(30);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NativeTickToTradeWorkload {
    Unloaded,
    Saturated { tasks: usize },
}

impl NativeTickToTradeWorkload {
    fn lanes(self) -> usize {
        match self {
            Self::Unloaded => 1,
            Self::Saturated { tasks } => tasks,
        }
    }

    fn name(self) -> &'static str {
        match self {
            Self::Unloaded => "unloaded",
            Self::Saturated { .. } => "saturated",
        }
    }

    fn waits_after_each_tick(self) -> bool {
        matches!(self, Self::Unloaded)
    }

    fn queue_inclusive(self) -> bool {
        matches!(self, Self::Saturated { .. })
    }
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct NativeTickToTradeReport {
    pub framework: &'static str,
    pub workload: &'static str,
    pub lanes: usize,
    pub messages_per_task: usize,
    pub total_messages: u64,
    pub queue_inclusive: bool,
    pub sent: u64,
    pub strategy_callbacks: u64,
    pub orders_generated: u64,
    pub commands_sent: u64,
    pub orders_relayed: u64,
    pub execution_callbacks: u64,
    pub latency_samples: u64,
    pub duplicates: u64,
    pub route_mismatches: u64,
    pub missing: u64,
    pub failures: u64,
    pub max_in_flight: u64,
    pub ending_in_flight: u64,
    pub wall_elapsed_ns: u64,
    pub elapsed_ns: u64,
    pub messages_per_second: f64,
    pub p50_ns: u64,
    pub p95_ns: u64,
    pub p99_ns: u64,
    pub min_ns: u64,
    pub max_ns: u64,
}

impl NativeTickToTradeReport {
    fn validate(&self) -> InfraResult<()> {
        let expected = self.total_messages;
        if self.sent != expected
            || self.strategy_callbacks != expected
            || self.orders_generated != expected
            || self.commands_sent != expected
            || self.orders_relayed != expected
            || self.execution_callbacks != expected
            || self.latency_samples != expected
            || self.duplicates != 0
            || self.route_mismatches != 0
            || self.missing != 0
            || self.failures != 0
            || self.ending_in_flight != 0
        {
            return Err(InfraError::Msg(format!(
                "native tick-to-trade conservation failed: expected={expected}, sent={}, strategy_callbacks={}, orders_generated={}, commands_sent={}, orders_relayed={}, execution_callbacks={}, latency_samples={}, duplicates={}, route_mismatches={}, missing={}, failures={}, ending_in_flight={}",
                self.sent,
                self.strategy_callbacks,
                self.orders_generated,
                self.commands_sent,
                self.orders_relayed,
                self.execution_callbacks,
                self.latency_samples,
                self.duplicates,
                self.route_mismatches,
                self.missing,
                self.failures,
                self.ending_in_flight,
            )));
        }

        if self.wall_elapsed_ns == 0
            || self.wall_elapsed_ns != self.elapsed_ns
            || self.min_ns == 0
            || self.max_ns < self.p99_ns
        {
            return Err(InfraError::Msg(
                "native tick-to-trade timing samples are invalid".into(),
            ));
        }

        Ok(())
    }
}

#[derive(Default)]
struct Counters {
    sent: AtomicU64,
    strategy_callbacks: AtomicU64,
    orders_generated: AtomicU64,
    commands_sent: AtomicU64,
    orders_relayed: Arc<AtomicU64>,
    execution_callbacks: AtomicU64,
    route_mismatches: AtomicU64,
    failures: Arc<AtomicU64>,
    in_flight: AtomicU64,
    max_in_flight: AtomicU64,
}

struct TimingState {
    origin: Instant,
    phase_start_ns: AtomicU64,
    starts: Vec<AtomicU64>,
    unloaded_ack_seen: Vec<AtomicU64>,
}

impl TimingState {
    fn new(total_messages: usize) -> Self {
        Self {
            origin: Instant::now(),
            phase_start_ns: AtomicU64::new(0),
            starts: atomic_slots(total_messages),
            unloaded_ack_seen: atomic_slots(total_messages),
        }
    }

    fn now_ns(&self) -> u64 {
        self.origin.elapsed().as_nanos().min(u64::MAX as u128) as u64
    }
}

struct ExecutionObservation {
    end_ns: u64,
    msg: InfraMsg<Vec<AltOrder>>,
}

struct ExecutionObservations {
    entries: Mutex<Vec<ExecutionObservation>>,
    last_end_ns: AtomicU64,
}

impl ExecutionObservations {
    fn new(total_messages: usize) -> Self {
        Self {
            entries: Mutex::new(Vec::with_capacity(total_messages)),
            last_end_ns: AtomicU64::new(0),
        }
    }
}

fn atomic_slots(len: usize) -> Vec<AtomicU64> {
    (0..len).map(|_| AtomicU64::new(0)).collect()
}

#[derive(Clone)]
struct SignalProbe {
    registry: Arc<CommandRegistry>,
    counters: Arc<Counters>,
    messages_per_task: usize,
    total_messages: usize,
}

impl Strategy for SignalProbe {
    async fn initialize(&mut self) {}
}

impl CommandEmitter for SignalProbe {
    fn command_init(&mut self, registry: Arc<CommandRegistry>) {
        self.registry = registry;
    }

    fn command_registry(&self) -> Arc<CommandRegistry> {
        Arc::clone(&self.registry)
    }
}

impl EventHandler for SignalProbe {
    async fn on_trade(&mut self, msg: InfraMsg<Vec<WsTrade>>) {
        self.counters
            .strategy_callbacks
            .fetch_add(1, Ordering::Relaxed);

        let Some(trade) = msg.data.first() else {
            self.counters.failures.fetch_add(1, Ordering::Relaxed);
            return;
        };
        if msg.data.len() != 1 {
            self.counters.failures.fetch_add(1, Ordering::Relaxed);
            return;
        }

        let Ok(global_index) = usize::try_from(trade.trade_id) else {
            self.counters.failures.fetch_add(1, Ordering::Relaxed);
            return;
        };
        if global_index >= self.total_messages {
            self.counters.failures.fetch_add(1, Ordering::Relaxed);
            return;
        }

        let expected_task_id = task_id_for(global_index, self.messages_per_task);
        if msg.task_id != expected_task_id
            || trade.timestamp != correlation_timestamp(global_index)
            || trade.market != Market::BinanceUmFutures
            || trade.inst != "BTC_USDT_PERP"
            || trade.price != expected_price(global_index)
            || trade.size != 0.001
            || trade.side != expected_side(global_index, self.messages_per_task)
        {
            self.counters
                .route_mismatches
                .fetch_add(1, Ordering::Relaxed);
            return;
        }

        let Some(handle) = self
            .registry
            .find_alt_handle(&AltTaskType::OrderExecution, msg.task_id)
        else {
            self.counters.failures.fetch_add(1, Ordering::Relaxed);
            return;
        };

        let order = AltOrder {
            timestamp: trade.timestamp,
            market: trade.market.clone(),
            order_params: OrderParams {
                inst: trade.inst.clone(),
                side: trade.side.clone(),
                size: trade.size.to_string(),
                order_type: OrderType::Market,
                ..Default::default()
            },
            metadata: HashMap::new(),
        };
        self.counters
            .orders_generated
            .fetch_add(1, Ordering::Relaxed);

        self.counters.commands_sent.fetch_add(1, Ordering::Relaxed);
        if handle
            .send_command(TaskCommand::OrderExecute(vec![order]), None)
            .await
            .is_err()
        {
            self.counters.commands_sent.fetch_sub(1, Ordering::Relaxed);
            self.counters.failures.fetch_add(1, Ordering::Relaxed);
        }
    }
}

#[derive(Clone)]
struct ExecutionProbe {
    registry: Arc<CommandRegistry>,
    counters: Arc<Counters>,
    timing: Arc<TimingState>,
    observations: Arc<ExecutionObservations>,
    completions: Option<Arc<Vec<mpsc::UnboundedSender<usize>>>>,
    all_executed: Arc<Notify>,
    messages_per_task: usize,
    total_messages: usize,
}

impl Strategy for ExecutionProbe {
    async fn initialize(&mut self) {}
}

impl CommandEmitter for ExecutionProbe {
    fn command_init(&mut self, registry: Arc<CommandRegistry>) {
        self.registry = registry;
    }

    fn command_registry(&self) -> Arc<CommandRegistry> {
        Arc::clone(&self.registry)
    }
}

impl EventHandler for ExecutionProbe {
    async fn on_order_execution(&mut self, msg: InfraMsg<Vec<AltOrder>>) {
        let callback_ns = self.timing.now_ns();
        let ack_index = self.completions.as_ref().and_then(|_| {
            execution_global_index(&msg, self.messages_per_task, self.total_messages)
        });
        let duplicate = ack_index.is_some_and(|global_index| {
            self.timing.unloaded_ack_seen[global_index].swap(1, Ordering::AcqRel) != 0
        });

        // The timed endpoint is callback entry. Saturated mode only records the
        // owned message and raw completion state here; validation is offline.
        self.observations
            .entries
            .lock()
            .expect("execution observation lock poisoned")
            .push(ExecutionObservation {
                end_ns: callback_ns,
                msg,
            });
        self.observations
            .last_end_ns
            .fetch_max(callback_ns, Ordering::Relaxed);
        self.counters.in_flight.fetch_sub(1, Ordering::Relaxed);
        let completed = self
            .counters
            .execution_callbacks
            .fetch_add(1, Ordering::AcqRel)
            + 1;
        if completed == self.total_messages as u64 {
            // notify_one retains a permit when the coordinator has not started
            // waiting yet, avoiding a lost final-completion wakeup.
            self.all_executed.notify_one();
        }

        if let (Some(completions), Some(global_index), false) =
            (&self.completions, ack_index, duplicate)
        {
            let lane = global_index / self.messages_per_task;
            match completions.get(lane) {
                Some(completion) if completion.send(global_index).is_ok() => {},
                _ => {
                    self.counters.failures.fetch_add(1, Ordering::Relaxed);
                },
            }
        }
    }
}

#[derive(Debug)]
struct ProducerTerminal {
    lane: usize,
    sent: usize,
    completed: usize,
}

struct PreparedRun {
    trade_senders: Vec<tokio::sync::broadcast::Sender<TaskEvent>>,
    events: Vec<Vec<TaskEvent>>,
    completion_receivers: Vec<Option<mpsc::UnboundedReceiver<usize>>>,
    runtime_tasks: JoinSet<()>,
    counters: Arc<Counters>,
    timing: Arc<TimingState>,
    observations: Arc<ExecutionObservations>,
    all_executed: Arc<Notify>,
    _command_registry_guard: Arc<CommandRegistry>,
}

pub async fn run_native_tick_to_trade(
    workload: NativeTickToTradeWorkload,
    messages_per_task: usize,
) -> InfraResult<NativeTickToTradeReport> {
    if workload.lanes() == 0 {
        return Err(InfraError::Msg(
            "saturated task count must be greater than zero".into(),
        ));
    }
    if messages_per_task == 0 {
        return Err(InfraError::Msg(
            "messages_per_task must be greater than zero".into(),
        ));
    }

    let lanes = workload.lanes();
    let total_messages = lanes.checked_mul(messages_per_task).ok_or_else(|| {
        InfraError::Msg("native tick-to-trade message count overflows usize".into())
    })?;
    let max_index = u64::try_from(total_messages - 1)
        .map_err(|_| InfraError::Msg("native tick-to-trade index overflows u64".into()))?;
    CORRELATION_TIMESTAMP_BASE
        .checked_add(max_index)
        .ok_or_else(|| InfraError::Msg("correlation timestamp overflows u64".into()))?;

    let wait_after_each_tick = workload.waits_after_each_tick();
    let mut prepared = prepare_run(
        lanes,
        messages_per_task,
        total_messages,
        wait_after_each_tick,
    )
    .await?;
    let start_barrier = Arc::new(Barrier::new(lanes + 1));
    let go = Arc::new(AtomicBool::new(false));
    let (terminal_tx, mut terminal_rx) = mpsc::unbounded_channel();
    let mut producer_tasks = Vec::with_capacity(lanes);

    let completion_receivers = std::mem::take(&mut prepared.completion_receivers);
    for (lane, completion_rx) in completion_receivers.into_iter().enumerate() {
        let sender = prepared.trade_senders[lane].clone();
        let events = std::mem::take(&mut prepared.events[lane]);
        producer_tasks.push(tokio::spawn(run_producer(
            lane,
            events,
            sender,
            completion_rx,
            Arc::clone(&start_barrier),
            Arc::clone(&go),
            terminal_tx.clone(),
            Arc::clone(&prepared.counters),
            Arc::clone(&prepared.timing),
            wait_after_each_tick,
        )));
    }
    drop(terminal_tx);
    let mut terminal_seen = vec![false; lanes];
    let expected_completed = usize::from(wait_after_each_tick) * messages_per_task;

    // Every producer is parked at the barrier before the timed phase starts.
    start_barrier.wait().await;
    let phase_start_ns = prepared.timing.now_ns();
    prepared
        .timing
        .phase_start_ns
        .store(phase_start_ns, Ordering::Release);
    go.store(true, Ordering::Release);

    let phase_result = tokio::time::timeout(
        RUN_TIMEOUT,
        wait_for_phase(
            &mut prepared.runtime_tasks,
            &mut terminal_rx,
            &mut terminal_seen,
            &prepared.counters,
            &prepared.all_executed,
            lanes,
            messages_per_task,
            expected_completed,
            total_messages as u64,
        ),
    )
    .await;

    match phase_result {
        Ok(Ok(())) => {
            teardown(&mut prepared.runtime_tasks, &mut producer_tasks, false).await?;
        },
        Ok(Err(error)) => {
            let cleanup = teardown(&mut prepared.runtime_tasks, &mut producer_tasks, true).await;
            return Err(preserve_primary_error(error, cleanup));
        },
        Err(_) => {
            let completed = prepared
                .counters
                .execution_callbacks
                .load(Ordering::Acquire);
            let timeout_error = InfraError::Msg(format!(
                "native tick-to-trade {} timed out after {:?}: execution callbacks completed={completed}/{total_messages}",
                workload.name(),
                RUN_TIMEOUT,
            ));
            let cleanup = teardown(&mut prepared.runtime_tasks, &mut producer_tasks, true).await;
            return Err(preserve_primary_error(timeout_error, cleanup));
        },
    }

    let report = build_report(workload, messages_per_task, &prepared);
    report.validate()?;
    Ok(report)
}

async fn prepare_run(
    lanes: usize,
    messages_per_task: usize,
    total_messages: usize,
    wait_after_each_tick: bool,
) -> InfraResult<PreparedRun> {
    let trade_keys = (0..lanes)
        .map(|lane| TaskKey::ws(&WsChannel::Trades(None), task_id_for_lane(lane)))
        .collect::<Vec<_>>();
    let order_keys = (0..lanes)
        .map(|lane| TaskKey::alt(&AltTaskType::OrderExecution, task_id_for_lane(lane)))
        .collect::<Vec<_>>();
    let channels = Arc::new(TaskChannels::new(
        trade_keys.iter().chain(order_keys.iter()).cloned(),
    )?);

    let counters = Arc::new(Counters::default());
    let timing = Arc::new(TimingState::new(total_messages));
    let observations = Arc::new(ExecutionObservations::new(total_messages));
    let all_executed = Arc::new(Notify::new());
    let (completion_senders, completion_receivers) = if wait_after_each_tick {
        let mut senders = Vec::with_capacity(lanes);
        let mut receivers = Vec::with_capacity(lanes);
        for _ in 0..lanes {
            let (sender, receiver) = mpsc::unbounded_channel();
            senders.push(sender);
            receivers.push(Some(receiver));
        }
        (Some(Arc::new(senders)), receivers)
    } else {
        (None, (0..lanes).map(|_| None).collect())
    };

    let alt_info = Arc::new(AltTaskInfo {
        alt_task_type: AltTaskType::OrderExecution,
        chunk: lanes as u64,
        task_base_id: Some(TASK_ID_BASE),
    });
    let mut command_handles = Vec::with_capacity(lanes);
    let mut runners = Vec::with_capacity(lanes);
    for (lane, order_key) in order_keys.iter().enumerate() {
        let task_id = task_id_for_lane(lane);
        let (cmd_tx, cmd_rx) = mpsc::channel::<TaskCommand>(2_048);
        command_handles.push(Arc::new(CommandHandle {
            cmd_tx,
            task_info: TaskInfo::AltTask(Arc::clone(&alt_info)),
            task_id,
        }));
        runners.push(AltTaskRunner {
            cmd_rx,
            event_tx: channels
                .sender(order_key)
                .expect("TaskChannels contains every order key"),
            alt_info: Arc::clone(&alt_info),
            task_id,
        });
    }
    let registry = Arc::new(CommandRegistry::new(command_handles));

    let signal_receivers = channels.subscribe(trade_keys.clone())?;
    let execution_receivers = channels.subscribe(order_keys)?;
    let ready = Arc::new(Barrier::new(lanes + 3));
    let mut runtime_tasks = JoinSet::new();

    let signal = SignalProbe {
        registry: Arc::clone(&registry),
        counters: Arc::clone(&counters),
        messages_per_task,
        total_messages,
    };
    let signal_ready = Arc::clone(&ready);
    runtime_tasks.spawn(async move {
        signal_ready.wait().await;
        strategy_handler_loop(signal, signal_receivers).await;
    });

    let execution = ExecutionProbe {
        registry: Arc::clone(&registry),
        counters: Arc::clone(&counters),
        timing: Arc::clone(&timing),
        observations: Arc::clone(&observations),
        completions: completion_senders,
        all_executed: Arc::clone(&all_executed),
        messages_per_task,
        total_messages,
    };
    let execution_ready = Arc::clone(&ready);
    runtime_tasks.spawn(async move {
        execution_ready.wait().await;
        strategy_handler_loop(execution, execution_receivers).await;
    });

    for mut runner in runners {
        let runner_ready = Arc::clone(&ready);
        let orders_relayed = Arc::clone(&counters.orders_relayed);
        let failures = Arc::clone(&counters.failures);
        runtime_tasks.spawn(async move {
            runner_ready.wait().await;
            runner
                .benchmark_order_execution(orders_relayed, failures)
                .await;
        });
    }

    // Task/channel construction and scheduling readiness are outside elapsed_ns.
    ready.wait().await;

    let trade_senders = trade_keys
        .iter()
        .map(|key| {
            channels
                .sender(key)
                .expect("TaskChannels contains every trade key")
        })
        .collect();
    let events = (0..lanes)
        .map(|lane| {
            (0..messages_per_task)
                .map(|sequence| {
                    let global_index = lane * messages_per_task + sequence;
                    TaskEvent::Trade(InfraMsg {
                        task_id: task_id_for_lane(lane),
                        data: Arc::new(vec![WsTrade {
                            timestamp: correlation_timestamp(global_index),
                            market: Market::BinanceUmFutures,
                            inst: "BTC_USDT_PERP".into(),
                            price: expected_price(global_index),
                            size: 0.001,
                            side: if sequence % 2 == 0 {
                                OrderSide::BUY
                            } else {
                                OrderSide::SELL
                            },
                            trade_id: global_index as u64,
                        }]),
                    })
                })
                .collect()
        })
        .collect();

    Ok(PreparedRun {
        trade_senders,
        events,
        completion_receivers,
        runtime_tasks,
        counters,
        timing,
        observations,
        all_executed,
        _command_registry_guard: registry,
    })
}

#[allow(clippy::too_many_arguments)]
async fn run_producer(
    lane: usize,
    events: Vec<TaskEvent>,
    sender: tokio::sync::broadcast::Sender<TaskEvent>,
    mut completion_rx: Option<mpsc::UnboundedReceiver<usize>>,
    start_barrier: Arc<Barrier>,
    go: Arc<AtomicBool>,
    terminal_tx: mpsc::UnboundedSender<ProducerTerminal>,
    counters: Arc<Counters>,
    timing: Arc<TimingState>,
    wait_after_each_tick: bool,
) {
    let messages_per_task = events.len();
    let mut sent = 0;
    let mut completed = 0;
    start_barrier.wait().await;
    while !go.load(Ordering::Acquire) {
        tokio::task::yield_now().await;
    }

    for event in events {
        let global_index = event_global_index(&event).expect("prebuilt trade event is valid");
        timing.starts[global_index].store(timing.now_ns(), Ordering::Release);
        let in_flight = counters.in_flight.fetch_add(1, Ordering::Relaxed) + 1;
        counters
            .max_in_flight
            .fetch_max(in_flight, Ordering::Relaxed);

        if sender.send(event).is_err() {
            counters.in_flight.fetch_sub(1, Ordering::Relaxed);
            counters.failures.fetch_add(1, Ordering::Relaxed);
            continue;
        }
        counters.sent.fetch_add(1, Ordering::Relaxed);
        sent += 1;

        if wait_after_each_tick {
            let receiver = completion_rx
                .as_mut()
                .expect("unloaded producer has a completion receiver");
            completed +=
                receive_completion(lane, messages_per_task, global_index, receiver, &counters)
                    .await;
        }
    }

    let _ = terminal_tx.send(ProducerTerminal {
        lane,
        sent,
        completed,
    });
}

async fn receive_completion(
    lane: usize,
    messages_per_task: usize,
    expected_global_index: usize,
    completion_rx: &mut mpsc::UnboundedReceiver<usize>,
    counters: &Counters,
) -> usize {
    match completion_rx.recv().await {
        Some(global_index)
            if global_index == expected_global_index
                && global_index / messages_per_task == lane =>
        {
            1
        },
        Some(_) | None => {
            counters.failures.fetch_add(1, Ordering::Relaxed);
            0
        },
    }
}

fn event_global_index(event: &TaskEvent) -> Option<usize> {
    match event {
        TaskEvent::Trade(msg) if msg.data.len() == 1 => usize::try_from(msg.data[0].trade_id).ok(),
        _ => None,
    }
}

fn execution_global_index(
    msg: &InfraMsg<Vec<AltOrder>>,
    messages_per_task: usize,
    total_messages: usize,
) -> Option<usize> {
    if msg.data.len() != 1 {
        return None;
    }
    let global_index = msg.data[0]
        .timestamp
        .checked_sub(CORRELATION_TIMESTAMP_BASE)
        .and_then(|index| usize::try_from(index).ok())?;
    (global_index < total_messages && msg.task_id == task_id_for(global_index, messages_per_task))
        .then_some(global_index)
}

#[allow(clippy::too_many_arguments)]
async fn wait_for_phase(
    runtime_tasks: &mut JoinSet<()>,
    terminal_rx: &mut mpsc::UnboundedReceiver<ProducerTerminal>,
    terminal_seen: &mut [bool],
    counters: &Counters,
    all_executed: &Notify,
    lanes: usize,
    messages_per_task: usize,
    expected_completed: usize,
    total_messages: u64,
) -> InfraResult<()> {
    for _ in 0..lanes {
        let terminal = tokio::select! {
            biased;
            runtime_result = runtime_tasks.join_next(), if !runtime_tasks.is_empty() => {
                return Err(unexpected_runtime_exit(runtime_result));
            }
            terminal = terminal_rx.recv() => terminal.ok_or_else(|| {
                InfraError::Msg(
                    "producer terminal channel closed before all lanes finished".into(),
                )
            })?,
        };
        if terminal.lane >= lanes || terminal_seen[terminal.lane] {
            counters.failures.fetch_add(1, Ordering::Relaxed);
        } else {
            terminal_seen[terminal.lane] = true;
        }
        if terminal.sent != messages_per_task || terminal.completed != expected_completed {
            counters.failures.fetch_add(1, Ordering::Relaxed);
        }
    }

    wait_for_all_executed(
        runtime_tasks,
        &counters.execution_callbacks,
        all_executed,
        total_messages,
    )
    .await
}

async fn wait_for_all_executed(
    runtime_tasks: &mut JoinSet<()>,
    completed: &AtomicU64,
    notify: &Notify,
    expected: u64,
) -> InfraResult<()> {
    loop {
        let notified = notify.notified();
        if let Some(runtime_result) = runtime_tasks.try_join_next() {
            return Err(unexpected_runtime_exit(Some(runtime_result)));
        }
        if completed.load(Ordering::Acquire) >= expected {
            return Ok(());
        }
        tokio::select! {
            biased;
            runtime_result = runtime_tasks.join_next(), if !runtime_tasks.is_empty() => {
                return Err(unexpected_runtime_exit(runtime_result));
            }
            () = notified => {},
        }
    }
}

fn unexpected_runtime_exit(result: Option<Result<(), tokio::task::JoinError>>) -> InfraError {
    match result {
        Some(Ok(())) => InfraError::Msg("tick-to-trade runtime task exited unexpectedly".into()),
        Some(Err(error)) if error.is_panic() => {
            InfraError::Msg(format!("tick-to-trade runtime task panicked: {error}"))
        },
        Some(Err(error)) if error.is_cancelled() => InfraError::Msg(format!(
            "tick-to-trade runtime task was unexpectedly cancelled: {error}"
        )),
        Some(Err(error)) => InfraError::Msg(format!("tick-to-trade runtime task failed: {error}")),
        None => InfraError::Msg("tick-to-trade runtime task set became empty".into()),
    }
}

fn preserve_primary_error(primary: InfraError, cleanup: InfraResult<()>) -> InfraError {
    match cleanup {
        Ok(()) => primary,
        Err(cleanup_error) => {
            InfraError::Msg(format!("{primary}; cleanup also failed: {cleanup_error}"))
        },
    }
}

async fn teardown(
    runtime_tasks: &mut JoinSet<()>,
    producer_tasks: &mut Vec<JoinHandle<()>>,
    abort_producers: bool,
) -> InfraResult<()> {
    if abort_producers {
        for task in producer_tasks.iter() {
            task.abort();
        }
    }
    runtime_tasks.abort_all();

    let mut first_error = None;
    for task in producer_tasks.drain(..) {
        match task.await {
            Ok(()) => {},
            Err(error) if abort_producers && error.is_cancelled() => {},
            Err(error) => {
                let kind = if error.is_panic() {
                    "panicked"
                } else if error.is_cancelled() {
                    "was unexpectedly cancelled"
                } else {
                    "failed"
                };
                first_error.get_or_insert_with(|| {
                    InfraError::Msg(format!("tick-to-trade producer task {kind}: {error}"))
                });
            },
        }
    }

    while let Some(result) = runtime_tasks.join_next().await {
        match result {
            Err(error) if error.is_cancelled() => {},
            Err(error) => {
                let kind = if error.is_panic() {
                    "panicked"
                } else {
                    "failed"
                };
                first_error.get_or_insert_with(|| {
                    InfraError::Msg(format!("tick-to-trade runtime task {kind}: {error}"))
                });
            },
            Ok(()) => {
                first_error.get_or_insert_with(|| {
                    InfraError::Msg("tick-to-trade runtime task exited unexpectedly".into())
                });
            },
        }
    }

    if let Some(error) = first_error {
        Err(error)
    } else {
        Ok(())
    }
}

fn build_report(
    workload: NativeTickToTradeWorkload,
    messages_per_task: usize,
    prepared: &PreparedRun,
) -> NativeTickToTradeReport {
    let phase_start_ns = prepared.timing.phase_start_ns.load(Ordering::Acquire);
    let total_messages = prepared.timing.starts.len();
    let observations = prepared
        .observations
        .entries
        .lock()
        .expect("execution observation lock poisoned");
    let mut ends = vec![0; total_messages];
    let mut seen = vec![false; total_messages];
    let mut duplicates = 0;
    let mut route_mismatches = 0;
    let mut failures = 0;
    let mut observed_last_end_ns = 0;

    for observation in observations.iter() {
        observed_last_end_ns = observed_last_end_ns.max(observation.end_ns);
        if observation.msg.data.len() != 1 {
            failures += 1;
            continue;
        }
        let order = &observation.msg.data[0];
        let Some(global_index) = order
            .timestamp
            .checked_sub(CORRELATION_TIMESTAMP_BASE)
            .and_then(|index| usize::try_from(index).ok())
            .filter(|&index| index < total_messages)
        else {
            failures += 1;
            continue;
        };

        if observation.msg.task_id != task_id_for(global_index, messages_per_task)
            || order.market != Market::BinanceUmFutures
            || order.order_params.order_type != OrderType::Market
            || order.order_params.inst != "BTC_USDT_PERP"
            || order.order_params.size != "0.001"
            || order.order_params.side != expected_side(global_index, messages_per_task)
        {
            route_mismatches += 1;
        }

        // Market orders intentionally carry no price. Input price correlation
        // is checked at the native strategy callback before order generation.
        if seen[global_index] {
            duplicates += 1;
        } else {
            seen[global_index] = true;
            ends[global_index] = observation.end_ns;
        }
    }

    let execution_callbacks = prepared
        .counters
        .execution_callbacks
        .load(Ordering::Acquire);
    if execution_callbacks != observations.len() as u64 {
        failures += 1;
    }
    let last_end_ns = prepared.observations.last_end_ns.load(Ordering::Acquire);
    if last_end_ns != observed_last_end_ns {
        failures += 1;
    }
    drop(observations);

    let mut latencies = Vec::with_capacity(total_messages);
    let mut missing = 0;
    for (index, &was_seen) in seen.iter().enumerate() {
        if !was_seen {
            missing += 1;
        } else if let Some(latency) = checked_latency_ns(
            prepared.timing.starts[index].load(Ordering::Acquire),
            ends[index],
        ) {
            latencies.push(latency);
        } else {
            failures += 1;
        }
    }
    latencies.sort_unstable();

    let elapsed_ns = last_end_ns.saturating_sub(phase_start_ns);
    let total_messages = total_messages as u64;
    NativeTickToTradeReport {
        framework: "extrema_infra",
        workload: workload.name(),
        lanes: workload.lanes(),
        messages_per_task,
        total_messages,
        queue_inclusive: workload.queue_inclusive(),
        sent: prepared.counters.sent.load(Ordering::Relaxed),
        strategy_callbacks: prepared.counters.strategy_callbacks.load(Ordering::Relaxed),
        orders_generated: prepared.counters.orders_generated.load(Ordering::Relaxed),
        commands_sent: prepared.counters.commands_sent.load(Ordering::Relaxed),
        orders_relayed: prepared.counters.orders_relayed.load(Ordering::Relaxed),
        execution_callbacks,
        latency_samples: latencies.len() as u64,
        duplicates,
        route_mismatches: prepared.counters.route_mismatches.load(Ordering::Relaxed)
            + route_mismatches,
        missing,
        failures: prepared.counters.failures.load(Ordering::Relaxed) + failures,
        max_in_flight: prepared.counters.max_in_flight.load(Ordering::Relaxed),
        ending_in_flight: prepared.counters.in_flight.load(Ordering::Relaxed),
        wall_elapsed_ns: elapsed_ns,
        elapsed_ns,
        messages_per_second: if elapsed_ns == 0 {
            0.0
        } else {
            total_messages as f64 * 1_000_000_000.0 / elapsed_ns as f64
        },
        p50_ns: percentile_ns(&latencies, 50),
        p95_ns: percentile_ns(&latencies, 95),
        p99_ns: percentile_ns(&latencies, 99),
        min_ns: latencies.first().copied().unwrap_or(0),
        max_ns: latencies.last().copied().unwrap_or(0),
    }
}

fn task_id_for(global_index: usize, messages_per_task: usize) -> u64 {
    task_id_for_lane(global_index / messages_per_task)
}

fn task_id_for_lane(lane: usize) -> u64 {
    TASK_ID_BASE + lane as u64
}

fn correlation_timestamp(global_index: usize) -> u64 {
    CORRELATION_TIMESTAMP_BASE + global_index as u64
}

fn expected_price(global_index: usize) -> f64 {
    100_000.0 + global_index as f64 * 0.01
}

fn expected_side(global_index: usize, messages_per_task: usize) -> OrderSide {
    if (global_index % messages_per_task).is_multiple_of(2) {
        OrderSide::BUY
    } else {
        OrderSide::SELL
    }
}

fn checked_latency_ns(start_ns: u64, end_ns: u64) -> Option<u64> {
    (start_ns != 0 && end_ns > start_ns).then_some(end_ns.saturating_sub(start_ns))
}

fn percentile_ns(sorted: &[u64], percentile: u32) -> u64 {
    if sorted.is_empty() {
        return 0;
    }

    let percentile = percentile.min(100) as usize;
    let rank = (percentile * sorted.len()).div_ceil(100).max(1);
    sorted[rank - 1]
}

#[cfg(test)]
mod tests {
    use super::*;

    fn assert_conservation(report: &NativeTickToTradeReport, expected: u64) {
        assert_eq!(report.sent, expected);
        assert_eq!(report.strategy_callbacks, expected);
        assert_eq!(report.orders_generated, expected);
        assert_eq!(report.commands_sent, expected);
        assert_eq!(report.orders_relayed, expected);
        assert_eq!(report.execution_callbacks, expected);
        assert_eq!(report.latency_samples, expected);
        assert_eq!(report.duplicates, 0);
        assert_eq!(report.route_mismatches, 0);
        assert_eq!(report.missing, 0);
        assert_eq!(report.failures, 0);
        assert_eq!(report.ending_in_flight, 0);
        assert_eq!(report.wall_elapsed_ns, report.elapsed_ns);
        assert!(report.min_ns > 0);
    }

    #[test]
    fn nearest_rank_percentiles_cover_boundaries() {
        let sorted = [10, 20, 30, 40, 50];

        assert_eq!(percentile_ns(&[], 50), 0);
        assert_eq!(percentile_ns(&sorted, 0), 10);
        assert_eq!(percentile_ns(&sorted, 50), 30);
        assert_eq!(percentile_ns(&sorted, 95), 50);
        assert_eq!(percentile_ns(&sorted, 100), 50);
    }

    #[test]
    fn latency_requires_a_strictly_later_end_timestamp() {
        assert_eq!(checked_latency_ns(10, 9), None);
        assert_eq!(checked_latency_ns(10, 10), None);
        assert_eq!(checked_latency_ns(0, 10), None);
        assert_eq!(checked_latency_ns(10, 11), Some(1));
    }

    #[tokio::test]
    async fn teardown_propagates_producer_panics() {
        let (terminal, mut terminal_seen) = mpsc::unbounded_channel();
        let mut runtime_tasks = JoinSet::new();
        let mut producer_tasks = vec![tokio::spawn(async move {
            terminal.send(()).unwrap();
            panic!("producer panic regression");
        })];
        assert_eq!(terminal_seen.recv().await, Some(()));

        let error = teardown(&mut runtime_tasks, &mut producer_tasks, false)
            .await
            .unwrap_err();

        assert!(error.to_string().contains("producer task panicked"));
    }

    async fn phase_error_for_runtime_task(
        task: impl Future<Output = ()> + Send + 'static,
    ) -> InfraError {
        let mut runtime_tasks = JoinSet::new();
        runtime_tasks.spawn(task);
        let (_terminal_guard, mut terminal_rx) = mpsc::unbounded_channel();
        let mut terminal_seen = [false];
        let counters = Counters::default();
        let all_executed = Notify::new();

        tokio::time::timeout(
            Duration::from_millis(250),
            wait_for_phase(
                &mut runtime_tasks,
                &mut terminal_rx,
                &mut terminal_seen,
                &counters,
                &all_executed,
                1,
                1,
                0,
                1,
            ),
        )
        .await
        .expect("runtime supervision must fail before the phase timeout")
        .unwrap_err()
    }

    #[tokio::test]
    async fn phase_supervision_fails_fast_for_runtime_exit_and_panic() {
        let normal_exit = phase_error_for_runtime_task(async {}).await;
        assert!(normal_exit.to_string().contains("exited unexpectedly"));

        let panic = phase_error_for_runtime_task(async {
            panic!("runtime panic regression");
        })
        .await;
        assert!(panic.to_string().contains("runtime task panicked"));
    }

    #[tokio::test]
    async fn execution_wait_fails_fast_for_runtime_exit() {
        let completed = AtomicU64::new(0);
        let notify = Notify::new();
        let mut runtime_tasks = JoinSet::new();
        runtime_tasks.spawn(async {});

        let error = tokio::time::timeout(
            Duration::from_millis(250),
            wait_for_all_executed(&mut runtime_tasks, &completed, &notify, 1),
        )
        .await
        .expect("runtime supervision must fail before the execution wait timeout")
        .unwrap_err();

        assert!(error.to_string().contains("exited unexpectedly"));
    }

    #[test]
    fn cleanup_error_does_not_replace_primary_error() {
        let combined = preserve_primary_error(
            InfraError::Msg("timed out: completed=3/4".into()),
            Err(InfraError::Msg(
                "runtime task panicked during cleanup".into(),
            )),
        );
        let text = combined.to_string();

        assert!(text.contains("timed out: completed=3/4"));
        assert!(text.contains("cleanup also failed"));
        assert!(text.contains("runtime task panicked during cleanup"));
    }

    #[tokio::test]
    async fn completion_before_wait_is_observed() {
        let completed = AtomicU64::new(1);
        let notify = Notify::new();
        let mut runtime_tasks = JoinSet::new();
        notify.notify_one();

        tokio::time::timeout(
            Duration::from_millis(250),
            wait_for_all_executed(&mut runtime_tasks, &completed, &notify, 1),
        )
        .await
        .expect("completion notification sent before waiting must not be lost")
        .unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn unloaded_waits_for_each_execution_callback() {
        let report = run_native_tick_to_trade(NativeTickToTradeWorkload::Unloaded, 32)
            .await
            .unwrap();

        assert_conservation(&report, 32);
        assert_eq!(report.lanes, 1);
        assert!(!report.queue_inclusive);
        assert_eq!(report.max_in_flight, 1);
        assert!(report.elapsed_ns > 0);
        assert!(report.max_ns >= report.p99_ns);
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 8)]
    async fn saturated_configurable_lane_run_has_no_loss_or_duplicate() {
        let report =
            run_native_tick_to_trade(NativeTickToTradeWorkload::Saturated { tasks: 4 }, 32)
                .await
                .unwrap();

        assert_conservation(&report, 4 * 32);
        assert_eq!(report.lanes, 4);
        assert!(report.queue_inclusive);
        assert!(report.max_in_flight > 1);
        assert!(report.elapsed_ns > 0);
        assert!(report.p50_ns <= report.p95_ns);
        assert!(report.p95_ns <= report.p99_ns);
        assert!(report.p99_ns <= report.max_ns);
    }

    #[tokio::test]
    async fn saturated_zero_tasks_is_rejected() {
        let error = run_native_tick_to_trade(NativeTickToTradeWorkload::Saturated { tasks: 0 }, 1)
            .await
            .unwrap_err();

        assert!(error.to_string().contains("task count"));
    }
}
