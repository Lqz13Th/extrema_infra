//! Internal before/after coverage for specialized exchange WebSocket decoders.

use serde_json::from_slice;

use crate::arch::{
    market_assets::exchange::{
        gate::{
            gate_ws_msg::{GateWsData, decode_single_ws_frame},
            schemas::futures_ws::lob::{
                WsBookTickerGateFutures, WsOrderBookGateFutures, WsOrderBookUpdateGateFutures,
            },
            schemas::futures_ws::trades::WsTradeGateFutures,
        },
        hyperliquid::{
            hyperliquid_ws_msg::HyperliquidWsData,
            schemas::ws::lob::{WsLobHyperliquid, decode_bbo_frame, decode_l2_book_frame},
        },
    },
    strategy_base::handler::lob_events::{WsLob, WsTrade},
    traits::conversion::IntoWsData,
};

pub const GATE_BBO: &[u8] = br#"{"channel":"futures.book_ticker","event":"update","result":{"t":1780569310140,"u":114427040898,"s":"BTC_USDT","b":"62706.4","B":3335,"a":"62706.5","A":8275}}"#;

pub const GATE_SNAPSHOT: &[u8] = br#"{"channel":"futures.order_book","event":"all","result":{"t":1780569310995,"id":114427042721,"contract":"BTC_USDT","asks":[{"p":"62698.1","s":10046}],"bids":[{"p":"62698","s":144730}],"l":"20"}}"#;

pub const GATE_INCREMENTAL: &[u8] = br#"{"channel":"futures.order_book_update","event":"update","result":{"t":1780569312795,"U":114427044935,"u":114427045214,"s":"BTC_USDT","a":[{"p":"62706.5","s":0}],"b":[],"l":"20"}}"#;

pub const GATE_CONTROL: &[u8] =
    br#"{"channel":"futures.book_ticker","event":"subscribe","result":{"status":"success"}}"#;

pub const HYPERLIQUID_BBO: &[u8] = br#"{"channel":"bbo","data":{"coin":"BTC","time":1733833200000,"bbo":[{"px":"98450.5","sz":"2.5","n":3},{"px":"98451.0","sz":"1.5","n":2}]}}"#;

pub const HYPERLIQUID_L2: &[u8] = br#"{"channel":"l2Book","data":{"coin":"BTC","levels":[[{"px":"98450.5","sz":"2.5","n":3},{"px":"98449.0","sz":"1.8","n":2},{"px":"98448.0","sz":"0.75","n":1},{"px":"98447.0","sz":"3.2","n":4},{"px":"98446.0","sz":"1.1","n":2},{"px":"98445.0","sz":"2.0","n":3},{"px":"98444.0","sz":"0.5","n":1},{"px":"98443.0","sz":"1.4","n":2},{"px":"98442.0","sz":"0.9","n":1},{"px":"98441.0","sz":"1.7","n":2}],[{"px":"98451.0","sz":"1.5","n":2},{"px":"98452.0","sz":"2.1","n":3},{"px":"98453.0","sz":"0.9","n":1},{"px":"98454.0","sz":"1.7","n":2},{"px":"98455.0","sz":"2.3","n":4},{"px":"98456.0","sz":"0.6","n":1},{"px":"98457.0","sz":"1.2","n":2},{"px":"98458.0","sz":"0.8","n":1},{"px":"98459.0","sz":"1.5","n":2},{"px":"98460.0","sz":"2.0","n":3}]],"time":1733833200000}}"#;

pub const HYPERLIQUID_PONG: &[u8] = br#"{"channel":"pong"}"#;

/// Decodes one Gate USDT perpetual trade frame through the same generic
/// envelope and normalization path used by the production trade WS runner.
pub fn gate_usdt_futures_trade(frame: &[u8]) -> serde_json::Result<Vec<WsTrade>> {
    let message: GateWsData<WsTradeGateFutures> = from_slice(frame)?;
    Ok(message.into_ws())
}

pub fn gate_bbo_legacy(frame: &[u8]) -> Vec<WsLob> {
    let message: GateWsData<WsBookTickerGateFutures> = from_slice(frame).unwrap();
    message.into_ws()
}

pub fn gate_bbo_specialized(frame: &[u8]) -> Vec<WsLob> {
    decode_single_ws_frame::<WsBookTickerGateFutures>(frame)
        .unwrap()
        .into_ws()
}

pub fn gate_snapshot_legacy(frame: &[u8]) -> Vec<WsLob> {
    let message: GateWsData<WsOrderBookGateFutures> = from_slice(frame).unwrap();
    message.into_ws()
}

pub fn gate_snapshot_specialized(frame: &[u8]) -> Vec<WsLob> {
    decode_single_ws_frame::<WsOrderBookGateFutures>(frame)
        .unwrap()
        .into_ws()
}

pub fn gate_incremental_legacy(frame: &[u8]) -> Vec<WsLob> {
    let message: GateWsData<WsOrderBookUpdateGateFutures> = from_slice(frame).unwrap();
    message.into_ws()
}

pub fn gate_incremental_specialized(frame: &[u8]) -> Vec<WsLob> {
    decode_single_ws_frame::<WsOrderBookUpdateGateFutures>(frame)
        .unwrap()
        .into_ws()
}

pub fn gate_control_legacy(frame: &[u8]) -> Vec<WsLob> {
    let message: GateWsData<WsBookTickerGateFutures> = from_slice(frame).unwrap();
    message.into_ws()
}

pub fn gate_control_specialized(frame: &[u8]) -> Vec<WsLob> {
    decode_single_ws_frame::<WsBookTickerGateFutures>(frame)
        .unwrap()
        .into_ws()
}

pub fn hyperliquid_bbo_legacy(frame: &[u8]) -> Vec<WsLob> {
    let message: HyperliquidWsData<WsLobHyperliquid> = from_slice(frame).unwrap();
    message.into_ws()
}

pub fn hyperliquid_bbo_specialized(frame: &[u8]) -> Vec<WsLob> {
    decode_bbo_frame(frame).unwrap().into_ws()
}

pub fn hyperliquid_l2_legacy(frame: &[u8]) -> Vec<WsLob> {
    let message: HyperliquidWsData<WsLobHyperliquid> = from_slice(frame).unwrap();
    message.into_ws()
}

pub fn hyperliquid_l2_specialized(frame: &[u8]) -> Vec<WsLob> {
    decode_l2_book_frame(frame).unwrap().into_ws()
}

pub fn hyperliquid_pong_legacy(frame: &[u8]) -> Vec<WsLob> {
    let message: HyperliquidWsData<WsLobHyperliquid> = from_slice(frame).unwrap();
    message.into_ws()
}

pub fn hyperliquid_pong_specialized(frame: &[u8]) -> Vec<WsLob> {
    decode_l2_book_frame(frame).unwrap().into_ws()
}
